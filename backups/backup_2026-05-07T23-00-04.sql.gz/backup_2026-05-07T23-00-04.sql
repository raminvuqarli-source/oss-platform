--
-- PostgreSQL database dump
--

\restrict C6JhoSMKUlyey91ck26gdpKQ7G9ndRNmO9OQLwB5V5fwdyg6FlPgPdCUwL3o5rE

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: pgboss; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgboss;


--
-- Name: job_state; Type: TYPE; Schema: pgboss; Owner: -
--

CREATE TYPE pgboss.job_state AS ENUM (
    'created',
    'retry',
    'active',
    'completed',
    'cancelled',
    'failed'
);


--
-- Name: create_queue(text, json); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.create_queue(queue_name text, options json) RETURNS void
    LANGUAGE plpgsql
    AS $_$
    DECLARE
      table_name varchar := 'j' || encode(sha224(queue_name::bytea), 'hex');
      queue_created_on timestamptz;
    BEGIN

      WITH q as (
      INSERT INTO pgboss.queue (
        name,
        policy,
        retry_limit,
        retry_delay,
        retry_backoff,
        expire_seconds,
        retention_minutes,
        dead_letter,
        partition_name
      )
      VALUES (
        queue_name,
        options->>'policy',
        (options->>'retryLimit')::int,
        (options->>'retryDelay')::int,
        (options->>'retryBackoff')::bool,
        (options->>'expireInSeconds')::int,
        (options->>'retentionMinutes')::int,
        options->>'deadLetter',
        table_name
      )
      ON CONFLICT DO NOTHING
      RETURNING created_on
      )
      SELECT created_on into queue_created_on from q;

      IF queue_created_on IS NULL THEN
        RETURN;
      END IF;

      EXECUTE format('CREATE TABLE pgboss.%I (LIKE pgboss.job INCLUDING DEFAULTS)', table_name);

      EXECUTE format('ALTER TABLE pgboss.%1$I ADD PRIMARY KEY (name, id)', table_name);
      EXECUTE format('ALTER TABLE pgboss.%1$I ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED', table_name);
      EXECUTE format('ALTER TABLE pgboss.%1$I ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue (name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i1 ON pgboss.%1$I (name, COALESCE(singleton_key, '''')) WHERE state = ''created'' AND policy = ''short''', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i2 ON pgboss.%1$I (name, COALESCE(singleton_key, '''')) WHERE state = ''active'' AND policy = ''singleton''', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i3 ON pgboss.%1$I (name, state, COALESCE(singleton_key, '''')) WHERE state <= ''active'' AND policy = ''stately''', table_name);
      EXECUTE format('CREATE UNIQUE INDEX %1$s_i4 ON pgboss.%1$I (name, singleton_on, COALESCE(singleton_key, '''')) WHERE state <> ''cancelled'' AND singleton_on IS NOT NULL', table_name);
      EXECUTE format('CREATE INDEX %1$s_i5 ON pgboss.%1$I (name, start_after) INCLUDE (priority, created_on, id) WHERE state < ''active''', table_name);

      EXECUTE format('ALTER TABLE pgboss.%I ADD CONSTRAINT cjc CHECK (name=%L)', table_name, queue_name);
      EXECUTE format('ALTER TABLE pgboss.job ATTACH PARTITION pgboss.%I FOR VALUES IN (%L)', table_name, queue_name);
    END;
    $_$;


--
-- Name: delete_queue(text); Type: FUNCTION; Schema: pgboss; Owner: -
--

CREATE FUNCTION pgboss.delete_queue(queue_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
      table_name varchar;
    BEGIN
      WITH deleted as (
        DELETE FROM pgboss.queue
        WHERE name = queue_name
        RETURNING partition_name
      )
      SELECT partition_name from deleted INTO table_name;

      EXECUTE format('DROP TABLE IF EXISTS pgboss.%I', table_name);
    END;
    $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: archive; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.archive (
    id uuid NOT NULL,
    name text NOT NULL,
    priority integer NOT NULL,
    data jsonb,
    state pgboss.job_state NOT NULL,
    retry_limit integer NOT NULL,
    retry_count integer NOT NULL,
    retry_delay integer NOT NULL,
    retry_backoff boolean NOT NULL,
    start_after timestamp with time zone NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval NOT NULL,
    created_on timestamp with time zone NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    archived_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: job; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.job (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text
)
PARTITION BY LIST (name);


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'subscription-renewal-check'::text))
);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = '__pgboss__send-it'::text))
);


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'night-audit-cron'::text))
);


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'payment-retry'::text))
);


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'night-audit'::text))
);


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'database-backup'::text))
);


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'subscription-renewal'::text))
);


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    data jsonb,
    state pgboss.job_state DEFAULT 'created'::pgboss.job_state NOT NULL,
    retry_limit integer DEFAULT 2 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_delay integer DEFAULT 0 NOT NULL,
    retry_backoff boolean DEFAULT false NOT NULL,
    start_after timestamp with time zone DEFAULT now() NOT NULL,
    started_on timestamp with time zone,
    singleton_key text,
    singleton_on timestamp without time zone,
    expire_in interval DEFAULT '00:15:00'::interval NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    completed_on timestamp with time zone,
    keep_until timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    output jsonb,
    dead_letter text,
    policy text,
    CONSTRAINT cjc CHECK ((name = 'database-backup-schedule'::text))
);


--
-- Name: queue; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.queue (
    name text NOT NULL,
    policy text,
    retry_limit integer,
    retry_delay integer,
    retry_backoff boolean,
    expire_seconds integer,
    retention_minutes integer,
    dead_letter text,
    partition_name text,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schedule; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.schedule (
    name text NOT NULL,
    cron text NOT NULL,
    timezone text,
    data jsonb,
    options jsonb,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.subscription (
    event text NOT NULL,
    name text NOT NULL,
    created_on timestamp with time zone DEFAULT now() NOT NULL,
    updated_on timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version; Type: TABLE; Schema: pgboss; Owner: -
--

CREATE TABLE pgboss.version (
    version integer NOT NULL,
    maintained_on timestamp with time zone,
    cron_on timestamp with time zone,
    monitored_on timestamp with time zone
);


--
-- Name: analytics_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_snapshots (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    property_id character varying,
    snapshot_type text NOT NULL,
    period text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: api_usage_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_usage_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    endpoint text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying,
    property_id character varying,
    user_id character varying,
    user_role text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying,
    description text,
    previous_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: billing_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_info (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    stripe_customer_id text,
    stripe_subscription_id text,
    payment_method_last4 text,
    payment_method_brand text,
    billing_email text,
    billing_name text,
    billing_address jsonb,
    current_period_start timestamp without time zone,
    current_period_end timestamp without time zone,
    cancel_at_period_end boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: billing_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    hotel_id character varying,
    owner_id character varying,
    event_type character varying NOT NULL,
    description text,
    amount_usd numeric(10,2) DEFAULT 0 NOT NULL,
    messages_added integer DEFAULT 0,
    package_name character varying,
    status character varying DEFAULT 'completed'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: board_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    reporter_name text NOT NULL,
    region text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    contract_ids text[],
    period_start timestamp without time zone,
    period_end timestamp without time zone,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    guest_id character varying NOT NULL,
    room_number text NOT NULL,
    room_type text NOT NULL,
    check_in_date timestamp without time zone NOT NULL,
    check_out_date timestamp without time zone NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    pre_checked_in boolean DEFAULT false,
    special_requests text,
    created_at timestamp without time zone DEFAULT now(),
    booking_number text,
    booking_source text,
    number_of_guests integer,
    nationality text,
    passport_number text,
    special_notes text,
    owner_id character varying,
    property_id character varying,
    unit_id character varying,
    nightly_rate integer,
    total_price integer,
    currency text DEFAULT 'USD'::text,
    discount integer,
    tenant_id character varying,
    travel_agency_name text,
    date_of_birth text,
    guest_address text,
    arrival_time text,
    pre_check_notes text,
    rejection_reason text,
    payment_status text DEFAULT 'unpaid'::text,
    guest_signature_base64 text,
    id_document_base64 text,
    rate_plan_id character varying,
    deposit_amount integer,
    deposit_due_date timestamp without time zone,
    deposit_paid_at timestamp without time zone,
    paid_amount integer DEFAULT 0,
    remaining_balance integer,
    payment_method text
);


--
-- Name: cancellation_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cancellation_policies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    name text NOT NULL,
    free_cancellation_hours integer DEFAULT 24,
    no_show_penalty_type text DEFAULT 'percent'::text,
    no_show_penalty_value integer DEFAULT 10000,
    late_cancellation_penalty_type text DEFAULT 'percent'::text,
    late_cancellation_penalty_value integer DEFAULT 10000,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: cash_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_accounts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    owner_id character varying,
    account_type text DEFAULT 'cash'::text NOT NULL,
    account_name text NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    last_updated timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chart_of_accounts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    account_code text NOT NULL,
    account_name text NOT NULL,
    account_type text NOT NULL,
    parent_id character varying,
    is_system boolean DEFAULT false,
    is_active boolean DEFAULT true,
    normal_balance text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    guest_id character varying NOT NULL,
    sender_id character varying NOT NULL,
    sender_role text NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    property_id character varying,
    thread_type text DEFAULT 'guest_service'::text NOT NULL,
    escalated_by character varying,
    escalation_note text,
    tenant_id character varying
);


--
-- Name: contract_acceptances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_acceptances (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    tenant_id character varying,
    user_id character varying NOT NULL,
    plan_code text NOT NULL,
    plan_type text NOT NULL,
    smart_plan_type text,
    contract_version text NOT NULL,
    property_name text,
    monthly_price integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    accepted_at timestamp without time zone NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now(),
    contract_language text DEFAULT 'EN'::text NOT NULL
);


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    region text NOT NULL,
    country text NOT NULL,
    client_name text NOT NULL,
    contract_value integer NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    partner_company text,
    partner_commission_percent integer DEFAULT 20 NOT NULL,
    tax_percent integer DEFAULT 18 NOT NULL,
    state_fee_percent integer DEFAULT 10 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    signed_date timestamp without time zone,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: cost_centers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_centers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    department_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    name text NOT NULL,
    code text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: credential_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credential_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    guest_id character varying NOT NULL,
    action text NOT NULL,
    performed_by character varying NOT NULL,
    performed_by_name text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: daily_financial_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_financial_summaries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    summary_date timestamp without time zone NOT NULL,
    room_revenue integer DEFAULT 0,
    fb_revenue integer DEFAULT 0,
    spa_revenue integer DEFAULT 0,
    other_revenue integer DEFAULT 0,
    total_revenue integer DEFAULT 0,
    total_tax integer DEFAULT 0,
    total_expenses integer DEFAULT 0,
    occupied_rooms integer DEFAULT 0,
    total_rooms integer DEFAULT 0,
    occupancy_rate integer DEFAULT 0,
    adr integer DEFAULT 0,
    revpar integer DEFAULT 0,
    total_payments_cash integer DEFAULT 0,
    total_payments_card integer DEFAULT 0,
    total_payments_bank integer DEFAULT 0,
    is_locked boolean DEFAULT false,
    locked_at timestamp without time zone,
    locked_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: deleted_trial_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deleted_trial_accounts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying NOT NULL,
    hotel_name character varying,
    deleted_at timestamp without time zone DEFAULT now(),
    reason character varying DEFAULT 'trial_expired'::character varying
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    name text NOT NULL,
    code text NOT NULL,
    type text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: device_telemetry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_telemetry (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    device_id character varying NOT NULL,
    metric_name text NOT NULL,
    metric_value real,
    string_value text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    unit_id character varying,
    property_id character varying NOT NULL,
    owner_id character varying NOT NULL,
    device_type text NOT NULL,
    name text NOT NULL,
    manufacturer text,
    model text,
    serial_number text,
    status text DEFAULT 'offline'::text NOT NULL,
    last_ping timestamp without time zone,
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    ip_address text,
    mac_address text,
    firmware_version text,
    hardware_version text,
    last_online timestamp without time zone,
    battery_level integer,
    signal_strength integer,
    capabilities text[],
    configuration jsonb,
    installed_at timestamp without time zone,
    tenant_id character varying
);


--
-- Name: door_action_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.door_action_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    booking_id character varying NOT NULL,
    guest_id character varying NOT NULL,
    room_number text NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: escalation_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.escalation_replies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    escalation_id character varying NOT NULL,
    user_id character varying NOT NULL,
    message text NOT NULL,
    tenant_id character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    owner_id character varying,
    recurring_expense_id character varying,
    category text NOT NULL,
    description text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    vendor text,
    receipt_url text,
    source_type text DEFAULT 'staff_input'::text NOT NULL,
    period_month integer,
    period_year integer,
    created_by character varying,
    created_by_name text,
    approved_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: external_bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_bookings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying,
    tenant_id character varying,
    source text,
    external_id text,
    guest_name text,
    checkin_date text,
    checkout_date text,
    room_name text,
    price real,
    status text DEFAULT 'confirmed'::text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: feature_flag_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flag_overrides (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    feature_name text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    reason text,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: financial_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    action text NOT NULL,
    performed_by character varying NOT NULL,
    performed_by_name text NOT NULL,
    previous_values jsonb,
    new_values jsonb,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    guest_id character varying,
    booking_id character varying,
    room_number text,
    category text NOT NULL,
    description text NOT NULL,
    amount integer NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    notes text,
    created_by character varying NOT NULL,
    created_by_name text NOT NULL,
    voided_at timestamp without time zone,
    voided_by character varying,
    void_reason text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    owner_id character varying,
    property_id character varying,
    transaction_reference text,
    tenant_id character varying
);


--
-- Name: folio_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folio_adjustments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    folio_id character varying NOT NULL,
    booking_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    adjustment_type text NOT NULL,
    description text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'USD'::text,
    approved_by character varying,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    approval_status text DEFAULT 'approved'::text NOT NULL,
    approved_at timestamp without time zone,
    rejected_by character varying,
    rejected_at timestamp without time zone,
    rejection_reason text
);


--
-- Name: folio_charges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folio_charges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    folio_id character varying NOT NULL,
    booking_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    department_id character varying,
    cost_center_id character varying,
    charge_type text NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1,
    unit_price integer NOT NULL,
    amount_net integer NOT NULL,
    tax_rate integer DEFAULT 0,
    tax_amount integer DEFAULT 0,
    amount_gross integer NOT NULL,
    is_inclusive boolean DEFAULT false,
    currency text DEFAULT 'USD'::text,
    service_date timestamp without time zone,
    idempotency_key text,
    status text DEFAULT 'posted'::text NOT NULL,
    voided_at timestamp without time zone,
    voided_by character varying,
    void_reason text,
    posted_by character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: folio_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folio_payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    folio_id character varying NOT NULL,
    booking_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    payment_type text DEFAULT 'payment'::text NOT NULL,
    payment_method text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'USD'::text,
    reference_number text,
    is_deposit boolean DEFAULT false,
    status text DEFAULT 'completed'::text NOT NULL,
    received_at timestamp without time zone DEFAULT now(),
    received_by character varying,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: guest_folios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guest_folios (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    booking_id character varying NOT NULL,
    guest_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    tenant_id character varying,
    folio_number text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    currency text DEFAULT 'USD'::text,
    total_charges integer DEFAULT 0,
    total_payments integer DEFAULT 0,
    total_adjustments integer DEFAULT 0,
    balance integer DEFAULT 0,
    tax_total integer DEFAULT 0,
    opened_at timestamp without time zone DEFAULT now(),
    closed_at timestamp without time zone,
    finalized_at timestamp without time zone,
    finalized_by character varying,
    invoice_generated_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: hotels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotels (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    address text,
    phone text,
    email text,
    logo_url text,
    created_at timestamp without time zone DEFAULT now(),
    country text,
    city text,
    postal_code text,
    website text,
    star_rating text,
    total_rooms integer,
    number_of_floors integer,
    building_type text,
    primary_guest_type text,
    has_smart_devices boolean DEFAULT false,
    smart_door_locks boolean DEFAULT false,
    smart_hvac boolean DEFAULT false,
    smart_lighting boolean DEFAULT false,
    pms_system boolean DEFAULT false,
    bms_system boolean DEFAULT false,
    iot_sensors boolean DEFAULT false,
    pms_software text,
    pms_other text,
    expected_smart_room_count integer,
    billing_currency text,
    billing_contact_email text,
    owner_id character varying,
    property_id character varying,
    tenant_id character varying,
    is_channex_enabled boolean DEFAULT false,
    channex_property_uuid text,
    channex_addon_price integer,
    channex_room_count integer,
    total_monthly_subscription_fee numeric(10,2),
    is_whatsapp_enabled boolean DEFAULT false,
    whatsapp_balance integer DEFAULT 0
);


--
-- Name: housekeeping_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.housekeeping_tasks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    property_id character varying NOT NULL,
    unit_id character varying NOT NULL,
    room_number text NOT NULL,
    task_type text NOT NULL,
    cleaning_type text,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'normal'::text,
    assigned_to character varying,
    trigger_source text NOT NULL,
    notes text,
    due_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    booking_id character varying
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    stripe_invoice_id text,
    amount integer NOT NULL,
    currency text DEFAULT 'usd'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    description text,
    invoice_url text,
    pdf_url text,
    period_start timestamp without time zone,
    period_end timestamp without time zone,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying,
    invoice_number text,
    pdf_path text
);


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    entry_number text NOT NULL,
    entry_date timestamp without time zone NOT NULL,
    description text NOT NULL,
    source_type text NOT NULL,
    source_id character varying,
    status text DEFAULT 'posted'::text NOT NULL,
    total_debit integer DEFAULT 0,
    total_credit integer DEFAULT 0,
    currency text DEFAULT 'USD'::text,
    created_by character varying,
    reversed_by character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: journal_entry_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entry_lines (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    journal_entry_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    account_id character varying NOT NULL,
    department_id character varying,
    description text,
    debit integer DEFAULT 0,
    credit integer DEFAULT 0,
    currency text DEFAULT 'USD'::text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_name text NOT NULL,
    country text NOT NULL,
    property_type text NOT NULL,
    email text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: night_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.night_audits (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    audit_date timestamp without time zone NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    total_revenue integer DEFAULT 0,
    total_payments integer DEFAULT 0,
    total_adjustments integer DEFAULT 0,
    room_nights_posted integer DEFAULT 0,
    occupied_rooms integer DEFAULT 0,
    total_rooms integer DEFAULT 0,
    occupancy_rate integer DEFAULT 0,
    notes text,
    closed_at timestamp without time zone,
    closed_by character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: no_show_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.no_show_records (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    booking_id character varying NOT NULL,
    guest_id character varying NOT NULL,
    room_number text NOT NULL,
    expected_check_in timestamp without time zone NOT NULL,
    estimated_revenue_loss integer,
    recorded_by character varying NOT NULL,
    recorded_by_name text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    read boolean DEFAULT false,
    action_url text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: onboarding_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_progress (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    current_step integer DEFAULT 1 NOT NULL,
    completed_steps integer[] DEFAULT '{}'::integer[],
    account_completed boolean DEFAULT false,
    property_completed boolean DEFAULT false,
    units_completed boolean DEFAULT false,
    subscription_completed boolean DEFAULT false,
    devices_completed boolean DEFAULT false,
    is_complete boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tenant_id character varying,
    smart_system_completed boolean DEFAULT false,
    staff_completed boolean DEFAULT false
);


--
-- Name: ota_conflicts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ota_conflicts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    external_id text NOT NULL,
    property_id character varying NOT NULL,
    tenant_id character varying,
    unit_id character varying,
    check_in text,
    check_out text,
    guest_name text,
    reason text NOT NULL,
    resolved boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: ota_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ota_integrations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    tenant_id character varying,
    provider text NOT NULL,
    api_key text,
    api_secret text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: ota_sync_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ota_sync_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    property_id character varying NOT NULL,
    tenant_id character varying,
    action text NOT NULL,
    status text NOT NULL,
    response text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.owners (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    company_name text,
    country text,
    city text,
    address text,
    logo_url text,
    created_at timestamp without time zone DEFAULT now(),
    status text DEFAULT 'active'::text NOT NULL,
    tax_id text,
    legal_name text,
    registration_number text,
    referral_source text,
    referral_staff_id character varying,
    referral_notes text,
    tenant_type text DEFAULT 'hotel'::text NOT NULL
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    label text NOT NULL,
    type text DEFAULT 'bank_transfer'::text NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    details jsonb NOT NULL,
    instructions text,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: payment_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    tenant_id character varying,
    plan_type text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    payment_method_id character varying,
    customer_note text,
    admin_note text,
    transfer_reference text,
    reviewed_by character varying,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    order_type text DEFAULT 'subscription'::text,
    reference_id character varying
);


--
-- Name: payroll_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_configs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    owner_id character varying,
    staff_id character varying NOT NULL,
    staff_name text NOT NULL,
    staff_role text NOT NULL,
    base_salary integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    frequency text DEFAULT 'monthly'::text NOT NULL,
    bonus_rules text,
    deduction_rules text,
    bank_details text,
    is_active boolean DEFAULT true NOT NULL,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tenant_id character varying,
    employee_tax_rate integer DEFAULT 0,
    additional_expenses_monthly integer DEFAULT 0
);


--
-- Name: payroll_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    owner_id character varying,
    payroll_config_id character varying NOT NULL,
    staff_id character varying NOT NULL,
    staff_name text NOT NULL,
    amount integer NOT NULL,
    bonus_amount integer DEFAULT 0,
    deduction_amount integer DEFAULT 0,
    net_amount integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    period_month integer NOT NULL,
    period_year integer NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    paid_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: pos_menu_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_menu_categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    property_id character varying NOT NULL,
    name character varying NOT NULL,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: pos_menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_menu_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    property_id character varying NOT NULL,
    category_id character varying,
    name character varying NOT NULL,
    description text,
    price_cents integer NOT NULL,
    image_url text,
    is_available boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: pos_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_order_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    order_id character varying NOT NULL,
    menu_item_id character varying,
    item_name character varying NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price_cents integer NOT NULL,
    total_cents integer NOT NULL
);


--
-- Name: pos_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    property_id character varying NOT NULL,
    folio_id character varying,
    booking_id character varying,
    table_number character varying,
    guest_name character varying,
    waiter_id character varying,
    kitchen_status character varying DEFAULT 'pending'::character varying NOT NULL,
    settlement_status character varying DEFAULT 'pending'::character varying NOT NULL,
    notes text,
    total_cents integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    ready_at timestamp without time zone,
    delivered_at timestamp without time zone,
    settled_at timestamp without time zone,
    room_number character varying,
    order_type character varying DEFAULT 'dine_in'::character varying,
    source_type character varying DEFAULT 'staff'::character varying,
    items jsonb
);


--
-- Name: pricing_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_rules (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    tenant_id character varying,
    name text NOT NULL,
    rule_type text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    conditions jsonb NOT NULL,
    adjustment jsonb NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.properties (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'hotel'::text NOT NULL,
    address text,
    phone text,
    email text,
    logo_url text,
    country text,
    city text,
    postal_code text,
    website text,
    star_rating text,
    total_units integer,
    number_of_floors integer,
    building_type text,
    primary_guest_type text,
    has_smart_devices boolean DEFAULT false,
    smart_door_locks boolean DEFAULT false,
    smart_hvac boolean DEFAULT false,
    smart_lighting boolean DEFAULT false,
    pms_system boolean DEFAULT false,
    bms_system boolean DEFAULT false,
    iot_sensors boolean DEFAULT false,
    pms_software text,
    pms_other text,
    expected_smart_room_count integer,
    billing_currency text,
    billing_contact_email text,
    timezone text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying,
    image_url text,
    country_tax_rate integer DEFAULT 0,
    utility_expense_pct integer DEFAULT 0,
    cleaning_expense_monthly integer DEFAULT 0,
    default_employee_tax_rate integer DEFAULT 0,
    additional_expenses_monthly integer DEFAULT 0
);


--
-- Name: quote_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_notes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    quote_request_id character varying NOT NULL,
    author_user_id character varying NOT NULL,
    note_text text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: quote_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_name text NOT NULL,
    contact_name text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    country text NOT NULL,
    city text NOT NULL,
    preferred_contact_hours text,
    timezone text,
    preferred_contact_method text,
    total_rooms integer,
    expected_smart_rooms integer,
    interested_features text[],
    message text,
    source_page text NOT NULL,
    language text DEFAULT 'en'::text,
    status text DEFAULT 'NEW'::text NOT NULL,
    internal_notes text,
    email_sent boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    assigned_to_user_id character varying,
    contacted_at timestamp without time zone
);


--
-- Name: rate_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_plans (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    tenant_id character varying,
    name text NOT NULL,
    refund_policy text DEFAULT 'flexible'::text NOT NULL,
    meal_plan text DEFAULT 'none'::text NOT NULL,
    price_modifier real DEFAULT 0 NOT NULL,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: recurring_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_expenses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    owner_id character varying,
    category text NOT NULL,
    description text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    frequency text DEFAULT 'monthly'::text NOT NULL,
    vendor text,
    is_active boolean DEFAULT true NOT NULL,
    next_run_at timestamp without time zone,
    last_run_at timestamp without time zone,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: referral_commissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referral_commissions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    staff_user_id character varying NOT NULL,
    owner_id character varying NOT NULL,
    commission_pct text DEFAULT '10.00'::text,
    status text DEFAULT 'pending'::text NOT NULL,
    amount_cents integer,
    paid_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: refund_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    invoice_id character varying NOT NULL,
    transaction_id character varying,
    owner_id character varying NOT NULL,
    tenant_id character varying,
    amount integer NOT NULL,
    currency text DEFAULT 'AZN'::text NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_by character varying NOT NULL,
    approved_by character varying,
    rejected_by character varying,
    rejection_reason text,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: restaurant_cleaning_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_cleaning_tasks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    property_id character varying NOT NULL,
    description text NOT NULL,
    location character varying,
    assigned_to_id character varying,
    created_by_id character varying,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    completed_at timestamp without time zone,
    photo_url text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: restaurant_guest_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_guest_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    table_number character varying NOT NULL,
    sender_name character varying DEFAULT 'Qonaq'::character varying,
    message text NOT NULL,
    is_read_by_waiter boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: restaurant_staff_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_staff_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    property_id character varying NOT NULL,
    salary_amount character varying DEFAULT '0'::character varying,
    tax_rate character varying DEFAULT '0'::character varying,
    tables_assigned text,
    notes text,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: restaurant_tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_tables (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    table_number character varying(20) NOT NULL,
    capacity integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: revenues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revenues (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    property_id character varying,
    owner_id character varying,
    booking_id character varying,
    guest_id character varying,
    transaction_id character varying,
    room_number text,
    category text DEFAULT 'room_booking'::text NOT NULL,
    description text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    payment_method text,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    source_type text DEFAULT 'auto'::text NOT NULL,
    created_by character varying,
    created_by_name text,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: room_nights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_nights (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    unit_id character varying NOT NULL,
    date date NOT NULL,
    booking_id character varying NOT NULL,
    tenant_id character varying,
    property_id character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: room_preparation_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_preparation_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    guest_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    room_number text NOT NULL,
    occasion_type text NOT NULL,
    decoration_style text,
    add_ons text[],
    notes text,
    budget_range text DEFAULT 'medium'::text NOT NULL,
    custom_budget integer,
    preferred_datetime timestamp without time zone,
    reference_image_url text,
    price integer,
    status text DEFAULT 'pending'::text NOT NULL,
    staff_assigned character varying,
    admin_notes text,
    rejection_reason text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    owner_id character varying,
    property_id character varying,
    tenant_id character varying
);


--
-- Name: room_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    booking_id character varying NOT NULL,
    temperature integer DEFAULT 22,
    lights_on boolean DEFAULT false,
    lights_brightness integer DEFAULT 50,
    curtains_open boolean DEFAULT false,
    jacuzzi_on boolean DEFAULT false,
    jacuzzi_temperature integer DEFAULT 38,
    welcome_mode boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT now(),
    door_locked boolean DEFAULT true,
    curtains_position integer DEFAULT 0,
    bathroom_lights_on boolean DEFAULT false,
    bathroom_lights_brightness integer DEFAULT 50,
    hall_lights_on boolean DEFAULT false,
    hall_lights_brightness integer DEFAULT 50,
    non_dimmable_lights_on boolean DEFAULT false,
    tenant_id character varying
);


--
-- Name: service_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    guest_id character varying NOT NULL,
    booking_id character varying NOT NULL,
    room_number text NOT NULL,
    request_type text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'normal'::text,
    assigned_to character varying,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    owner_id character varying,
    property_id character varying,
    tenant_id character varying
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: staff_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_feedback (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    staff_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    type text NOT NULL,
    reason text,
    score_impact real NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: staff_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_invitations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    owner_id character varying NOT NULL,
    email text NOT NULL,
    staff_role text DEFAULT 'front_desk'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    invited_by character varying NOT NULL,
    accepted_by character varying,
    invite_token text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: staff_message_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_message_status (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying NOT NULL,
    staff_id character varying NOT NULL,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone
);


--
-- Name: staff_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    sender_role text DEFAULT 'owner'::text NOT NULL,
    sender_id character varying NOT NULL,
    message_text text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: staff_performance_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_performance_scores (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    staff_id character varying NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    message_response_score real DEFAULT 0,
    task_completion_score real DEFAULT 0,
    service_quality_score real DEFAULT 0,
    activity_score real DEFAULT 0,
    manual_adjustment real DEFAULT 0,
    total_score real DEFAULT 0,
    period text NOT NULL,
    calculated_at timestamp without time zone DEFAULT now()
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    plan_type text DEFAULT 'basic'::text NOT NULL,
    feature_flags jsonb DEFAULT '{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}'::jsonb,
    max_properties integer DEFAULT 1,
    max_units_per_property integer DEFAULT 50,
    start_date timestamp without time zone DEFAULT now(),
    end_date timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    tenant_id character varying,
    trial_ends_at timestamp without time zone,
    smart_plan_type text DEFAULT 'none'::text,
    max_staff integer DEFAULT 5,
    multi_property boolean DEFAULT false,
    performance_enabled boolean DEFAULT false,
    staff_performance_enabled boolean DEFAULT false,
    advanced_analytics boolean DEFAULT false,
    priority_support boolean DEFAULT false,
    custom_integrations boolean DEFAULT false,
    smart_rooms_enabled boolean DEFAULT false,
    guest_management boolean DEFAULT true,
    staff_management boolean DEFAULT false,
    plan_code text DEFAULT 'CORE_STARTER'::text,
    status text DEFAULT 'active'::text NOT NULL,
    current_period_start timestamp without time zone DEFAULT now(),
    current_period_end timestamp without time zone,
    auto_renew boolean DEFAULT true NOT NULL,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    failed_payment_attempts integer DEFAULT 0 NOT NULL,
    last_payment_order_id character varying,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: tax_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_configurations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    hotel_id character varying NOT NULL,
    tenant_id character varying,
    name text NOT NULL,
    code text NOT NULL,
    rate integer NOT NULL,
    is_inclusive boolean DEFAULT false,
    applies_to text[],
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    property_id character varying NOT NULL,
    owner_id character varying NOT NULL,
    unit_number text NOT NULL,
    unit_type text DEFAULT 'room'::text NOT NULL,
    name text,
    floor integer,
    capacity integer DEFAULT 2,
    description text,
    amenities text[],
    price_per_night integer,
    status text DEFAULT 'available'::text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    unit_category text DEFAULT 'accommodation'::text NOT NULL,
    tenant_id character varying
);


--
-- Name: usage_meters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_meters (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    metric_type text NOT NULL,
    current_value integer DEFAULT 0 NOT NULL,
    max_allowed integer NOT NULL,
    last_updated timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text DEFAULT 'guest'::text NOT NULL,
    full_name text NOT NULL,
    email text,
    phone text,
    avatar_url text,
    created_at timestamp without time zone DEFAULT now(),
    hotel_id character varying,
    language text DEFAULT 'en'::text,
    phone_country_code text,
    owner_id character varying,
    property_id character varying,
    tenant_id character varying,
    referral_code text
);


--
-- Name: waiter_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waiter_calls (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    property_id character varying NOT NULL,
    booking_id character varying,
    table_number character varying,
    room_number character varying,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    called_at timestamp without time zone DEFAULT now(),
    acknowledged_at timestamp without time zone,
    acknowledged_by character varying
);


--
-- Name: white_label_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.white_label_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying NOT NULL,
    logo_url text,
    favicon_url text,
    primary_color text,
    secondary_color text,
    accent_color text,
    custom_domain text,
    company_name text,
    hide_branding boolean DEFAULT false,
    custom_css text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    tenant_id character varying
);


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 FOR VALUES IN ('subscription-renewal-check');


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 FOR VALUES IN ('__pgboss__send-it');


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 FOR VALUES IN ('night-audit-cron');


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 FOR VALUES IN ('payment-retry');


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b FOR VALUES IN ('night-audit');


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 FOR VALUES IN ('database-backup');


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 FOR VALUES IN ('subscription-renewal');


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260; Type: TABLE ATTACH; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job ATTACH PARTITION pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 FOR VALUES IN ('database-backup-schedule');


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	86843c8dee670d9f1201585a8aeb4a911f49be6ae6d6bd925e769bb3860aac3e	1772443702456
2	cf1672a51b37665303b5131b3421b8c6caee5bf8ec60cdafd2cc3b89ed46f192	1772443835335
3	4790a4124bb4a0b2bb6c6846701b396a5f13d23a89ecbce64ad69a5d3d32b5de	1772447166837
4	0be6af1d753eec0e3073d8ac0214e3d70bb986d4feeea847ae3afed3f0d74bfc	1772455000000
5	981c49b104a613801389ec3dec561c26f0b7fb910f0061f06e69d290dc3a97a5	1772627000000
6	c9bce104ff6c420a7ce3d2be69b013b394340943eac1491a7d324e8e1bcf7134	1772628000000
7	b177afe341c3b5063444833ebe8e81ffee1f4ed3a4d132a25bd1b42cbc93052b	1772632000000
8	715bcae96ad365c1d30db8df82802e0a4269acefb3a6c53b6dbdbaf888731db4	1772730000000
9	46c34b661eeff6cd874ab721e26ebbb580d6d2ee86c8d746341ea236e4e7123e	1772810000000
10	319e0607699cc9e4e94aa8cf105042d3457ebaca665e38e604b05d46ace9e3de	1772900000000
11	79810700cd19c79121dc1bba96fc13951010362e6abed4ba9062314f1b93a55b	1772986000000
12	4cb3c495fdd659a3d9aa9975e022e3554f37846d31884ca1759026ca7feb95e1	1773072000000
13	324f755fd11ff994f5845f27273725b51486253ac85c7edf46d5d7087f9e96b2	1773158000000
14	f029878a68fb8509bbe65a169c5463ec1d88ca7467510d627a14540a7208eee7	1774483574000
15	d5f446522add8afa8a7ec2ab2c9ae7d163db79664562264c44113d0f60de00f9	1774900000000
16	07d8bb11d19fd7b3447a9b69250f08b296192bd8ab63738963f4bce6133010fc	1774990000000
17	e48ac5b0bae5bb1f6f07312c2484d85814b86d22680213ac773ceb48cc4b5f55	1775100000000
18	7b819193debabaa8d81d61c0937b1e329aadcc1ea07faf583042290e5517ad79	1775200000000
19	97b6d56e99f74e2ac9d6eedf17abfe42e41f11d39ec6fa80bdecc229728faade	1775390209000
20	eada63e0825a6afe1ab9a2d619f375e8451c295d93a5afcdffbad7880c93197b	1775500000000
21	0815cb582f666c8c5346be97acbdc8922ea166afb3ed3e36de1e4a14225892fd	1775600000000
22	bffc8144bf13d1a4266843209f222fdad2476aa946c59e1b8c3235d21dc52bf0	1775700000000
\.


--
-- Data for Name: archive; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.archive (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy, archived_on) FROM stdin;
\.


--
-- Data for Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
\.


--
-- Data for Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
5277d6e4-6f93-4c63-a596-d23ce79c3505	__pgboss__send-it	0	{"data": {}, "name": "night-audit-cron"}	completed	3	0	30	f	2026-05-07 22:00:01.366844+00	2026-05-07 22:00:01.940922+00	night-audit-cron	2026-05-07 22:00:00	00:05:00	2026-05-07 22:00:01.366844+00	2026-05-07 22:00:01.951004+00	2026-05-14 22:00:01.366844+00	\N	\N	standard
5722e9d0-ee03-415c-8a16-223a4e820e12	__pgboss__send-it	0	{"tz": "Asia/Baku", "data": {}, "name": "database-backup"}	completed	3	0	30	f	2026-05-07 23:00:01.441614+00	2026-05-07 23:00:02.336315+00	database-backup	2026-05-07 23:00:00	00:05:00	2026-05-07 23:00:01.441614+00	2026-05-07 23:00:02.345651+00	2026-05-14 23:00:01.441614+00	\N	\N	standard
771b41c1-4806-400a-8411-11a6126d55fc	__pgboss__send-it	0	{"tz": "Asia/Baku", "data": {}, "name": "database-backup-schedule"}	completed	3	0	30	f	2026-05-07 23:00:01.441614+00	2026-05-07 23:00:02.336315+00	database-backup-schedule	2026-05-07 23:00:00	00:05:00	2026-05-07 23:00:01.441614+00	2026-05-07 23:00:02.345651+00	2026-05-14 23:00:01.441614+00	\N	\N	standard
\.


--
-- Data for Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
6f178786-3aee-42c3-abff-3079a985d9cc	night-audit-cron	0	{}	completed	3	0	30	f	2026-05-07 22:00:01.945416+00	2026-05-07 22:00:03.652337+00	\N	\N	00:05:00	2026-05-07 22:00:01.945416+00	2026-05-07 22:00:03.957577+00	2026-05-14 22:00:01.945416+00	\N	\N	standard
\.


--
-- Data for Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
\.


--
-- Data for Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
10aedc9c-f9a4-4789-9e58-d3e27061a003	night-audit	0	{"hotelId": "4b678775-1fb6-4b29-aeb6-66efd36254a6", "tenantId": "4b678775-1fb6-4b29-aeb6-66efd36254a6"}	failed	2	2	60	f	2026-05-07 22:02:05.794597+00	2026-05-07 22:02:07.680681+00	\N	\N	01:00:00	2026-05-07 22:00:03.709977+00	2026-05-07 22:02:07.733298+00	2026-05-14 22:00:03.709977+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
5ece7082-a448-41af-b2b6-a7d66a79f7a3	night-audit	0	{"hotelId": "92be9bf5-6d03-4993-9478-a6d838398a46", "tenantId": "92be9bf5-6d03-4993-9478-a6d838398a46"}	failed	2	2	60	f	2026-05-07 22:02:11.676435+00	2026-05-07 22:02:13.68276+00	\N	\N	01:00:00	2026-05-07 22:00:03.729234+00	2026-05-07 22:02:13.687081+00	2026-05-14 22:00:03.729234+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
1e24210b-3dd5-491e-b239-9730b2ed01ba	night-audit	0	{"hotelId": "f79cf4d0-8944-4d83-9ced-976073ae2824", "tenantId": "f79cf4d0-8944-4d83-9ced-976073ae2824"}	failed	2	2	60	f	2026-05-07 22:02:17.67082+00	2026-05-07 22:02:17.684076+00	\N	\N	01:00:00	2026-05-07 22:00:03.744034+00	2026-05-07 22:02:17.689729+00	2026-05-14 22:00:03.744034+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
98d33697-4b33-413c-8625-e8a779497795	night-audit	0	{"hotelId": "f2085959-093d-4e61-9229-f38841a56f9e", "tenantId": "f2085959-093d-4e61-9229-f38841a56f9e"}	failed	2	2	60	f	2026-05-07 22:02:23.671614+00	2026-05-07 22:02:23.684967+00	\N	\N	01:00:00	2026-05-07 22:00:03.763194+00	2026-05-07 22:02:23.689807+00	2026-05-14 22:00:03.763194+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
e701b93c-4731-4bae-b7b3-cd965a15d696	night-audit	0	{"hotelId": "c7ebef61-6fbc-438f-8a44-639d53fcc58d", "tenantId": "c7ebef61-6fbc-438f-8a44-639d53fcc58d"}	failed	2	2	60	f	2026-05-07 22:02:35.675153+00	2026-05-07 22:02:35.688962+00	\N	\N	01:00:00	2026-05-07 22:00:03.941241+00	2026-05-07 22:02:35.694332+00	2026-05-14 22:00:03.941241+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
93c70e00-4ea3-4c74-b6b3-af45a34984a2	night-audit	0	{"hotelId": "aa05c231-e9bf-4141-95fe-e570bd70953d", "tenantId": "aa05c231-e9bf-4141-95fe-e570bd70953d"}	failed	2	2	60	f	2026-05-07 22:02:07.667839+00	2026-05-07 22:02:09.681215+00	\N	\N	01:00:00	2026-05-07 22:00:03.713416+00	2026-05-07 22:02:09.68571+00	2026-05-14 22:00:03.713416+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
42ea8495-18d4-43c1-acae-980a3f20d814	night-audit	0	{"hotelId": "37e5945d-ac5f-42a5-9a1e-c29a6fdf668c", "tenantId": "37e5945d-ac5f-42a5-9a1e-c29a6fdf668c"}	failed	2	2	60	f	2026-05-07 22:02:13.668233+00	2026-05-07 22:02:15.68359+00	\N	\N	01:00:00	2026-05-07 22:00:03.740856+00	2026-05-07 22:02:15.687606+00	2026-05-14 22:00:03.740856+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
28480aa5-2a9a-431b-9f18-9b97a62247f5	night-audit	0	{"hotelId": "13bb4267-9856-4790-9c33-02b989ffbbc9", "tenantId": "13bb4267-9856-4790-9c33-02b989ffbbc9"}	failed	2	2	60	f	2026-05-07 22:02:09.681643+00	2026-05-07 22:02:11.68233+00	\N	\N	01:00:00	2026-05-07 22:00:03.716705+00	2026-05-07 22:02:11.696385+00	2026-05-14 22:00:03.716705+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
8da03339-9ed9-440b-8380-90e745b8198d	night-audit	0	{"hotelId": "20bf763c-1652-43af-ab4a-b91567b85f9a", "tenantId": "20bf763c-1652-43af-ab4a-b91567b85f9a"}	failed	2	2	60	f	2026-05-07 22:02:25.671709+00	2026-05-07 22:02:25.685925+00	\N	\N	01:00:00	2026-05-07 22:00:03.775314+00	2026-05-07 22:02:25.690981+00	2026-05-14 22:00:03.775314+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
3963469a-e7b4-433e-a05c-1a7af3b146df	night-audit	0	{"hotelId": "86d04359-dc5e-4b08-86f7-d45bf449188a", "tenantId": "86d04359-dc5e-4b08-86f7-d45bf449188a"}	failed	2	2	60	f	2026-05-07 22:02:41.677886+00	2026-05-07 22:02:41.69033+00	\N	\N	01:00:00	2026-05-07 22:00:03.952152+00	2026-05-07 22:02:41.694521+00	2026-05-14 22:00:03.952152+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
243b9ce5-5f6d-4cbb-86bb-4b54b0467ec4	night-audit	0	{"hotelId": "e807c861-3c3e-41ed-b4d3-89dbe5020c2c", "tenantId": "e807c861-3c3e-41ed-b4d3-89dbe5020c2c"}	failed	2	2	60	f	2026-05-07 22:02:19.670413+00	2026-05-07 22:02:19.683348+00	\N	\N	01:00:00	2026-05-07 22:00:03.756425+00	2026-05-07 22:02:19.688165+00	2026-05-14 22:00:03.756425+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
bfb1c592-644f-4664-8f4f-d02712bc74af	night-audit	0	{"hotelId": "24d1573c-c810-485c-a2f9-cc1d0ef3dfb2", "tenantId": "24d1573c-c810-485c-a2f9-cc1d0ef3dfb2"}	failed	2	2	60	f	2026-05-07 22:02:31.675904+00	2026-05-07 22:02:31.686558+00	\N	\N	01:00:00	2026-05-07 22:00:03.93317+00	2026-05-07 22:02:31.691654+00	2026-05-14 22:00:03.93317+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
2be3c45b-12b9-4a93-a650-5521d6463b2e	night-audit	0	{"hotelId": "92cf194e-6096-4945-94a3-a005d1b3f822", "tenantId": "92cf194e-6096-4945-94a3-a005d1b3f822"}	failed	2	2	60	f	2026-05-07 22:02:37.676846+00	2026-05-07 22:02:37.68993+00	\N	\N	01:00:00	2026-05-07 22:00:03.94456+00	2026-05-07 22:02:37.693567+00	2026-05-14 22:00:03.94456+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
e0273f7f-7ebb-4919-94f0-30432929e211	night-audit	0	{"hotelId": "46ae92e5-9940-4b90-a5af-7fad98148a6a", "tenantId": "46ae92e5-9940-4b90-a5af-7fad98148a6a"}	failed	2	2	60	f	2026-05-07 22:02:39.676929+00	2026-05-07 22:02:39.689988+00	\N	\N	01:00:00	2026-05-07 22:00:03.948892+00	2026-05-07 22:02:39.695053+00	2026-05-14 22:00:03.948892+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
b9e02ce8-d773-44ba-be2e-6975ac8f902c	night-audit	0	{"hotelId": "df0a1f3a-869f-455a-913c-5595c65e61f7", "tenantId": "df0a1f3a-869f-455a-913c-5595c65e61f7"}	failed	2	2	60	f	2026-05-07 22:02:21.671898+00	2026-05-07 22:02:21.684522+00	\N	\N	01:00:00	2026-05-07 22:00:03.759823+00	2026-05-07 22:02:21.690145+00	2026-05-14 22:00:03.759823+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
3c283507-e393-40cd-946c-89bba2df18c6	night-audit	0	{"hotelId": "7577111e-642c-4e59-a839-6686f47c5256", "tenantId": "7577111e-642c-4e59-a839-6686f47c5256"}	failed	2	2	60	f	2026-05-07 22:02:29.674088+00	2026-05-07 22:02:29.685721+00	\N	\N	01:00:00	2026-05-07 22:00:03.782071+00	2026-05-07 22:02:29.692092+00	2026-05-14 22:00:03.782071+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
37bb0cea-7108-4a38-9610-5d136f3aee86	night-audit	0	{"hotelId": "afdcc6cc-9212-4bd9-9bd2-403c0f824513", "tenantId": "afdcc6cc-9212-4bd9-9bd2-403c0f824513"}	failed	2	2	60	f	2026-05-07 22:02:27.673523+00	2026-05-07 22:02:27.686074+00	\N	\N	01:00:00	2026-05-07 22:00:03.778746+00	2026-05-07 22:02:27.690019+00	2026-05-14 22:00:03.778746+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
4aef2dfc-65f6-4c96-8637-cf0b9c09a439	night-audit	0	{"hotelId": "ff6d2516-815b-40ae-ac7b-cf7a086dbaa0", "tenantId": "ff6d2516-815b-40ae-ac7b-cf7a086dbaa0"}	failed	2	2	60	f	2026-05-07 22:02:33.674866+00	2026-05-07 22:02:33.688319+00	\N	\N	01:00:00	2026-05-07 22:00:03.937218+00	2026-05-07 22:02:33.69375+00	2026-05-14 22:00:03.937218+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
3fb559db-14dc-4b3d-8c08-48e824616938	night-audit	0	{"hotelId": "608e066b-3d9a-49dc-a3d3-27468d4af9b2", "tenantId": "608e066b-3d9a-49dc-a3d3-27468d4af9b2"}	failed	2	2	60	f	2026-05-07 22:02:43.678429+00	2026-05-07 22:02:43.690265+00	\N	\N	01:00:00	2026-05-07 22:00:03.955024+00	2026-05-07 22:02:43.703325+00	2026-05-14 22:00:03.955024+00	{"name": "TypeError", "stack": "TypeError: Cannot destructure property 'hotelId' of 'job.data' as it is undefined.\\n    at <anonymous> (/home/runner/workspace/server/workers/nightAuditWorker.ts:27:13)\\n    at Worker.onFetch (/home/runner/workspace/node_modules/pg-boss/src/manager.js:216:51)\\n    at Worker.start (/home/runner/workspace/node_modules/pg-boss/src/worker.js:58:22)\\n    at process.processTicksAndRejections (node:internal/process/task_queues:95:5)", "message": "Cannot destructure property 'hotelId' of 'job.data' as it is undefined."}	\N	standard
\.


--
-- Data for Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
6a53e27b-1eb1-4108-8759-3c9b05341cb2	database-backup	0	{}	active	3	0	30	f	2026-05-07 23:00:02.340829+00	2026-05-07 23:00:04.196215+00	\N	\N	00:05:00	2026-05-07 23:00:02.340829+00	\N	2026-05-14 23:00:02.340829+00	\N	\N	standard
\.


--
-- Data for Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
\.


--
-- Data for Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 (id, name, priority, data, state, retry_limit, retry_count, retry_delay, retry_backoff, start_after, started_on, singleton_key, singleton_on, expire_in, created_on, completed_on, keep_until, output, dead_letter, policy) FROM stdin;
0400b8a4-232f-4753-a6cf-4ecb4c71ce04	database-backup-schedule	0	{}	created	3	0	30	f	2026-05-07 23:00:02.340829+00	\N	\N	\N	00:05:00	2026-05-07 23:00:02.340829+00	\N	2026-05-14 23:00:02.340829+00	\N	\N	standard
\.


--
-- Data for Name: queue; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.queue (name, policy, retry_limit, retry_delay, retry_backoff, expire_seconds, retention_minutes, dead_letter, partition_name, created_on, updated_on) FROM stdin;
__pgboss__send-it	standard	\N	\N	\N	\N	\N	\N	j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3	2026-03-02 09:38:06.124941+00	2026-03-02 09:38:06.124941+00
subscription-renewal	standard	\N	\N	\N	\N	\N	\N	jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989	2026-03-05 14:53:40.272792+00	2026-03-05 14:53:40.272792+00
subscription-renewal-check	standard	\N	\N	\N	\N	\N	\N	j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21	2026-03-05 14:53:40.444367+00	2026-03-05 14:53:40.444367+00
payment-retry	standard	\N	\N	\N	\N	\N	\N	j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94	2026-03-05 15:02:10.566115+00	2026-03-05 15:02:10.566115+00
database-backup	standard	\N	\N	\N	\N	\N	\N	j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571	2026-03-05 16:14:39.164244+00	2026-03-05 16:14:39.164244+00
database-backup-schedule	standard	\N	\N	\N	\N	\N	\N	jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260	2026-03-05 16:14:39.272611+00	2026-03-05 16:14:39.272611+00
night-audit	standard	\N	\N	\N	\N	\N	\N	j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b	2026-03-23 16:29:59.280466+00	2026-03-23 16:29:59.280466+00
night-audit-cron	standard	\N	\N	\N	\N	\N	\N	j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7	2026-03-23 16:29:59.377567+00	2026-03-23 16:29:59.377567+00
\.


--
-- Data for Name: schedule; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.schedule (name, cron, timezone, data, options, created_on, updated_on) FROM stdin;
subscription-renewal-check	0 6 * * *	Asia/Baku	{}	{"tz": "Asia/Baku"}	2026-03-05 14:53:40.480428+00	2026-05-07 20:27:01.541086+00
database-backup	0 3 * * *	Asia/Baku	{}	{"tz": "Asia/Baku"}	2026-03-05 16:15:44.66649+00	2026-05-07 20:27:01.554478+00
night-audit-cron	0 22 * * *	UTC	{}	{}	2026-03-23 16:29:59.401298+00	2026-05-07 20:27:01.569095+00
database-backup-schedule	0 3 * * *	Asia/Baku	{}	{"tz": "Asia/Baku"}	2026-03-05 16:14:39.29528+00	2026-03-05 16:14:39.29528+00
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.subscription (event, name, created_on, updated_on) FROM stdin;
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: pgboss; Owner: -
--

COPY pgboss.version (version, maintained_on, cron_on, monitored_on) FROM stdin;
24	2026-05-07 22:59:01.238415+00	2026-05-07 23:00:01.408335+00	\N
\.


--
-- Data for Name: analytics_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_snapshots (id, owner_id, property_id, snapshot_type, period, data, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: api_usage_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_usage_logs (id, tenant_id, endpoint, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, owner_id, property_id, user_id, user_role, action, entity_type, entity_id, description, previous_values, new_values, ip_address, user_agent, created_at, tenant_id) FROM stdin;
a8cd7acc-f9f3-417f-bf2f-b6aea7321494	\N	\N	00d0a7ca-27e4-417a-9274-b16597f0cab0	\N	user_logout	user	00d0a7ca-27e4-417a-9274-b16597f0cab0	User logged out	\N	\N	\N	\N	2026-02-28 13:16:12.713062	\N
23c8ff9b-002e-4646-837b-4815845f19a2	11e77135-6f73-422d-8b48-244d2137c1e6	\N	ff5b544d-40fe-49f4-8325-34a99146bca0	owner_admin	user_login	user	ff5b544d-40fe-49f4-8325-34a99146bca0	User admin_demo logged in	\N	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-04-29 09:45:51.585437	\N
5641063b-993f-4b19-bff1-99280f9a95da	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-05-04 16:03:53.572777	\N
7f538148-092a-4805-9093-0e1579def672	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-05-05 09:27:31.059182	\N
ce0f2cd2-5da1-4b7f-8ce7-038fbea64b01	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-05-05 09:27:46.047392	\N
df4f100b-24fb-4f7f-9945-1bb679b4aa63	\N	\N	demo_staff_1	admin	user_login	user	demo_staff_1	User demo_staff logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-13 14:52:08.561364	\N
3bfd83d8-8f58-4b5c-b8ea-eff6eb13342f	\N	\N	0803ee24-dc71-430a-9b76-4d4885a624be	guest	user_login	user	0803ee24-dc71-430a-9b76-4d4885a624be	User GUEST-474089Y1J logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-13 17:21:53.54921	\N
f548b865-92cb-4acc-aeb8-737b5406a483	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	10.81.0.79	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-27 11:27:56.030195	\N
057519a3-9dd7-4cf4-ad2b-8b1bf650332d	87772a76-ada5-4dc6-bacf-9e949d17ffc6	\N	1a992ff9-d50f-4ec3-9721-12560d2c0e62	owner_admin	user_login	user	1a992ff9-d50f-4ec3-9721-12560d2c0e62	User testadmin_lvPwUO logged in	\N	\N	10.81.8.109	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-02-14 14:41:58.480455	\N
7086d136-dd5a-43eb-abfc-18cf88301c7c	87772a76-ada5-4dc6-bacf-9e949d17ffc6	\N	1a992ff9-d50f-4ec3-9721-12560d2c0e62	owner_admin	staff_created	user	da401877-b991-474d-a193-acba0451280c	Created Reception Test OQi8 as front_desk for property Test Hotel	\N	\N	\N	\N	2026-02-14 14:43:20.888734	\N
dee4b618-7c23-48ec-99f4-85897904d400	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	10.81.0.79	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-28 13:16:19.697658	\N
2e5b39c4-5abb-42cc-b807-4ed587e2652f	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	10.81.0.129	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-02-19 07:00:20.033076	\N
42c8162b-19d9-4f4c-9bc6-608427644117	\N	\N	496c7a53-8626-4252-9c54-dd65e6b99f71	\N	user_logout	user	496c7a53-8626-4252-9c54-dd65e6b99f71	User logged out	\N	\N	\N	\N	2026-03-04 13:43:02.036839	\N
4cf338ef-306a-4bdc-a008-73b706d70173	afa0de93-1326-4fe4-a339-f65121ba4bcb	\N	8317f3c8-f1f9-4b9f-8570-25968af7ef28	owner_admin	user_login	user	8317f3c8-f1f9-4b9f-8570-25968af7ef28	User test7 logged in	\N	\N	10.81.1.43	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-19 16:41:34.049993	\N
fc5e258a-f42a-49eb-ad6d-b5374df16b26	afa0de93-1326-4fe4-a339-f65121ba4bcb	\N	8317f3c8-f1f9-4b9f-8570-25968af7ef28	owner_admin	staff_invited	staff_invitation	df71356f-946e-480c-b13d-c595500d2296	Invited ramin.v@orange-studio.az as front_desk to property tt	\N	\N	\N	\N	2026-02-19 16:42:15.151382	\N
39aae78f-28d3-412b-9a85-f87d21ad76b6	\N	\N	8317f3c8-f1f9-4b9f-8570-25968af7ef28	\N	user_logout	user	8317f3c8-f1f9-4b9f-8570-25968af7ef28	User logged out	\N	\N	\N	\N	2026-02-19 16:42:45.11221	\N
1c7ae114-cb9c-417a-8eb4-09d73d50d1f8	02d18ce6-ec09-48c3-948e-741eeceaee86	\N	cedfcf50-2d94-4699-9dd1-1a1b11c14824	owner_admin	user_login	user	cedfcf50-2d94-4699-9dd1-1a1b11c14824	User test8 logged in	\N	\N	10.81.8.75	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-19 16:43:43.937806	\N
2e197666-4fb2-44d0-b7a2-4627840be170	\N	\N	cedfcf50-2d94-4699-9dd1-1a1b11c14824	\N	user_logout	user	cedfcf50-2d94-4699-9dd1-1a1b11c14824	User logged out	\N	\N	\N	\N	2026-02-19 16:46:35.343076	\N
fce50c43-5921-431b-ad9c-e76559b1afb7	6dec171d-d048-47d4-a5d4-1476a7b5390a	\N	85d0d02e-5942-47c4-929a-62479c70a788	owner_admin	user_login	user	85d0d02e-5942-47c4-929a-62479c70a788	User test9 logged in	\N	\N	10.81.1.43	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-19 17:06:08.479383	\N
b17ff769-10bd-4a4e-9322-a8148735b3e3	\N	\N	85d0d02e-5942-47c4-929a-62479c70a788	\N	user_logout	user	85d0d02e-5942-47c4-929a-62479c70a788	User logged out	\N	\N	\N	\N	2026-02-19 17:07:33.665907	\N
96fcd0a4-5553-459f-8007-5487159cf759	495c33fe-a392-439a-aec7-39d639d8b45c	\N	e9dd6201-3d01-4316-9baf-f6ac3cfe0a35	owner_admin	user_login	user	e9dd6201-3d01-4316-9baf-f6ac3cfe0a35	User test11 logged in	\N	\N	10.81.10.159	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-19 17:39:01.070882	\N
fac30369-f82c-483a-b083-a536b04be0a2	\N	\N	e9dd6201-3d01-4316-9baf-f6ac3cfe0a35	\N	user_logout	user	e9dd6201-3d01-4316-9baf-f6ac3cfe0a35	User logged out	\N	\N	\N	\N	2026-02-19 17:41:33.842524	\N
4322e501-a36b-4a5b-bde9-8ca03e7c6fb6	a8d4b603-ad1a-4807-ad4d-d992076c5892	\N	da4e4e54-8610-4535-bbd9-de375e9f4337	owner_admin	user_login	user	da4e4e54-8610-4535-bbd9-de375e9f4337	User test12 logged in	\N	\N	10.81.1.43	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-19 18:40:23.266871	\N
9420c897-c6b1-4a4d-9dc4-00698d788f44	\N	\N	da4e4e54-8610-4535-bbd9-de375e9f4337	\N	user_logout	user	da4e4e54-8610-4535-bbd9-de375e9f4337	User logged out	\N	\N	\N	\N	2026-02-19 18:40:59.913177	\N
fc4977bd-3d5c-4973-b055-33269d1c96b6	ac506214-8952-45da-97f0-0e771f8543a2	\N	67909c91-a893-46f1-ba80-6d668fbe1d6d	owner_admin	user_login	user	67909c91-a893-46f1-ba80-6d668fbe1d6d	User test55 logged in	\N	\N	10.81.14.63	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 06:40:24.026141	\N
5f69447e-7385-46c0-9d1b-6f671f8d44a4	\N	\N	67909c91-a893-46f1-ba80-6d668fbe1d6d	\N	user_logout	user	67909c91-a893-46f1-ba80-6d668fbe1d6d	User logged out	\N	\N	\N	\N	2026-02-20 07:16:52.322693	\N
d945f508-16e9-4243-be8d-39ae9639db16	e333d1d7-db91-4f5a-a85b-f78b25df2b53	\N	a420736f-75ef-42f7-bd37-b97a743f56e7	owner_admin	user_login	user	a420736f-75ef-42f7-bd37-b97a743f56e7	User test66 logged in	\N	\N	10.81.6.182	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 07:49:52.400245	\N
6b8e19eb-4fcb-4602-90ad-3db578b5c723	\N	\N	a420736f-75ef-42f7-bd37-b97a743f56e7	\N	user_logout	user	a420736f-75ef-42f7-bd37-b97a743f56e7	User logged out	\N	\N	\N	\N	2026-02-20 08:17:08.898602	\N
f9a03ab2-9781-40c9-8358-c22caf9d93f6	bc78df31-2b2a-4daa-a3d8-51a0ca8baa10	\N	375adbfa-a298-4a4c-acf9-94809174ac14	owner_admin	user_login	user	375adbfa-a298-4a4c-acf9-94809174ac14	User testpro_9jBjzA logged in	\N	\N	10.81.6.182	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-02-20 08:50:44.472998	\N
94d7766e-e02b-4e57-b901-f06705692c31	11e77135-6f73-422d-8b48-244d2137c1e6	\N	ff5b544d-40fe-49f4-8325-34a99146bca0	owner_admin	user_login	user	ff5b544d-40fe-49f4-8325-34a99146bca0	User admin_demo logged in	\N	\N	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-04-29 09:47:43.274445	\N
8776595d-e409-4f67-8070-4e3ac60b4e23	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-05-04 16:04:36.944331	\N
b0663057-d99e-48dc-bdf4-065647fad220	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-05-05 09:51:10.43858	\N
7279be09-54d8-4bb4-af71-4ed357ba5cb1	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-05-05 09:51:16.533925	\N
6b68f1a0-4f54-4f7a-8920-2ea275615729	\N	\N	6fc6324a-76a0-4d9b-9da7-a03096e5484d	\N	user_logout	user	6fc6324a-76a0-4d9b-9da7-a03096e5484d	User logged out	\N	\N	\N	\N	2026-02-20 08:55:39.531058	\N
1359967e-1b52-48de-951b-df8c81b66681	\N	\N	af7ba19d-06c4-4490-bc91-fda1414802ed	\N	user_logout	user	af7ba19d-06c4-4490-bc91-fda1414802ed	User logged out	\N	\N	\N	\N	2026-02-20 09:24:47.083357	\N
8936d88f-8d45-408a-8188-0ad0d62528bc	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	owner_admin	user_login	user	8da0da3f-8e4a-4623-ac41-789ee316b827	User orta1 logged in	\N	\N	10.81.14.63	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 09:25:32.081169	\N
564bbac4-f3bf-4bfe-8360-5916434cd552	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	owner_admin	staff_invited	staff_invitation	07ad2ca1-da8d-4cf1-930e-56176c9cf2c3	Invited ramin.v@orange-studio.az as front_desk to property 3	\N	\N	\N	\N	2026-02-20 09:33:02.683329	\N
809621f5-8b7d-4486-b786-5da892d7529f	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	5928ad00-69b2-4c01-a6c5-5379c5110c4b	reception	staff_joined	user	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22 joined as front_desk via invitation	\N	\N	\N	\N	2026-02-20 09:34:09.752621	\N
3f508eb4-e1ba-4901-9ab8-e4d70ffa01ae	\N	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	\N	user_logout	user	8da0da3f-8e4a-4623-ac41-789ee316b827	User logged out	\N	\N	\N	\N	2026-02-20 09:35:48.32284	\N
b3d139a9-376e-43f9-9a21-780b895ed691	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	owner_admin	staff_invited	staff_invitation	c677f64b-26b6-4ae6-ac6a-7ed123bd27b4	Invited ramin.v@orange-studio.az as front_desk to property 3	\N	\N	\N	\N	2026-02-20 09:38:30.971154	\N
31f25b02-3cec-4d4a-9494-17d2539f95c2	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	b7c11396-9a5a-48a3-8443-9e2e199ac124	reception	staff_joined	user	b7c11396-9a5a-48a3-8443-9e2e199ac124	staff3 joined as front_desk via invitation	\N	\N	\N	\N	2026-02-20 09:39:26.142914	\N
a7f7e139-0f68-4e03-b1b2-4e0754dc07ca	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	\N	user_logout	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User logged out	\N	\N	\N	\N	2026-02-27 11:52:03.239709	\N
60d062dc-c54e-4b72-bd9b-828b32b24160	\N	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	\N	user_logout	user	8da0da3f-8e4a-4623-ac41-789ee316b827	User logged out	\N	\N	\N	\N	2026-02-20 10:01:17.413202	\N
c690a64b-7ba4-4867-8de5-734bb02b5368	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	5928ad00-69b2-4c01-a6c5-5379c5110c4b	reception	user_login	user	5928ad00-69b2-4c01-a6c5-5379c5110c4b	User staff22 logged in	\N	\N	10.81.15.50	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 10:01:47.24892	\N
b0bb6e31-be43-4c70-8af7-e8d4851e93b1	\N	\N	5928ad00-69b2-4c01-a6c5-5379c5110c4b	\N	user_logout	user	5928ad00-69b2-4c01-a6c5-5379c5110c4b	User logged out	\N	\N	\N	\N	2026-02-20 10:06:56.746335	\N
c5c99e11-f259-45ee-bb92-7e4658522fe5	\N	\N	254ef3be-573c-45a1-ad39-96cd40546b7d	guest	user_login	user	254ef3be-573c-45a1-ad39-96cd40546b7d	User GUEST-KLQX logged in	\N	\N	10.81.6.182	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 10:07:07.286286	\N
039af7f3-9d80-4cf2-bcfe-2e28d5b5d2fa	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	\N	user_logout	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User logged out	\N	\N	\N	\N	2026-02-28 14:13:00.51646	\N
e64b8238-c45b-4a2a-83a2-8ffed933a063	\N	\N	254ef3be-573c-45a1-ad39-96cd40546b7d	\N	user_logout	user	254ef3be-573c-45a1-ad39-96cd40546b7d	User logged out	\N	\N	\N	\N	2026-02-20 10:21:04.739377	\N
6d640936-48c4-4fec-b654-a40955a52bb1	\N	\N	81e76596-4329-4026-98e9-f2f040820245	guest	user_login	user	81e76596-4329-4026-98e9-f2f040820245	User GUEST-2FKT logged in	\N	\N	10.81.5.158	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 10:21:18.81313	\N
dccb58b1-8e68-4258-87f3-ac7dd9bd1724	\N	\N	5928ad00-69b2-4c01-a6c5-5379c5110c4b	\N	user_logout	user	5928ad00-69b2-4c01-a6c5-5379c5110c4b	User logged out	\N	\N	\N	\N	2026-02-20 10:22:32.252703	\N
0c48d19d-72ec-4370-9eee-c63e49cfe28c	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	owner_admin	user_login	user	8da0da3f-8e4a-4623-ac41-789ee316b827	User orta1 logged in	\N	\N	10.81.11.149	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 10:22:41.4503	\N
02213bcc-4ecb-41f2-b951-df43b8d90e8a	\N	\N	8da0da3f-8e4a-4623-ac41-789ee316b827	\N	user_logout	user	8da0da3f-8e4a-4623-ac41-789ee316b827	User logged out	\N	\N	\N	\N	2026-02-20 10:23:43.397599	\N
7abf80b0-1d84-4ec6-8aea-11a2f0bee5fe	7402ec1b-29e9-4041-86d5-711beacb39e7	\N	7e9c5281-144b-4a8f-8074-7f06a6fd7f50	owner_admin	user_login	user	7e9c5281-144b-4a8f-8074-7f06a6fd7f50	User test112 logged in	\N	\N	10.81.11.149	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 10:25:12.500481	\N
01459cc4-d4fc-44b5-8bbc-2c225242a540	\N	\N	7e9c5281-144b-4a8f-8074-7f06a6fd7f50	\N	user_logout	user	7e9c5281-144b-4a8f-8074-7f06a6fd7f50	User logged out	\N	\N	\N	\N	2026-02-20 10:27:42.279506	\N
bcd95ab3-29fb-46f7-8865-e22cda520936	\N	\N	7e9c5281-144b-4a8f-8074-7f06a6fd7f50	\N	user_logout	user	7e9c5281-144b-4a8f-8074-7f06a6fd7f50	User logged out	\N	\N	\N	\N	2026-02-20 10:28:57.729842	\N
1c28c98e-21fa-42be-88e2-32ed6b5437d9	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 10:31:26.597477	\N
f726640e-7ac5-4eda-b22b-ddebd23fe535	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	10.81.5.158	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-20 10:31:46.763946	\N
8f0c81a8-e01e-470f-922b-82f20320d78b	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 10:38:44.987322	\N
1d9738c7-1f0b-4458-8e9b-670ada861ff4	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 10:39:44.027992	\N
3d10f607-5cb5-4f63-9ad2-3d18d88c58b1	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 10:40:38.019731	\N
be3a43cc-b50f-48c1-8a18-727e90da1441	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 10:41:49.57796	\N
15406e91-5bcf-47d6-8e42-863a53559b37	\N	\N	81e76596-4329-4026-98e9-f2f040820245	\N	user_logout	user	81e76596-4329-4026-98e9-f2f040820245	User logged out	\N	\N	\N	\N	2026-02-20 11:08:11.097343	\N
249fe640-753c-4b68-80ce-ee8b25077b79	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	staff_deleted	user	b7c11396-9a5a-48a3-8443-9e2e199ac124	Deleted staff member staff3	\N	\N	\N	\N	2026-05-05 09:51:10.579916	\N
9361ecdc-4ad2-45fd-9bc3-383245574193	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 13:03:42.307028	\N
03440a1c-320d-4219-a485-d289a30b6062	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	oss_super_admin	user_login	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User oss_admin logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-20 13:19:11.550488	\N
ffa92f9e-70f3-46b8-b138-9751097cdf36	\N	\N	69d2ec0e-d832-4477-b631-c1d03de733ce	\N	user_logout	user	69d2ec0e-d832-4477-b631-c1d03de733ce	User logged out	\N	\N	\N	\N	2026-02-20 13:53:55.180637	\N
a8f667a8-955e-44fa-88e2-1b27a58119f2	\N	\N	9b1dfd0b-805b-4c70-abf9-329093db2892	guest	user_login	user	9b1dfd0b-805b-4c70-abf9-329093db2892	User GUEST-P4S7 logged in	\N	\N	10.81.2.76	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-02-24 11:55:07.490338	\N
250c76c9-7fb7-4f55-831f-bf70b4f27518	\N	\N	161bfeb3-c162-4917-b1d1-21c4a40e1446	guest	user_login	user	161bfeb3-c162-4917-b1d1-21c4a40e1446	User GUEST-NFKV logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-24 12:00:00.447906	\N
20146338-aa9f-44f7-b907-08ca3ed33ae6	\N	\N	c765f89e-a13c-41a1-8b8f-7dfac07d72d7	guest	user_login	user	c765f89e-a13c-41a1-8b8f-7dfac07d72d7	User GUEST-YYS9 logged in	\N	\N	10.81.2.76	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	2026-02-24 12:01:19.529868	\N
07bbc152-8e87-41f1-9b61-e7c5cf6f2d50	\N	\N	8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	guest	user_login	user	8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	User GUEST-G7ES logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-24 12:15:33.153581	\N
8d24d55d-23b5-49f2-b2bf-bc2ab42f8d72	\N	\N	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	guest	user_login	user	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	User GUEST-MP4F logged in	\N	\N	127.0.0.1	curl/8.14.1	2026-02-24 12:16:32.621813	\N
\.


--
-- Data for Name: billing_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_info (id, owner_id, stripe_customer_id, stripe_subscription_id, payment_method_last4, payment_method_brand, billing_email, billing_name, billing_address, current_period_start, current_period_end, cancel_at_period_end, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: billing_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_logs (id, tenant_id, hotel_id, owner_id, event_type, description, amount_usd, messages_added, package_name, status, created_at) FROM stdin;
\.


--
-- Data for Name: board_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_reports (id, reporter_name, region, title, content, contract_ids, period_start, period_end, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, guest_id, room_number, room_type, check_in_date, check_out_date, status, pre_checked_in, special_requests, created_at, booking_number, booking_source, number_of_guests, nationality, passport_number, special_notes, owner_id, property_id, unit_id, nightly_rate, total_price, currency, discount, tenant_id, travel_agency_name, date_of_birth, guest_address, arrival_time, pre_check_notes, rejection_reason, payment_status, guest_signature_base64, id_document_base64, rate_plan_id, deposit_amount, deposit_due_date, deposit_paid_at, paid_amount, remaining_balance, payment_method) FROM stdin;
07a20250-599d-4622-8177-a89636b29843	3e6b086d-382a-4ef2-b56c-ee5191701554	301	Standard	2026-04-01 14:00:00	2026-04-05 12:00:00	confirmed	f	\N	2026-02-24 11:35:53.48705	PAY-TEST-001	direct_website	\N	\N	\N	\N	\N	\N	\N	10000	40000	USD	\N	demo_session_3f0af152-9afc-4ef2-af0a-6cf8495bbfcc	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
e77f8cb2-35bf-488a-a50c-74704c693c93	9b1dfd0b-805b-4c70-abf9-329093db2892	401	Standard	2026-04-01 14:00:00	2026-04-05 12:00:00	confirmed	f	\N	2026-02-24 11:54:37.45684	CHECKIN-TEST-001	direct_website	\N	\N	\N	\N	\N	\N	\N	\N	\N	USD	\N	demo_session_54d883e0-d226-42eb-84df-bb19082f7e3f	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
443f65a3-aa8a-42f6-8dae-8c5900d8ba18	254ef3be-573c-45a1-ad39-96cd40546b7d	505	Standard	2026-02-20 00:00:00	2026-02-25 00:00:00	checked_in	f	\N	2026-02-20 10:04:09.654307	d3	booking_com	1	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	fb04e537-345b-4e39-9d19-959e2eded6dc	\N	15000	75000	USD	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
c648a0ed-4ec3-4610-b476-6305e7f12048	81e76596-4329-4026-98e9-f2f040820245	3	Standard	2026-02-20 14:25:00	2026-02-25 12:00:00	confirmed	f	\N	2026-02-20 10:18:42.257677	43	booking_com	23	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	fb04e537-345b-4e39-9d19-959e2eded6dc	\N	15000	75000	USD	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
9867f205-79fb-4853-a858-4cb4effaf631	f365edad-3a97-42f6-a549-a5ffa19348e0	202	deluxe	2026-05-06 13:54:50.286	2026-05-08 13:54:50.286	checked_in	f	Extra yastıq, gec yoxlama	2026-05-07 13:54:50.287367	\N	\N	2	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	25000	50000	USD	\N	\N	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
340a1d5f-f7a0-451e-b718-b67e7acd74a5	5ad56e5d-fd29-4876-b148-8d42424847e9	202	Standard	2026-03-01 14:00:00	2026-03-05 12:00:00	confirmed	f	\N	2026-02-24 11:00:32.420197	wea	booking_com	\N	\N	\N	\N	\N	\N	\N	\N	\N	USD	\N	demo_session_2879497c-67d8-4254-a824-fcbaea376064	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
fb36d454-1188-4c95-8f29-16b22baf9ca4	909320fe-e9b7-4490-91b6-6aad72ef9b0b	202	Standard	2026-03-03 14:00:00	2026-06-03 12:00:00	confirmed	f	\N	2026-02-24 11:01:23.113003	656	airbnb	\N	\N	\N	\N	\N	\N	\N	\N	\N	USD	\N	demo_session_2879497c-67d8-4254-a824-fcbaea376064	\N	\N	\N	\N	\N	\N	unpaid	\N	\N	\N	\N	\N	\N	0	\N	\N
352e587b-8bde-42fb-a6a1-91c950a5aede	161bfeb3-c162-4917-b1d1-21c4a40e1446	501	Standard	2026-04-10 14:00:00	2026-04-15 12:00:00	precheck_submitted	f	Extra pillow	2026-02-24 11:59:54.301928	API-TEST-001	direct_website	2	Azerbaijan	AZ1234567	\N	\N	\N	\N	\N	\N	USD	\N	demo_session_695830c5-05bd-4882-8eb6-cb868bdff80c	\N	1990-05-15	Baku	\N	\N	\N	unpaid	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==	\N	\N	\N	\N	\N	0	\N	\N
3201d4d2-c2d2-4b69-a97f-43d6cf727f77	c765f89e-a13c-41a1-8b8f-7dfac07d72d7	601	Standard	2026-05-01 14:00:00	2026-05-05 12:00:00	precheck_submitted	f	Late checkout please	2026-02-24 12:00:58.926873	E2E-CHECKIN-001	direct_website	1	Azerbaijan	E2E12345	\N	\N	\N	\N	\N	\N	USD	\N	demo_session_34e01e00-8509-47db-874b-3bbc6ed52284	\N	1985-03-20	Baku, AZ	\N	\N	\N	unpaid	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==	\N	\N	\N	\N	\N	0	\N	\N
e087a247-2820-43ac-a422-086647504685	8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	701	Standard	2026-06-01 14:00:00	2026-06-05 12:00:00	precheck_submitted	f	\N	2026-02-24 12:15:15.460464	CASE1-001	direct_website	\N	Azerbaijan	CASE1-PASS	\N	\N	\N	\N	\N	\N	USD	\N	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7	\N	1990-01-01	\N	\N	\N	\N	paid	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==	\N	\N	\N	\N	\N	0	\N	\N
96dff7ef-a6ef-43b8-89a9-6964ce2dd964	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	702	Standard	2026-06-10 14:00:00	2026-06-15 12:00:00	confirmed	f	\N	2026-02-24 12:16:11.892935	CASE2-001	direct_website	\N	Turkey	CASE2-PASS	\N	\N	\N	\N	\N	10000	USD	\N	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7	\N	1988-07-15	\N	\N	\N	\N	paid	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==	\N	\N	\N	\N	\N	0	\N	\N
\.


--
-- Data for Name: cancellation_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cancellation_policies (id, hotel_id, tenant_id, name, free_cancellation_hours, no_show_penalty_type, no_show_penalty_value, late_cancellation_penalty_type, late_cancellation_penalty_value, is_default, is_active, created_at) FROM stdin;
3e4301bc-f896-4879-a608-0624ab731e20	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	Standard Policy	48	percent	10000	percent	5000	t	t	2026-03-23 16:34:08.532573
\.


--
-- Data for Name: cash_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_accounts (id, hotel_id, property_id, owner_id, account_type, account_name, balance, currency, last_updated, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chart_of_accounts (id, hotel_id, tenant_id, account_code, account_name, account_type, parent_id, is_system, is_active, normal_balance, description, created_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, hotel_id, guest_id, sender_id, sender_role, message, created_at, property_id, thread_type, escalated_by, escalation_note, tenant_id) FROM stdin;
f9264020-abb4-40cd-93d0-990beabecf74	7577111e-642c-4e59-a839-6686f47c5256	254ef3be-573c-45a1-ad39-96cd40546b7d	254ef3be-573c-45a1-ad39-96cd40546b7d	guest	salam	2026-02-20 10:07:28.331463	\N	guest_service	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2
de2ea287-ae52-44b5-be34-f0e75a1f2ea5	7577111e-642c-4e59-a839-6686f47c5256	81e76596-4329-4026-98e9-f2f040820245	81e76596-4329-4026-98e9-f2f040820245	guest	salam	2026-02-20 10:21:34.490776	\N	guest_service	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2
\.


--
-- Data for Name: contract_acceptances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_acceptances (id, owner_id, tenant_id, user_id, plan_code, plan_type, smart_plan_type, contract_version, property_name, monthly_price, currency, accepted_at, ip_address, user_agent, created_at, contract_language) FROM stdin;
6d5fa9d9-eeab-4189-8c63-e47e2159320f	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_dd5af306-17a7-46c5-914e-f786259be7d7	62797tA7	CORE_STARTER	starter	none	v1.0	Test Hotel oozoFl	79	USD	2026-02-24 08:11:22.423	10.81.2.76	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-24 08:11:22.427575	AZ
85974a08-91a9-4f68-b6a2-12c198fec81e	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_dd5af306-17a7-46c5-914e-f786259be7d7	62797tA7	CORE_PRO	pro	none	v1.0	Test Hotel oozoFl	199	USD	2026-02-24 08:11:25.461	10.81.11.71	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-24 08:11:25.462373	AZ
407fa81c-5da8-4009-9126-547db711cd98	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_dd5af306-17a7-46c5-914e-f786259be7d7	62797tA7	CORE_STARTER	starter	none	v1.0	Test Hotel oozoFl	79	USD	2026-02-24 08:19:25.391	10.81.5.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-02-24 08:19:25.392237	AZ
46a6811f-ae0c-45ef-9ab3-8b63ff0946a1	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_08f26c86-bcee-4bef-91a1-36981c5a1914	62797tA7	CORE_PRO	pro	smart_lite	v1.0	Test Hotel oozoFl	228	USD	2026-03-30 12:32:18.395	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-03-30 12:32:18.397412	EN
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, region, country, client_name, contract_value, currency, partner_company, partner_commission_percent, tax_percent, state_fee_percent, status, notes, signed_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: cost_centers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_centers (id, department_id, hotel_id, tenant_id, name, code, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: credential_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credential_logs (id, guest_id, action, performed_by, performed_by_name, notes, created_at, tenant_id) FROM stdin;
06ebbc15-2187-405f-84f4-39a6c078da03	0803ee24-dc71-430a-9b76-4d4885a624be	created	demo_staff_1	Demo Staff	Guest account created with username GUEST-474089Y1J, password: guest123	2026-02-13 14:52:19.968641	\N
72f06e7e-8576-47d8-b57b-650319311e1f	254ef3be-573c-45a1-ad39-96cd40546b7d	created	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	Guest account created with username GUEST-KLQX, password: guest123	2026-02-20 10:04:09.650391	f73182bf-6a38-4126-b94d-7ef754bc3db2
1a99c6c6-ea48-4ee3-afa7-6c71947fada2	81e76596-4329-4026-98e9-f2f040820245	created	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	Guest account created with username GUEST-2FKT, password: ramin danger8030	2026-02-20 10:18:42.253162	f73182bf-6a38-4126-b94d-7ef754bc3db2
ebba3536-39f1-479f-af57-fb5259dfd02d	5ad56e5d-fd29-4876-b148-8d42424847e9	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-UPDB	2026-02-24 11:00:32.416499	demo_session_2879497c-67d8-4254-a824-fcbaea376064
a9cc57ea-847f-41b1-a322-8c129531c54b	909320fe-e9b7-4490-91b6-6aad72ef9b0b	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-ZUDW	2026-02-24 11:01:23.109924	demo_session_2879497c-67d8-4254-a824-fcbaea376064
3844a5a8-7b26-49e8-95cb-ec0619621c2c	3e6b086d-382a-4ef2-b56c-ee5191701554	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-DN7Z	2026-02-24 11:35:53.482028	demo_session_3f0af152-9afc-4ef2-af0a-6cf8495bbfcc
0debc2e0-084b-461d-9be2-bcdc60437bba	9b1dfd0b-805b-4c70-abf9-329093db2892	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-P4S7	2026-02-24 11:54:37.443827	demo_session_54d883e0-d226-42eb-84df-bb19082f7e3f
30d7c90b-e71c-42ff-9290-ce7bcc092f56	161bfeb3-c162-4917-b1d1-21c4a40e1446	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-NFKV	2026-02-24 11:59:54.297526	demo_session_695830c5-05bd-4882-8eb6-cb868bdff80c
5499b925-33e6-4af8-b294-f68db5a66a39	c765f89e-a13c-41a1-8b8f-7dfac07d72d7	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-YYS9	2026-02-24 12:00:58.922892	demo_session_34e01e00-8509-47db-874b-3bbc6ed52284
3e105444-1af8-4742-82e8-d1ceb04bdaaf	8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-G7ES	2026-02-24 12:15:15.456458	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
52c766d5-2e23-4f8e-b27f-de23bcc83ef6	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-MP4F	2026-02-24 12:16:11.888503	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
448a42f8-3f4e-4f1c-aa9a-9f9f44c4ddf9	2ac88303-6e1b-4f38-a844-c96844af6fef	created	demo_recep_1	Demo Reception	Guest account created with username GUEST-KN9Y	2026-02-24 13:15:15.313575	demo_session_2c831ac8-9c02-411c-b930-799a0999b7b8
404bd5c3-3f27-463a-86c2-0c3e7a1ddfaf	5a7a66ec-9f6b-4730-9bcd-a6b9ec71dba1	created	0d33e5a9-5008-4e52-a897-42c81274ced3	James Wilson	Guest account created with username GUEST-GD65	2026-03-23 16:09:13.748445	11405dd7-d6b6-4d46-8774-bbaa16c01f71
0b12c073-c14e-4371-9bd5-e71a043cf798	3b4feb92-ace7-4005-82e9-0c23211dcfb4	created	0d33e5a9-5008-4e52-a897-42c81274ced3	James Wilson	Guest account created with username GUEST-JLL6	2026-03-23 16:12:33.168826	11405dd7-d6b6-4d46-8774-bbaa16c01f71
020d7e5e-c735-4b27-a461-acfb26efb9bb	711c1a7a-40f5-45ab-a94d-3a63d3b24468	created	0d33e5a9-5008-4e52-a897-42c81274ced3	James Wilson	Guest account created with username GUEST-RX2H	2026-03-23 16:12:33.621753	11405dd7-d6b6-4d46-8774-bbaa16c01f71
1840bedd-533d-45bb-a0e0-7e860e53e809	bb12fe81-fe1d-467b-ba79-c4dd9547435b	created	0d33e5a9-5008-4e52-a897-42c81274ced3	James Wilson	Guest account created with username GUEST-ZTCG	2026-03-23 16:15:53.111039	11405dd7-d6b6-4d46-8774-bbaa16c01f71
a0595755-b8d1-46b9-b7cd-ce42afdad764	a0ace9f0-eb15-4e96-8a72-da6d83247764	created	0d33e5a9-5008-4e52-a897-42c81274ced3	James Wilson	Guest account created with username GUEST-T9L2	2026-03-23 16:16:15.75202	11405dd7-d6b6-4d46-8774-bbaa16c01f71
\.


--
-- Data for Name: daily_financial_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_financial_summaries (id, hotel_id, tenant_id, summary_date, room_revenue, fb_revenue, spa_revenue, other_revenue, total_revenue, total_tax, total_expenses, occupied_rooms, total_rooms, occupancy_rate, adr, revpar, total_payments_cash, total_payments_card, total_payments_bank, is_locked, locked_at, locked_by, created_at, updated_at) FROM stdin;
9b0c0624-d376-4c1e-8f83-fdf01693b443	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	2026-03-22 00:00:00	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	f	\N	\N	2026-03-23 16:34:08.590566	2026-03-23 16:34:08.590566
\.


--
-- Data for Name: deleted_trial_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deleted_trial_accounts (id, email, hotel_name, deleted_at, reason) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, hotel_id, tenant_id, name, code, type, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: device_telemetry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_telemetry (id, device_id, metric_name, metric_value, string_value, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, unit_id, property_id, owner_id, device_type, name, manufacturer, model, serial_number, status, last_ping, metadata, is_active, created_at, ip_address, mac_address, firmware_version, hardware_version, last_online, battery_level, signal_strength, capabilities, configuration, installed_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: door_action_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.door_action_logs (id, booking_id, guest_id, room_number, action, performed_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: escalation_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.escalation_replies (id, escalation_id, user_id, message, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, hotel_id, property_id, owner_id, recurring_expense_id, category, description, amount, currency, vendor, receipt_url, source_type, period_month, period_year, created_by, created_by_name, approved_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_bookings (id, hotel_id, tenant_id, source, external_id, guest_name, checkin_date, checkout_date, room_name, price, status, created_at) FROM stdin;
19867c22-665b-4ceb-bf88-918390675def	channex-unmapped	\N	channex	channex-bk-9001	Ramin Vuqarli	2026-05-10	2026-05-13	Standart	450	confirmed	2026-04-29 08:28:35.913233
5bfd156f-be6d-43dd-b656-73501ac6875d	channex-unmapped	\N	channex	channex-bk-1777451381	Ramin Vuqarli	2026-06-01	2026-06-04	Standart	520	cancelled	2026-04-29 08:29:41.30699
\.


--
-- Data for Name: feature_flag_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feature_flag_overrides (id, owner_id, feature_name, enabled, reason, expires_at, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: financial_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_audit_logs (id, hotel_id, transaction_id, action, performed_by, performed_by_name, previous_values, new_values, created_at, tenant_id) FROM stdin;
afe42c8c-49b9-48b6-a6b7-d1c101e63e1e	4941633e-88da-4920-92c5-6f29de45f79a	1e20a034-56fb-4ae0-9533-a6b6809c6053	created	demo_staff_1	Demo Staff	\N	{"amount": 20000, "method": "credit_card", "status": "paid"}	2026-02-13 14:52:20.020792	899d7a50-7ac8-4c57-b16a-035da45ab8dc
3a5a7962-c08a-4642-8bc5-8a7bf018090f	7577111e-642c-4e59-a839-6686f47c5256	25ca3e47-238d-461e-9537-d7757c2e82ea	created	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	\N	{"amount": 75000, "method": "cash", "status": "paid"}	2026-02-20 10:04:09.690166	f73182bf-6a38-4126-b94d-7ef754bc3db2
9705199a-672d-46b1-910e-9394346d6a38	7577111e-642c-4e59-a839-6686f47c5256	864343ab-f940-44fc-82a3-f9f792b1cdd4	created	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	\N	{"amount": 75000, "method": "cash", "status": "paid"}	2026-02-20 10:18:42.288086	f73182bf-6a38-4126-b94d-7ef754bc3db2
80ab1c48-015e-4092-badd-bee3f4d31e86	4941633e-88da-4920-92c5-6f29de45f79a	96dca2ea-8c23-4eea-bfd9-206de3b4e508	created	demo_recep_1	Demo Reception	\N	{"amount": 10000, "status": "paid"}	2026-02-24 12:16:11.926901	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_transactions (id, hotel_id, guest_id, booking_id, room_number, category, description, amount, payment_status, payment_method, notes, created_by, created_by_name, voided_at, voided_by, void_reason, created_at, updated_at, owner_id, property_id, transaction_reference, tenant_id) FROM stdin;
1e20a034-56fb-4ae0-9533-a6b6809c6053	4941633e-88da-4920-92c5-6f29de45f79a	0803ee24-dc71-430a-9b76-4d4885a624be	e27d63b7-999f-47bc-a1ba-d730eaa87930	101	room_booking	Room 101 booking payment	20000	paid	credit_card	\N	demo_staff_1	Demo Staff	\N	\N	\N	2026-02-13 14:52:20.015537	2026-02-13 14:52:20.015537	\N	\N	\N	899d7a50-7ac8-4c57-b16a-035da45ab8dc
25ca3e47-238d-461e-9537-d7757c2e82ea	7577111e-642c-4e59-a839-6686f47c5256	254ef3be-573c-45a1-ad39-96cd40546b7d	443f65a3-aa8a-42f6-8dae-8c5900d8ba18	505	room_booking	Room 505 booking payment	75000	paid	cash	\N	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	\N	\N	\N	2026-02-20 10:04:09.685974	2026-02-20 10:04:09.685974	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2
864343ab-f940-44fc-82a3-f9f792b1cdd4	7577111e-642c-4e59-a839-6686f47c5256	81e76596-4329-4026-98e9-f2f040820245	c648a0ed-4ec3-4610-b476-6305e7f12048	3	room_booking	Room 3 booking payment	75000	paid	cash	\N	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	\N	\N	\N	2026-02-20 10:18:42.284508	2026-02-20 10:18:42.284508	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2
96dca2ea-8c23-4eea-bfd9-206de3b4e508	4941633e-88da-4920-92c5-6f29de45f79a	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	96dff7ef-a6ef-43b8-89a9-6964ce2dd964	702	room_booking	Room 702 booking payment	10000	paid	cash	\N	demo_recep_1	Demo Reception	\N	\N	\N	2026-02-24 12:16:11.919036	2026-02-24 12:16:11.919036	\N	\N	\N	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
\.


--
-- Data for Name: folio_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folio_adjustments (id, folio_id, booking_id, hotel_id, tenant_id, adjustment_type, description, amount, currency, approved_by, created_by, created_at, approval_status, approved_at, rejected_by, rejected_at, rejection_reason) FROM stdin;
\.


--
-- Data for Name: folio_charges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folio_charges (id, folio_id, booking_id, hotel_id, tenant_id, department_id, cost_center_id, charge_type, description, quantity, unit_price, amount_net, tax_rate, tax_amount, amount_gross, is_inclusive, currency, service_date, idempotency_key, status, voided_at, voided_by, void_reason, posted_by, created_at) FROM stdin;
aa223346-7ce5-4a27-82ec-95162fbfbeb7	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	room_night	Room charge — 3 nights @ STA-001	3	1500000	4500000	0	0	4500000	f	USD	2026-03-24 16:09:13.383	room-charge-62ddfb35-a3eb-4cc0-8de7-613f7106c306	posted	\N	\N	\N	\N	2026-03-23 16:09:26.46882
05659635-c309-4f7e-8fad-bf07f51b046b	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	restaurant	Fine dining dinner x2	2	6500	13000	0	0	13000	f	USD	2026-03-23 16:10:48.23	\N	posted	\N	\N	\N	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:10:48.231247
c6caf755-3f88-4287-8311-882063c3861a	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	minibar	Minibar consumption - Day 1	3	1500	4500	0	0	4500	f	USD	2026-03-23 16:10:48.247	\N	posted	\N	\N	\N	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:10:48.248429
d18c7886-d9a3-4e92-a24c-8e90e56c82fc	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	spa	DUPLICATE - should be rejected	1	8000	8000	0	0	8000	f	USD	2026-03-23 16:11:11.548	spa-charge-test-001	posted	\N	\N	\N	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:11:11.55009
886d9d18-9bea-4510-97f6-9bd99a9ba31c	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	spa	Deep tissue massage - 60min	1	8000	8000	1800	1440	9440	f	USD	2026-03-23 16:10:48.175	\N	voided	2026-03-23 16:11:11.592	0d33e5a9-5008-4e52-a897-42c81274ced3	Guest complained - charge incorrect	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:10:48.177093
48657cb8-3a5e-4b1b-b6f0-b757248c447c	e17ddc40-33dc-4c2e-99eb-07f37edbad02	d719846a-2d2f-49c8-a32f-06a43d8752c4	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	room_night	Room charge — 2 nights @ FIX-101	2	15000	30000	0	0	30000	f	USD	2026-03-24 16:15:52.769	room-charge-d719846a-2d2f-49c8-a32f-06a43d8752c4	posted	\N	\N	\N	\N	2026-03-23 16:15:53.269818
0a719bbd-9f96-46ce-8007-63f12bccab03	36376e30-756c-4c95-aeb6-2975c200ad94	245962ce-d1bd-46cd-9d87-6b66a77665d4	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N	\N	other	No-show cancellation penalty (1 night)	1	20000	20000	0	0	20000	f	USD	2026-03-23 16:16:15.831	\N	posted	\N	\N	\N	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:16:15.832516
\.


--
-- Data for Name: folio_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folio_payments (id, folio_id, booking_id, hotel_id, tenant_id, payment_type, payment_method, amount, currency, reference_number, is_deposit, status, received_at, received_by, notes, created_at) FROM stdin;
4ca80c8b-d51c-4662-a468-12b241b8ccbf	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	payment	bank_transfer	1000000	USD	BNK-2026-00142	t	completed	2026-03-23 16:11:37.073	0d33e5a9-5008-4e52-a897-42c81274ced3	Pre-arrival deposit via bank transfer	2026-03-23 16:11:37.073832
fadaa80d-fb0a-4aef-a374-954265e7c972	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	payment	cash	2000000	USD	\N	f	completed	2026-03-23 16:11:37.106	0d33e5a9-5008-4e52-a897-42c81274ced3	\N	2026-03-23 16:11:37.106718
031e0ea7-80a3-411a-b121-8783a5bf07aa	7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	payment	card	1525500	USD	CARD-XXXX-4291	f	completed	2026-03-23 16:11:37.132	0d33e5a9-5008-4e52-a897-42c81274ced3	\N	2026-03-23 16:11:37.132584
0c59a9d4-c0bb-4554-863a-b0517c494542	36376e30-756c-4c95-aeb6-2975c200ad94	245962ce-d1bd-46cd-9d87-6b66a77665d4	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	payment	bank_transfer	20000	USD	DEPOSIT-PRE-001	t	completed	2026-03-23 16:16:15.85	0d33e5a9-5008-4e52-a897-42c81274ced3	\N	2026-03-23 16:16:15.851363
\.


--
-- Data for Name: guest_folios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guest_folios (id, booking_id, guest_id, hotel_id, property_id, tenant_id, folio_number, status, currency, total_charges, total_payments, total_adjustments, balance, tax_total, opened_at, closed_at, finalized_at, finalized_by, invoice_generated_at, notes, created_at) FROM stdin;
36376e30-756c-4c95-aeb6-2975c200ad94	245962ce-d1bd-46cd-9d87-6b66a77665d4	a0ace9f0-eb15-4e96-8a72-da6d83247764	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	F-20260323-8693	finalized	USD	20000	20000	0	0	0	2026-03-23 16:16:15.818	2026-03-23 16:16:15.882	2026-03-23 16:16:15.882	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:16:15.882	No-show billing: retaining deposit per policy	2026-03-23 16:16:15.818904
7d22fb19-f5cd-49e1-af42-f6960accc3ed	62ddfb35-a3eb-4cc0-8de7-613f7106c306	5a7a66ec-9f6b-4730-9bcd-a6b9ec71dba1	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	F-20260323-9861	finalized	USD	4525500	4525500	0	0	0	2026-03-23 16:09:26.464681	2026-03-23 16:11:52.612	2026-03-23 16:11:52.612	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:11:52.612	\N	2026-03-23 16:09:26.464681
e17ddc40-33dc-4c2e-99eb-07f37edbad02	d719846a-2d2f-49c8-a32f-06a43d8752c4	bb12fe81-fe1d-467b-ba79-c4dd9547435b	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	F-20260323-2434	finalized	USD	30000	0	0	30000	0	2026-03-23 16:15:53.265268	2026-03-23 16:15:54.319	2026-03-23 16:15:54.319	0d33e5a9-5008-4e52-a897-42c81274ced3	2026-03-23 16:15:54.319	\N	2026-03-23 16:15:53.265268
\.


--
-- Data for Name: hotels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hotels (id, name, address, phone, email, logo_url, created_at, country, city, postal_code, website, star_rating, total_rooms, number_of_floors, building_type, primary_guest_type, has_smart_devices, smart_door_locks, smart_hvac, smart_lighting, pms_system, bms_system, iot_sensors, pms_software, pms_other, expected_smart_room_count, billing_currency, billing_contact_email, owner_id, property_id, tenant_id, is_channex_enabled, channex_property_uuid, channex_addon_price, channex_room_count, total_monthly_subscription_fee, is_whatsapp_enabled, whatsapp_balance) FROM stdin;
4b678775-1fb6-4b29-aeb6-66efd36254a6	Test Hotel	Test St 1	+994501234567	hotel@test.com	\N	2026-02-14 14:41:51.828463	Azerbaijan	Baku	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	87772a76-ada5-4dc6-bacf-9e949d17ffc6	e9510355-d798-4f92-a102-1a59c2c2fc85	\N	f	\N	\N	\N	\N	f	0
aa05c231-e9bf-4141-95fe-e570bd70953d	tt	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-19 16:41:22.903327	Azerbaijan	Baku	\N	\N	boutique	34	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	afa0de93-1326-4fe4-a339-f65121ba4bcb	579129ae-3ff4-42ec-825a-61c7c5319d85	\N	f	\N	\N	\N	\N	f	0
13bb4267-9856-4790-9c33-02b989ffbbc9	tttt	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-19 16:43:35.773502	Azerbaijan	Baku	\N	\N	5-star	994	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	02d18ce6-ec09-48c3-948e-741eeceaee86	e2475222-a91c-4167-b334-99f020731951	\N	f	\N	\N	\N	\N	f	0
92be9bf5-6d03-4993-9478-a6d838398a46	ttt	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-19 17:05:59.850551	Azerbaijan	Baku	\N	\N	boutique	33	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	6dec171d-d048-47d4-a5d4-1476a7b5390a	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	\N	f	\N	\N	\N	\N	f	0
37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	Test Hotel oozoFl	123 Test St	+994501234567	demo_owner+hotel@example.com	\N	2026-02-19 17:35:05.7932	United States	Test City	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	f	\N	\N	\N	\N	f	0
f79cf4d0-8944-4d83-9ced-976073ae2824	aewr	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-19 17:38:52.946507	Azerbaijan	Baku	\N	\N	3-star	13	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	495c33fe-a392-439a-aec7-39d639d8b45c	c43b9ca9-7855-43b7-8c41-d2863b88e47a	\N	f	\N	\N	\N	\N	f	0
e807c861-3c3e-41ed-b4d3-89dbe5020c2c	gsd	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-19 18:40:15.297472	Azerbaijan	Baku	\N	\N	5-star	56	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	a8d4b603-ad1a-4807-ad4d-d992076c5892	72122e33-d1a4-4805-bae0-57c020b13ce6	\N	f	\N	\N	\N	\N	f	0
df0a1f3a-869f-455a-913c-5595c65e61f7	test	Baku , Khagani rustamov 8	+0518880089	ramin.v@orange-studio.az	\N	2026-02-20 06:40:15.907052	Azerbaijan	Baku	\N	\N	3-star	4545	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	ac506214-8952-45da-97f0-0e771f8543a2	af2cc7de-c86c-485f-bc92-d0125ec094fb	\N	f	\N	\N	\N	\N	f	0
f2085959-093d-4e61-9229-f38841a56f9e	df	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-20 07:49:44.044766	Azerbaijan	Baku	\N	\N	3-star	43	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	e333d1d7-db91-4f5a-a85b-f78b25df2b53	e0ad8e78-4f8b-45ab-9f06-33c384367f0d	\N	f	\N	\N	\N	\N	f	0
20bf763c-1652-43af-ab4a-b91567b85f9a	TestHotel_ArfmpL	Test Address 123	+994501234567	hotel_aYE8W7@test.com	\N	2026-02-20 08:50:33.303259	Azerbaijan	Baku	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	bc78df31-2b2a-4daa-a3d8-51a0ca8baa10	afbc29ae-ca8f-4c3c-9840-98f3ceb2f1b2	\N	f	\N	\N	\N	\N	f	0
afdcc6cc-9212-4bd9-9bd2-403c0f824513	test	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-20 08:56:25.594891	Azerbaijan	Baku	\N	\N	2-star	56	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	ae2ddc1d-50dc-489d-b690-73465af34a13	b0803298-c2e9-44ac-b28d-4866be2e217e	\N	f	\N	\N	\N	\N	f	0
7577111e-642c-4e59-a839-6686f47c5256	da	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-20 09:25:24.030096	Azerbaijan	Baku	\N	\N	2-star	20	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	\N	f	\N	\N	\N	\N	f	0
24d1573c-c810-485c-a2f9-cc1d0ef3dfb2	test	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-02-20 10:24:50.804068	Azerbaijan	Baku	\N	\N	3-star	321	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	7402ec1b-29e9-4041-86d5-711beacb39e7	2196d0ed-08de-474f-a104-d0c0d5f8fb02	\N	f	\N	\N	\N	\N	f	0
ff6d2516-815b-40ae-ac7b-cf7a086dbaa0	Black.ice.aframe2	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-03-04 10:02:21.161486	Azerbaijan	Baku	\N	\N	apartment	3	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	4b40a969-f41d-4722-bf60-e60829e7bc90	719dd5ca-c66f-4947-8b7e-1b30e22f787a	\N	f	\N	\N	\N	\N	f	0
c7ebef61-6fbc-438f-8a44-639d53fcc58d	Demo Hotel	Demo Street 1	+994501234567	demo-hotel@example.com	\N	2026-03-05 15:06:34.961156	Azerbaijan	Baku	\N	\N	\N	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	11e77135-6f73-422d-8b48-244d2137c1e6	096b4ba5-e48a-4947-95fb-ca9352a29a41	\N	f	\N	\N	\N	\N	f	0
92cf194e-6096-4945-94a3-a005d1b3f822	Black.ice.aframe2	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	2026-03-11 12:47:41.416843	Azerbaijan	Baku	\N	\N	apartment	3	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	e10e1ae2-7ac4-4814-8db4-b701c457309d	d7bb67a8-f871-42d1-a78f-1115b35f04e9	\N	f	\N	\N	\N	\N	f	0
46ae92e5-9940-4b90-a5af-7fad98148a6a	Nuhouse	Nakhchivan - Shikhmahmud	+994504449292	admin@ossaipro.com	\N	2026-03-28 11:25:36.317566	Azerbaijan	Nakhchivan	\N	\N	resort	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	4251c73f-843a-49a7-ad6f-991e94b408db	1008e1af-da16-465b-9812-12a2ae80d378	\N	f	\N	\N	\N	\N	f	0
86d04359-dc5e-4b08-86f7-d45bf449188a	Test Hotel testuser_1777910103	Test Address 1	+994501234567	testuser_1777910103@hotel.com	\N	2026-05-04 15:55:03.973087	AZ	Baku	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	a25bc5e3-4dfe-49c9-899c-f15b8dd8da75	8e0bc00d-3e78-4038-976c-341cab01e423	\N	f	\N	\N	\N	\N	f	0
608e066b-3d9a-49dc-a3d3-27468d4af9b2	Fix Cafe	\N	+994501234567	fix@test.com	\N	2026-05-06 17:53:33.514026	AZ	Baku	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	adfa9924-8b80-4edb-9481-a67feac2580f	beaddf7c-4234-4316-b8a1-b73f2327936a	\N	f	\N	\N	\N	\N	f	0
\.


--
-- Data for Name: housekeeping_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.housekeeping_tasks (id, tenant_id, property_id, unit_id, room_number, task_type, cleaning_type, status, priority, assigned_to, trigger_source, notes, due_date, created_at, completed_at, booking_id) FROM stdin;
f4e82a6c-5579-4a88-b46e-5c7868ee4357	demo_session_3ec6cbe6-038e-4cb7-b29e-6b6784cac621	prop-test-rs	unit-102	102	cleaning	checkout_cleaning	completed	normal	\N	auto_checkout	\N	\N	2026-02-24 12:55:30.348282	2026-02-24 12:56:31.902	\N
f5a42f55-5c37-4b36-b31e-97ee7d3f30e1	demo_session_3ec6cbe6-038e-4cb7-b29e-6b6784cac621	prop-test-rs	unit-103	103	cleaning	deep_cleaning	pending	high	\N	manual	\N	\N	2026-02-24 12:56:46.397895	\N	\N
62714f52-d674-4f7d-a9aa-afff41dde73f	demo_session_2c831ac8-9c02-411c-b930-799a0999b7b8	prop-test-rs	unit-102	102	cleaning	checkout_cleaning	completed	normal	\N	auto_checkout	\N	\N	2026-02-24 13:15:58.965588	2026-02-24 13:16:22.821	e7b0b3d6-1bef-4704-86bb-51f82f3c2cf6
2eae9868-a2f0-42b2-b73c-f445cd831b98	demo_session_2c831ac8-9c02-411c-b930-799a0999b7b8	prop-test-rs	unit-102	102	cleaning	checkout_cleaning	pending	urgent	\N	auto_checkout	\N	\N	2026-02-24 13:16:41.853128	\N	checkout-hk-1771939001
cc80fc9b-8fdf-4eb7-a7c7-da2bc2d356da	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	16495a29-0043-408c-81bb-78e3717990e8	STA-001	cleaning	checkout_cleaning	pending	normal	\N	auto_checkout	\N	\N	2026-03-23 16:11:51.538529	\N	62ddfb35-a3eb-4cc0-8de7-613f7106c306
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, owner_id, stripe_invoice_id, amount, currency, status, description, invoice_url, pdf_url, period_start, period_end, paid_at, created_at, tenant_id, invoice_number, pdf_path) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, hotel_id, tenant_id, entry_number, entry_date, description, source_type, source_id, status, total_debit, total_credit, currency, created_by, reversed_by, created_at) FROM stdin;
\.


--
-- Data for Name: journal_entry_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entry_lines (id, journal_entry_id, hotel_id, tenant_id, account_id, department_id, description, debit, credit, currency, created_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, property_name, country, property_type, email, created_at) FROM stdin;
c0166c2e-2e4f-44aa-9adc-f0f6307d7eb9	Grand Palace Hotel	Azerbaijan	Hotel	owner@grandpalace.az	2026-03-14 20:28:18.120621
cff0da60-f72a-4995-9ae6-bda864667afd	Blue Horizon Resort	UAE	Resort	manager@bluehorizon.ae	2026-03-14 20:30:17.482578
\.


--
-- Data for Name: night_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.night_audits (id, hotel_id, tenant_id, audit_date, status, total_revenue, total_payments, total_adjustments, room_nights_posted, occupied_rooms, total_rooms, occupancy_rate, notes, closed_at, closed_by, created_at) FROM stdin;
\.


--
-- Data for Name: no_show_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.no_show_records (id, hotel_id, booking_id, guest_id, room_number, expected_check_in, estimated_revenue_loss, recorded_by, recorded_by_name, notes, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, title, message, type, read, action_url, created_at, tenant_id) FROM stdin;
2f184e3a-fd3d-4c4e-86fa-7ab52ed0cd97	0803ee24-dc71-430a-9b76-4d4885a624be	Welcome to O.S.S!	Your room 101 is ready. Check-in: 2/13/2026	info	f	\N	2026-02-13 14:52:19.99315	\N
352dd28d-5a8a-449f-ae8b-6e5bf9eb19c9	demo_staff_1	New Service Request	Room 202: housekeeping - Test towel request QO9zIT	info	f	\N	2026-02-19 05:35:46.461212	demo_session_e0939bf2-74ac-4df7-9878-0369fd60bc44
10ebe34b-13b1-4eb0-b30d-ada14380fe19	254ef3be-573c-45a1-ad39-96cd40546b7d	Welcome to O.S.S!	Your room 505 is ready. Check-in: 2/20/2026	info	f	\N	2026-02-20 10:04:09.66139	f73182bf-6a38-4126-b94d-7ef754bc3db2
b1e16199-b67a-430b-ac22-129352e53050	b7c11396-9a5a-48a3-8443-9e2e199ac124	New message from Ramin Veghari	salam	chat	f	/chat?guest=254ef3be-573c-45a1-ad39-96cd40546b7d	2026-02-20 10:07:28.336414	f73182bf-6a38-4126-b94d-7ef754bc3db2
8e9a4045-f4d9-4624-b520-54772e05de3b	8da0da3f-8e4a-4623-ac41-789ee316b827	New message from Ramin Veghari	salam	chat	f	/chat?guest=254ef3be-573c-45a1-ad39-96cd40546b7d	2026-02-20 10:07:28.342822	f73182bf-6a38-4126-b94d-7ef754bc3db2
4125b345-9926-4377-964e-5645dd12dd20	81e76596-4329-4026-98e9-f2f040820245	Welcome to O.S.S!	Your room 3 is ready. Check-in: 2/20/2026	info	f	\N	2026-02-20 10:18:42.265014	f73182bf-6a38-4126-b94d-7ef754bc3db2
dfb1da6e-1f24-4362-a22b-719b9980d37d	b7c11396-9a5a-48a3-8443-9e2e199ac124	New Service Request	Room 3: taxi - tad	info	f	\N	2026-02-20 10:21:30.582404	f73182bf-6a38-4126-b94d-7ef754bc3db2
22e9f3c4-28cd-4dad-b5e8-f04acffdd81f	b7c11396-9a5a-48a3-8443-9e2e199ac124	New message from rasd	salam	chat	f	/chat?guest=81e76596-4329-4026-98e9-f2f040820245	2026-02-20 10:21:34.495505	f73182bf-6a38-4126-b94d-7ef754bc3db2
610fa087-8a78-42d8-8132-ab7763434650	8da0da3f-8e4a-4623-ac41-789ee316b827	New message from rasd	salam	chat	f	/chat?guest=81e76596-4329-4026-98e9-f2f040820245	2026-02-20 10:21:34.501842	f73182bf-6a38-4126-b94d-7ef754bc3db2
e4b8b669-1ff6-48bd-86d1-d5e67bf861aa	5928ad00-69b2-4c01-a6c5-5379c5110c4b	New message from Ramin Veghari	salam	chat	t	/chat?guest=254ef3be-573c-45a1-ad39-96cd40546b7d	2026-02-20 10:07:28.339328	f73182bf-6a38-4126-b94d-7ef754bc3db2
f9fc112a-1c55-404e-897b-7f844b296998	5928ad00-69b2-4c01-a6c5-5379c5110c4b	New Service Request	Room 3: taxi - tad	info	t	\N	2026-02-20 10:21:30.585989	f73182bf-6a38-4126-b94d-7ef754bc3db2
d131980a-09c7-410d-b90c-73ed891bd8c2	5928ad00-69b2-4c01-a6c5-5379c5110c4b	New message from rasd	salam	chat	t	/chat?guest=81e76596-4329-4026-98e9-f2f040820245	2026-02-20 10:21:34.498511	f73182bf-6a38-4126-b94d-7ef754bc3db2
e528816e-6683-456c-b0b7-d5d215a60f1c	5ad56e5d-fd29-4876-b148-8d42424847e9	Welcome to O.S.S!	Your room 202 is ready. Check-in: 3/1/2026	info	f	\N	2026-02-24 11:00:32.426624	demo_session_2879497c-67d8-4254-a824-fcbaea376064
3978db01-ebcb-4c74-b450-7b59505a7db4	909320fe-e9b7-4490-91b6-6aad72ef9b0b	Welcome to O.S.S!	Your room 202 is ready. Check-in: 3/3/2026	info	f	\N	2026-02-24 11:01:23.119695	demo_session_2879497c-67d8-4254-a824-fcbaea376064
1b36bd87-ef54-4833-ac61-b793d2390938	3e6b086d-382a-4ef2-b56c-ee5191701554	Welcome to O.S.S!	Your room 301 is ready. Check-in: 4/1/2026	info	f	\N	2026-02-24 11:35:53.49433	demo_session_3f0af152-9afc-4ef2-af0a-6cf8495bbfcc
ed5b24da-cf28-4301-9701-b79f556bfdeb	9b1dfd0b-805b-4c70-abf9-329093db2892	Welcome to O.S.S!	Your room 401 is ready. Check-in: 4/1/2026	info	f	\N	2026-02-24 11:54:37.46563	demo_session_54d883e0-d226-42eb-84df-bb19082f7e3f
558f8004-9d72-4eed-b101-defe469255af	161bfeb3-c162-4917-b1d1-21c4a40e1446	Welcome to O.S.S!	Your room 501 is ready. Check-in: 4/10/2026	info	f	\N	2026-02-24 11:59:54.30901	demo_session_695830c5-05bd-4882-8eb6-cb868bdff80c
20903483-965c-4ac5-b3ad-688226a500dd	c765f89e-a13c-41a1-8b8f-7dfac07d72d7	Welcome to O.S.S!	Your room 601 is ready. Check-in: 5/1/2026	info	f	\N	2026-02-24 12:00:58.933338	demo_session_34e01e00-8509-47db-874b-3bbc6ed52284
a0d257bf-ebc9-47a1-b290-a24f84d66873	8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	Welcome to O.S.S!	Your room 701 is ready. Check-in: 6/1/2026	info	f	\N	2026-02-24 12:15:15.467369	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
1ba84465-0f68-4969-9303-7f0cc3b95893	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	Welcome to O.S.S!	Your room 702 is ready. Check-in: 6/10/2026	info	f	\N	2026-02-24 12:16:11.908507	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
d15659a5-494b-4a2b-b6a3-7afe94d21b37	2ac88303-6e1b-4f38-a844-c96844af6fef	Welcome to O.S.S!	Your room 102 is ready. Check-in: 2/24/2026	info	f	\N	2026-02-24 13:15:15.326042	demo_session_2c831ac8-9c02-411c-b930-799a0999b7b8
a9c8d4f5-141f-4d97-b7ef-76e0a9c8693b	5a7a66ec-9f6b-4730-9bcd-a6b9ec71dba1	Welcome to O.S.S!	Your room STA-001 is ready. Check-in: 3/24/2026	info	f	\N	2026-03-23 16:09:13.774164	11405dd7-d6b6-4d46-8774-bbaa16c01f71
96bb2c69-6bb6-4855-b572-ffb6e56776ed	eeef0bea-79dd-41d7-96d2-54a05789e802	Housekeeping Task Created	Room STA-001 checkout cleaning unassigned [normal]	housekeeping	f	/housekeeping	2026-03-23 16:11:51.576187	11405dd7-d6b6-4d46-8774-bbaa16c01f71
f0d4aec3-ac7b-43eb-a1ac-52a63ac6c2a4	b7a5a248-a499-45ad-bc91-e1fb33cc06ec	Housekeeping Task Created	Room STA-001 checkout cleaning unassigned [normal]	housekeeping	f	/housekeeping	2026-03-23 16:11:51.579873	11405dd7-d6b6-4d46-8774-bbaa16c01f71
b7c05faf-28e6-49c4-a117-37e07d8b80d8	3b4feb92-ace7-4005-82e9-0c23211dcfb4	Welcome to O.S.S!	Your room STA-002 is ready. Check-in: 3/26/2026	info	f	\N	2026-03-23 16:12:33.189907	11405dd7-d6b6-4d46-8774-bbaa16c01f71
aabfd51d-2c30-40a8-926d-0ae4e57ebe61	711c1a7a-40f5-45ab-a94d-3a63d3b24468	Welcome to O.S.S!	Your room STA-003 is ready. Check-in: 3/26/2026	info	f	\N	2026-03-23 16:12:33.633183	11405dd7-d6b6-4d46-8774-bbaa16c01f71
aea102a2-e9e9-411b-bee9-ddc780e14116	bb12fe81-fe1d-467b-ba79-c4dd9547435b	Welcome to O.S.S!	Your room FIX-101 is ready. Check-in: 3/24/2026	info	f	\N	2026-03-23 16:15:53.197431	11405dd7-d6b6-4d46-8774-bbaa16c01f71
3759fba2-24b1-4f92-82e2-fb6b9609ceff	a0ace9f0-eb15-4e96-8a72-da6d83247764	Welcome to O.S.S!	Your room NS-201 is ready. Check-in: 3/25/2026	info	f	\N	2026-03-23 16:16:15.768759	11405dd7-d6b6-4d46-8774-bbaa16c01f71
e85d45cb-7958-4d09-8584-08a01f21e003	62797tA7	New Booking	Michael Chen reserved room 301 for 08/05/2026 - 14/05/2026	booking	f	\N	2026-05-07 13:54:50.306764	\N
9506db27-0936-4acc-b95d-ac9ad4ab4ee5	62797tA7	Service Request	Sarah Johnson (Room 202) requested extra towels	service_request	f	\N	2026-05-07 13:54:50.312617	\N
6ebc79ad-49f8-487e-9fcb-1705f3333e67	0d33e5a9-5008-4e52-a897-42c81274ced3	New Booking	Michael Chen reserved room 301 for 08/05/2026 - 14/05/2026	booking	f	\N	2026-05-07 13:54:50.316864	\N
935e9ba6-ace0-4177-9848-91c4f7de91b3	0d33e5a9-5008-4e52-a897-42c81274ced3	Service Request	Sarah Johnson (Room 202) requested extra towels	service_request	f	\N	2026-05-07 13:54:50.320014	\N
bae2d8ce-866d-4cbe-95ff-e2145c8fabdf	demo_recep_1	New Booking	Michael Chen reserved room 301 for 08/05/2026 - 14/05/2026	booking	f	\N	2026-05-07 13:54:50.324667	\N
a26298ec-539e-4fea-9f80-5c1d3368dc90	demo_recep_1	Service Request	Sarah Johnson (Room 202) requested extra towels	service_request	f	\N	2026-05-07 13:54:50.328551	\N
45b867bd-b646-4f3c-8e24-a5f00955e791	9ee2674e-a482-41e6-92fa-e29d22ab3948	New Booking	Michael Chen reserved room 301 for 08/05/2026 - 14/05/2026	booking	f	\N	2026-05-07 13:54:50.333765	\N
0f5add40-4a6d-4cc6-8ac1-61e88da15306	9ee2674e-a482-41e6-92fa-e29d22ab3948	Service Request	Sarah Johnson (Room 202) requested extra towels	service_request	f	\N	2026-05-07 13:54:50.337186	\N
4ed95163-76e8-4ab9-844b-7e1122d91eda	e529a154-6b04-438e-83c5-a2b93b741c73	New Booking	Michael Chen reserved room 301 for 08/05/2026 - 14/05/2026	booking	f	\N	2026-05-07 13:54:50.34289	\N
f62d26e6-fe97-4acf-963a-b4ed1039681d	e529a154-6b04-438e-83c5-a2b93b741c73	Service Request	Sarah Johnson (Room 202) requested extra towels	service_request	f	\N	2026-05-07 13:54:50.346499	\N
9f22cbb3-0e4a-49cd-9435-a9fa4d4b71f6	ded08335-b52a-4093-ab0a-875dbfe20c20	New Order	Table 3 — Sarah Johnson: Steak, Lemonade x2, Tiramisu (₼87.00)	info	f	\N	2026-05-07 13:54:50.350791	\N
3eca6aaf-aafe-4c81-a99a-ca6855367d95	ded08335-b52a-4093-ab0a-875dbfe20c20	Order Ready	Table 7 — Michael Chen's order is ready, waiter needed	info	f	\N	2026-05-07 13:54:50.354414	\N
19414a49-2266-4aaf-aefe-bf0d43df1252	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	New Order	Table 3 — Sarah Johnson: Steak, Lemonade x2, Tiramisu (₼87.00)	info	f	\N	2026-05-07 13:54:50.358782	\N
3650897c-1d96-4ea7-99de-236652bada41	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	Order Ready	Table 7 — Michael Chen's order is ready, waiter needed	info	f	\N	2026-05-07 13:54:50.362602	\N
fe940db2-44f1-445a-b80e-a9179764ebd6	9323fd64-17dc-401f-8c07-528a7dcf5fb9	New Order	Table 3 — Sarah Johnson: Steak, Lemonade x2, Tiramisu (₼87.00)	info	f	\N	2026-05-07 13:54:50.367564	\N
37474838-4c99-45ee-921c-ff55a8d51c23	9323fd64-17dc-401f-8c07-528a7dcf5fb9	Order Ready	Table 7 — Michael Chen's order is ready, waiter needed	info	f	\N	2026-05-07 13:54:50.371043	\N
e52f22e5-aa7a-4331-8499-209d732306cb	e7c0a417-1d09-42e0-b0c0-278801594949	New Order	Table 3 — Sarah Johnson: Steak, Lemonade x2, Tiramisu (₼87.00)	info	f	\N	2026-05-07 13:54:50.374866	\N
2c54db70-d94e-4890-a6f5-024769c73e5d	e7c0a417-1d09-42e0-b0c0-278801594949	Order Ready	Table 7 — Michael Chen's order is ready, waiter needed	info	f	\N	2026-05-07 13:54:50.378782	\N
f088d458-1bb6-450d-9b03-2ae3cb1938c6	ef1abc49-94d6-43dc-8f10-94eb34bb7bc1	New Order	Table 3 — Sarah Johnson: Steak, Lemonade x2, Tiramisu (₼87.00)	info	f	\N	2026-05-07 13:54:50.392957	\N
13794ef1-b50b-4ba2-b27d-9002a7bde0f1	ef1abc49-94d6-43dc-8f10-94eb34bb7bc1	Order Ready	Table 7 — Michael Chen's order is ready, waiter needed	info	f	\N	2026-05-07 13:54:50.396343	\N
\.


--
-- Data for Name: onboarding_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onboarding_progress (id, owner_id, current_step, completed_steps, account_completed, property_completed, units_completed, subscription_completed, devices_completed, is_complete, created_at, updated_at, tenant_id, smart_system_completed, staff_completed) FROM stdin;
7817ba02-2f24-401a-95bb-8b95bbb88f30	ac506214-8952-45da-97f0-0e771f8543a2	4	{1,2,3}	f	t	t	f	f	f	2026-02-20 06:40:32.559837	2026-02-20 06:40:34.455	\N	t	t
c5fd781d-b129-49fb-a9ec-120f29a40d2f	4251c73f-843a-49a7-ad6f-991e94b408db	5	{1,2,3,4,5}	f	t	t	t	f	f	2026-03-28 11:25:55.70887	2026-03-28 11:28:04.367	\N	t	t
9369c051-94a1-4a2f-a1c4-a679a09881ba	ae2ddc1d-50dc-489d-b690-73465af34a13	4	{1,2,3,4}	f	t	t	t	f	t	2026-02-20 08:57:17.976316	2026-02-20 08:57:20.85	ae2ddc1d-50dc-489d-b690-73465af34a13	t	t
e5ddc491-3472-464f-970a-7fff1b1da6d0	11e77135-6f73-422d-8b48-244d2137c1e6	3	{1,2}	f	t	t	f	f	f	2026-04-29 09:48:00.920347	2026-04-29 09:48:08.042	\N	f	f
b3963485-1b3e-41cf-8123-ccbcbb27da07	f73182bf-6a38-4126-b94d-7ef754bc3db2	4	{1,2,3,4}	f	t	t	t	f	t	2026-02-20 09:25:44.596231	2026-02-20 09:25:47.304	f73182bf-6a38-4126-b94d-7ef754bc3db2	t	t
d6d62258-77b8-40da-9cbd-f5f9f90fe530	7402ec1b-29e9-4041-86d5-711beacb39e7	4	{1,2,3,4}	f	t	t	t	f	t	2026-02-20 10:25:20.42871	2026-02-20 10:25:24.6	7402ec1b-29e9-4041-86d5-711beacb39e7	t	t
f7c37cd3-90a9-4705-be7f-b4b37900ea89	495c33fe-a392-439a-aec7-39d639d8b45c	4	{1,2,3}	f	t	t	f	f	f	2026-02-19 17:39:10.634457	2026-02-19 17:39:13.309	\N	t	t
6ea7bf91-c465-435b-9da7-1f999a02a036	a8d4b603-ad1a-4807-ad4d-d992076c5892	5	{1,2,3,4,5}	f	t	t	t	f	t	2026-02-19 18:40:33.35158	2026-02-19 18:40:49.981	a8d4b603-ad1a-4807-ad4d-d992076c5892	t	t
e9b5c233-bd7e-4810-ae81-744e29a93f1c	afa0de93-1326-4fe4-a339-f65121ba4bcb	5	{1,2,3,4}	f	t	t	t	f	t	2026-02-19 16:41:47.250188	2026-02-19 16:41:51.242	afa0de93-1326-4fe4-a339-f65121ba4bcb	t	t
390df895-e860-4cc2-b95b-f4f2fbffeb75	02d18ce6-ec09-48c3-948e-741eeceaee86	5	{1,2,3,4}	f	t	t	t	f	t	2026-02-19 16:43:53.972244	2026-02-19 16:43:57.74	02d18ce6-ec09-48c3-948e-741eeceaee86	t	t
109e8815-c6f8-4067-89de-134f093d5a73	6dec171d-d048-47d4-a5d4-1476a7b5390a	5	{1,2,3,4}	f	t	t	t	f	t	2026-02-19 17:06:15.84232	2026-02-19 17:06:19.67	6dec171d-d048-47d4-a5d4-1476a7b5390a	t	t
f31c363d-3493-49a6-971c-f500d87c2e35	11405dd7-d6b6-4d46-8774-bbaa16c01f71	5	{1,2,3,4,5}	f	t	t	t	f	t	2026-02-19 17:35:31.045955	2026-02-19 17:37:03.332	\N	t	t
933447fa-f004-4ce8-a283-f6c668a8dde0	e10e1ae2-7ac4-4814-8db4-b701c457309d	4	{1,2,3,4}	f	t	t	t	f	f	2026-03-11 12:47:51.273481	2026-03-11 12:47:53.169	\N	t	t
\.


--
-- Data for Name: ota_conflicts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ota_conflicts (id, provider, external_id, property_id, tenant_id, unit_id, check_in, check_out, guest_name, reason, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: ota_integrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ota_integrations (id, property_id, tenant_id, provider, api_key, api_secret, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: ota_sync_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ota_sync_logs (id, provider, property_id, tenant_id, action, status, response, created_at) FROM stdin;
\.


--
-- Data for Name: owners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.owners (id, name, email, phone, company_name, country, city, address, logo_url, created_at, status, tax_id, legal_name, registration_number, referral_source, referral_staff_id, referral_notes, tenant_type) FROM stdin;
1abed867-520f-42c0-87cb-836763296852	Trial Test	trialtest2@test.com	\N	Trial Test's Properties	\N	\N	\N	\N	2026-02-19 17:02:37.443056	active	\N	\N	\N	\N	\N	\N	hotel
11405dd7-d6b6-4d46-8774-bbaa16c01f71	Demo Owner	demo_owner+test@example.com	+994501234567	Test Hotel oozoFl	United States	Test City	123 Test St	\N	2026-02-19 17:35:05.741719	active	\N	\N	\N	\N	\N	\N	hotel
6bc37ae9-1cac-4cf0-920a-2c54d018cb53	Diag Test	diag@test.com	\N	Diag Test's Properties	\N	\N	\N	\N	2026-02-20 08:08:19.953598	active	\N	\N	\N	\N	\N	\N	hotel
bc78df31-2b2a-4daa-a3d8-51a0ca8baa10	Test User z2ZC	admin_OM2tKm@test.com	+994501234567	TestHotel_ArfmpL	Azerbaijan	Baku	Test Address 123	\N	2026-02-20 08:50:33.21751	active	\N	\N	\N	\N	\N	\N	hotel
7402ec1b-29e9-4041-86d5-711beacb39e7	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	test	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-20 10:24:50.793466	deleted	\N	\N	\N	\N	\N	\N	hotel
f73182bf-6a38-4126-b94d-7ef754bc3db2	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	da	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-20 09:25:23.977028	deleted	\N	\N	\N	\N	\N	\N	hotel
ae2ddc1d-50dc-489d-b690-73465af34a13	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	test	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-20 08:56:25.581355	deleted	\N	\N	\N	\N	\N	\N	hotel
e333d1d7-db91-4f5a-a85b-f78b25df2b53	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	df	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-20 07:49:43.81906	deleted	\N	\N	\N	\N	\N	\N	hotel
ac506214-8952-45da-97f0-0e771f8543a2	Ramin Veghari	ramin.v@orange-studio.az	+0518880089	test	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-20 06:40:15.853821	deleted	\N	\N	\N	\N	\N	\N	hotel
a8d4b603-ad1a-4807-ad4d-d992076c5892	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	gsd	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-19 18:40:14.981239	deleted	\N	\N	\N	\N	\N	\N	hotel
495c33fe-a392-439a-aec7-39d639d8b45c	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	aewr	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-19 17:38:52.913682	deleted	\N	\N	\N	\N	\N	\N	hotel
6dec171d-d048-47d4-a5d4-1476a7b5390a	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	ttt	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-19 17:05:59.789382	deleted	\N	\N	\N	\N	\N	\N	hotel
02d18ce6-ec09-48c3-948e-741eeceaee86	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	tttt	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-19 16:43:35.757404	deleted	\N	\N	\N	\N	\N	\N	hotel
afa0de93-1326-4fe4-a339-f65121ba4bcb	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	tt	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-02-19 16:41:22.713752	deleted	\N	\N	\N	\N	\N	\N	hotel
87772a76-ada5-4dc6-bacf-9e949d17ffc6	Test Admin	testadmin@test.com	+994501234567	Test Hotel	Azerbaijan	Baku	Test St 1	\N	2026-02-14 14:41:51.223466	deleted	\N	\N	\N	\N	\N	\N	hotel
4b40a969-f41d-4722-bf60-e60829e7bc90	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	Black.ice.aframe2	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-03-04 10:02:21.029889	active	\N	\N	\N	\N	\N	\N	hotel
11e77135-6f73-422d-8b48-244d2137c1e6	Demo Admin	admin@demo.com	+994501234567	Demo Hotel	Azerbaijan	Baku	Demo Street 1	\N	2026-03-05 15:06:34.945852	active	\N	\N	\N	\N	\N	\N	hotel
e10e1ae2-7ac4-4814-8db4-b701c457309d	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	Black.ice.aframe2	Azerbaijan	Baku	Baku , Khagani rustamov 8	\N	2026-03-11 12:47:41.398697	active	\N	\N	\N	\N	\N	\N	hotel
4251c73f-843a-49a7-ad6f-991e94b408db	Ramin	admin@ossaipro.com	+994504449292	Nuhouse	Azerbaijan	Nakhchivan	Nakhchivan - Shikhmahmud	\N	2026-03-28 11:25:36.25267	active	\N	\N	\N	\N	\N	\N	hotel
e1ac24e3-e692-44cb-b829-d2d3920a2324	Test User	test99@hotel.com	+994501234567	Test Channex Hotel	Azerbaijan	Baku	123 Test St	\N	2026-04-29 08:45:20.963416	active	\N	\N	\N	\N	\N	\N	hotel
a25bc5e3-4dfe-49c9-899c-f15b8dd8da75	Test User	testuser_1777910103@test.com	+994501234567	Test Hotel testuser_1777910103	AZ	Baku	Test Address 1	\N	2026-05-04 15:55:03.955271	active	\N	\N	\N	\N	\N	\N	hotel
adfa9924-8b80-4edb-9481-a67feac2580f	Fix Test	fix@test.com	+994501234567	Fix Cafe	AZ	Baku	\N	\N	2026-05-06 17:53:33.482564	active	\N	\N	\N	\N	\N	\N	restaurant_only
1aa25103-7061-4340-b939-98fed23f74e3	Leyla Məmmədova	leyla@ossrestodemo.com	+994501234567	Baku Bistro Group	\N	\N	\N	\N	2026-05-06 18:27:54.027538	active	\N	\N	\N	\N	\N	\N	restaurant_only
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used_at, created_at) FROM stdin;
4089e9af-4e59-46b7-b2bd-06877763e4a5	69d2ec0e-d832-4477-b631-c1d03de733ce	8615c835-17ab-4cfe-aea9-fda980572363	2026-02-19 07:59:12.985	2026-02-19 06:59:50.681	2026-02-19 06:59:12.987793
b0019361-c823-42dd-9de0-3effff79d81d	2b16058a-20b9-4e8e-a880-aa8efe5b738e	e4f2ab51-40cb-4103-8775-ccce5709992d	2026-02-25 10:49:30.97	\N	2026-02-24 10:49:30.970906
5d98f290-92b6-4bf7-90f8-17d3632805ec	73e03062-a936-407e-a1cc-8e6cef1db35d	6701a828-88f7-47b2-988c-7818f63b7ef7	2026-02-25 10:52:06.274	\N	2026-02-24 10:52:06.274885
048b98a2-1750-4995-a924-f4fa559389aa	5ad56e5d-fd29-4876-b148-8d42424847e9	bbf87c15-539c-4173-bf82-6a879d650307	2026-02-25 11:00:32.43	\N	2026-02-24 11:00:32.43058
02675996-011f-4b2b-9d23-c489477c9079	909320fe-e9b7-4490-91b6-6aad72ef9b0b	b7b795d8-f055-4131-acb0-ec1cbade0525	2026-02-25 11:01:23.124	\N	2026-02-24 11:01:23.124555
bd7645db-cedb-497b-a823-f9e852497f5f	3e6b086d-382a-4ef2-b56c-ee5191701554	cb232a66-fb6c-496f-aa32-653a718a7773	2026-02-25 11:35:53.498	\N	2026-02-24 11:35:53.498451
bd086732-36bd-49ee-914d-3a76d151da26	9b1dfd0b-805b-4c70-abf9-329093db2892	318a79cd-e771-4306-8739-623e44373a66	2026-02-25 11:54:37.469	\N	2026-02-24 11:54:37.46959
31114257-d589-427d-872c-f7c611e29ec8	161bfeb3-c162-4917-b1d1-21c4a40e1446	b0ffc4ca-790b-4854-ae8b-c3359b01664b	2026-02-25 11:59:54.312	\N	2026-02-24 11:59:54.312586
01a0040e-13d3-4884-9bcf-fb362d5e452e	c765f89e-a13c-41a1-8b8f-7dfac07d72d7	d7ddce67-40f8-49ad-ad06-aa92ad8117ee	2026-02-25 12:00:58.937	\N	2026-02-24 12:00:58.937949
46e8cf38-4a3a-4b03-bda0-33fd57b43cbb	8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	94860fbb-59c7-464e-910a-31be84872786	2026-02-25 12:15:15.471	\N	2026-02-24 12:15:15.472175
c7d3559e-6f20-404f-a68d-f0816fc39a73	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	8a36e2a2-69c4-417e-96dd-303e0260c4b1	2026-02-25 12:16:11.912	\N	2026-02-24 12:16:11.912943
a41b5b12-e5af-4abf-9173-4e1d095c57d5	2ac88303-6e1b-4f38-a844-c96844af6fef	7d86bbef-ef0d-4cda-b338-1a49eb56da29	2026-02-25 13:15:15.331	\N	2026-02-24 13:15:15.331526
d3f3dcf8-efec-442e-a065-d15167a8949d	c7b239de-f976-4396-bc9a-86185fe48fe6	ce4a2bf3-af27-4f4f-9b34-edb0791a5d70	2026-03-05 13:44:51.128	\N	2026-03-04 13:44:51.128832
ea38f45c-7bba-47af-a9ab-cbaa62fb510e	c74f743c-3047-4bc6-b29a-8174d7c34c66	a01e55ee-0c5d-4be3-b3c0-fa15162449e6	2026-03-05 13:46:15.536	\N	2026-03-04 13:46:15.537097
97049760-a6c1-4125-a299-39998776eb12	4405f382-0550-4d07-97a6-7983e100a9e9	ea8b06f7-83c1-4422-83f9-75d07da1bf15	2026-03-05 13:50:52.551	\N	2026-03-04 13:50:52.551631
8e29214c-8cc1-4989-bd43-7e24f6583f83	5a7a66ec-9f6b-4730-9bcd-a6b9ec71dba1	9809500b-2069-4936-9a4e-eaba31cd3bf9	2026-03-24 16:09:13.783	\N	2026-03-23 16:09:13.783927
0848b75d-4c94-4550-9ab7-22ffa35d0191	3b4feb92-ace7-4005-82e9-0c23211dcfb4	67483472-633a-415f-90da-62b953215852	2026-03-24 16:12:33.194	\N	2026-03-23 16:12:33.195387
37b4c774-ceaf-4a90-a1a1-9e06693ed321	711c1a7a-40f5-45ab-a94d-3a63d3b24468	44d708c3-0cdb-4e63-abc5-6f57fafe4796	2026-03-24 16:12:33.637	\N	2026-03-23 16:12:33.63728
3247a0eb-03e7-434c-bc5d-48cd696429ce	bb12fe81-fe1d-467b-ba79-c4dd9547435b	4fc9c4a8-3512-47d6-99b4-dd72a7977551	2026-03-24 16:15:53.201	\N	2026-03-23 16:15:53.202204
edc16de1-e00d-45b6-99e0-e34edf8ebe53	a0ace9f0-eb15-4e96-8a72-da6d83247764	0de65afe-800c-4377-ad7a-99c3abc51a31	2026-03-24 16:16:15.772	\N	2026-03-23 16:16:15.7731
0d63a14e-55cf-40d3-9d66-e8de78d093c0	38ed791c-6f0f-4abe-96fb-9d8afadda435	9d1bd1b5-02f2-48a0-8f3b-c310d73773af	2026-04-28 14:27:25.119	\N	2026-04-28 13:27:25.120148
59af6d10-0d49-4cd8-afc5-f33cdf9afb0d	38ed791c-6f0f-4abe-96fb-9d8afadda435	c902876d-ae05-4d37-8e44-38b72eacd40e	2026-04-28 17:39:58.401	\N	2026-04-28 16:39:58.402622
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (id, label, type, currency, details, instructions, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_orders (id, owner_id, tenant_id, plan_type, amount, currency, status, payment_method_id, customer_note, admin_note, transfer_reference, reviewed_by, reviewed_at, created_at, updated_at, order_type, reference_id) FROM stdin;
4ad90b9c-7371-4955-b5f7-57fe24a9a115	7402ec1b-29e9-4041-86d5-711beacb39e7	7402ec1b-29e9-4041-86d5-711beacb39e7	growth	219	AZN	rejected	\N	Payriff payment - CORE_GROWTH	Payriff API error	\N	\N	\N	2026-02-20 10:25:43.02898	2026-02-20 10:25:43.499	subscription	\N
7a65e1d4-5622-46f5-b76f-9263939c168c	7402ec1b-29e9-4041-86d5-711beacb39e7	7402ec1b-29e9-4041-86d5-711beacb39e7	growth	219	AZN	rejected	\N	Payriff payment - CORE_GROWTH	Payriff API error	\N	\N	\N	2026-02-20 10:25:51.349046	2026-02-20 10:25:51.704	subscription	\N
bc2370e8-38ce-4d4f-b8d7-3677a3c7e363	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_dd5af306-17a7-46c5-914e-f786259be7d7	pro	33830	AZN	pending	\N	Epoint transaction: te014975449	\N	te014975449	\N	\N	2026-02-24 08:16:03.540266	2026-02-24 08:16:05.032	subscription	\N
f3fc143a-2c7a-4b6c-b7da-a1f9194d6962	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_dd5af306-17a7-46c5-914e-f786259be7d7	starter	13430	AZN	pending	\N	Epoint transaction: te014975641	\N	te014975641	\N	\N	2026-02-24 08:19:25.606945	2026-02-24 08:19:26.762	subscription	\N
3a927b99-fe19-47c5-ae81-b0af16dcefee	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_a792c86a-cc0f-4090-b2a2-5a942ad5df41	starter	13430	AZN	pending	\N	Epoint transaction: te015324436	\N	te015324436	\N	\N	2026-03-01 17:05:42.086765	2026-03-01 17:05:43.272	subscription	\N
50298e70-115c-4b07-8a6a-3d3a6c75c3e9	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_d8c4e6fb-891b-4246-a54e-6ed626200062	starter	13430	AZN	pending	\N	Epoint transaction: te015641975	\N	te015641975	\N	\N	2026-03-05 13:56:54.399744	2026-03-05 13:56:55.83	subscription	\N
b8abcfca-3db0-4cb6-af1b-f9243a12fe0a	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_7a63d279-53d1-491e-b48a-5ac5f0d74cd2	starter	13430	AZN	pending	\N	Epoint transaction: te015831355	\N	te015831355	\N	\N	2026-03-07 16:43:02.716543	2026-03-07 16:43:04.336	subscription	\N
05a52f5b-c03e-4cb7-a687-9218452132fd	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_c1875b56-87c7-42f1-a9ad-7c83fae6226f	starter	13430	AZN	pending	\N	Epoint transaction: te016099142	\N	te016099142	\N	\N	2026-03-11 18:10:10.391775	2026-03-11 18:10:12.193	subscription	\N
fc701ad8-b9f6-4aea-9c23-bd7cabfa3325	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_08f26c86-bcee-4bef-91a1-36981c5a1914	pro	80000	AZN	rejected	\N	{"splitGroupId":"e52ddecd-f29c-48ea-b4b6-ba101b797016","splitIndex":1,"splitTotal":4,"planCode":"CORE_PRO","smartPlanCode":"smart_lite","smartRoomCount":53,"totalAmountAZN":2951.2}	Epoint API error: SQLSTATE[22001]: String data, right truncated: 1406 Data too long for column 'success_redirect_url' at row 1 (SQL: insert into `payments` (`table_name`, `record_id`, `recipient_id`, `user_id`, `commission`, `fix_surcharge`, `type`, `purpose`, `total`, `sendbox`, `user_merchant_id`, `merchant_order_id`, `other_attr`, `connection_type`, `success_redirect_url`, `error_redirect_url`, `description`, `bank_key`, `merchant`, `merchant_key`, `id`, `updated_at`, `created_at`) values (merchants, 1314, 11493, 11493, 0, 0, 0, 0, 800.00, 0, 1314, fc701ad8-b9f6-4aea-9c23-bd7cabfa3325, ?, 1, https://ossaiproapp.com/settings?payment=split_pending&splitGroupId=e52ddecd-f29c-48ea-b4b6-ba101b797016&splitIndex=1&splitTotal=4&planCode=CORE_PRO&smartPlanCode=smart_lite&smartRoomCount=53&paidAZN=800&remainingAZN=2151.2&totalAZN=2951.2&planType=pro, https://ossaiproapp.com/settings?payment=declined&orderId=fc701ad8-b9f6-4aea-9c23-bd7cabfa3325, O.S.S Pro plan + Smart Lite x53 rooms (1/4), 1, 0018581, 25, 17283698, 2026-03-30 16:32:19, 2026-03-30 16:32:19))	\N	\N	\N	2026-03-30 12:32:18.669465	2026-03-30 12:32:19.928	subscription	\N
10342008-f485-4303-9a4e-b42f39f1aadb	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_59a227dc-10ea-43af-afa7-ecd56597f707	pro	80000	AZN	pending	\N	{"splitGroupId":"5ea8c5a3-764e-4dff-b0c4-e87d8f6265c6","splitIndex":1,"splitTotal":7,"planCode":"CORE_PRO","smartPlanCode":"smart_lite","smartRoomCount":100,"totalAmountAZN":5268.3}	\N	te017284007	\N	\N	2026-03-30 12:36:29.211307	2026-03-30 12:36:30.496	subscription	\N
e32cbb19-c628-448e-9847-8d04735c334f	11405dd7-d6b6-4d46-8774-bbaa16c01f71	demo_session_c6c0de4c-0863-475d-9888-c0fe2aee59f4	pro	80000	AZN	pending	\N	{"splitGroupId":"f640da35-fd8a-4ee1-bb5e-3fde54169dd5","splitIndex":1,"splitTotal":7,"planCode":"CORE_PRO","smartPlanCode":"smart_lite","smartRoomCount":100,"totalAmountAZN":5268.3}	\N	te017284316	\N	\N	2026-03-30 12:40:59.299959	2026-03-30 12:41:00.581	subscription	\N
5135d084-6cf8-43a5-8e7c-2518919d281e	1aa25103-7061-4340-b939-98fed23f74e3	demo_session_250d832e-a4e7-4903-b18d-b5551bddbac7	restaurant_bistro	8330	AZN	pending	\N	Epoint transaction: te018932568	\N	te018932568	\N	\N	2026-05-06 19:11:01.321303	2026-05-06 19:11:04.344	subscription	\N
cd177d75-2d3e-4680-a82b-b64b26239b2f	1aa25103-7061-4340-b939-98fed23f74e3	demo_session_250d832e-a4e7-4903-b18d-b5551bddbac7	pro	33830	AZN	pending	\N	Epoint transaction: te018932570	\N	te018932570	\N	\N	2026-05-06 19:11:06.930712	2026-05-06 19:11:07.976	subscription	\N
8992e94d-17bb-4df8-a428-a19a860854d0	1aa25103-7061-4340-b939-98fed23f74e3	demo_session_438ed50f-7fb3-4ea9-aa4e-976537bd10f9	restaurant_bistro	8330	AZN	pending	\N	Epoint transaction: te018932605	\N	te018932605	\N	\N	2026-05-06 19:12:29.377364	2026-05-06 19:12:31.838	subscription	\N
f985a717-2868-4ff5-9833-98090cafe2de	1aa25103-7061-4340-b939-98fed23f74e3	demo_session_438ed50f-7fb3-4ea9-aa4e-976537bd10f9	restaurant_bistro	8330	AZN	pending	\N	Epoint transaction: te018932614	\N	te018932614	\N	\N	2026-05-06 19:12:55.902983	2026-05-06 19:12:57.966	subscription	\N
98107ffb-324f-47af-b9bd-518b8348e402	1aa25103-7061-4340-b939-98fed23f74e3	demo_session_6fefeb26-1da9-4869-86f0-f5b13c35d25d	restaurant_bistro	8330	AZN	pending	\N	Epoint transaction: te018932673	\N	te018932673	\N	\N	2026-05-06 19:15:13.268501	2026-05-06 19:15:15.52	subscription	\N
852c0b53-6caa-4e82-bf1b-e915ecd19235	1aa25103-7061-4340-b939-98fed23f74e3	demo_session_9966a6f6-cf39-4892-b6dd-0d0fb22e9292	restaurant_bistro	8330	AZN	pending	\N	Epoint transaction: te018932687	\N	te018932687	\N	\N	2026-05-06 19:15:50.654705	2026-05-06 19:15:53.349	subscription	\N
\.


--
-- Data for Name: payroll_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_configs (id, hotel_id, property_id, owner_id, staff_id, staff_name, staff_role, base_salary, currency, frequency, bonus_rules, deduction_rules, bank_details, is_active, created_by, created_at, updated_at, tenant_id, employee_tax_rate, additional_expenses_monthly) FROM stdin;
f2ee989f-70c4-4c9a-96fe-7423eb58a9da	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	9ee2674e-a482-41e6-92fa-e29d22ab3948	Nina Torres	staff	250000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.022478	2026-05-05 17:55:43.022478	\N	0	0
e5e9d3e0-1ae7-4c4e-9ce2-c425979aafff	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	e529a154-6b04-438e-83c5-a2b93b741c73	Dave Park	staff	270000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.029593	2026-05-05 17:55:43.029593	\N	0	0
86a3129e-92f8-4076-96d5-fd6a7cfd1b16	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	ded08335-b52a-4093-ab0a-875dbfe20c20	Sofia Reyes	restaurant_manager	480000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.03798	2026-05-05 17:55:43.03798	\N	140	0
ba63716a-8020-4d31-aa1f-5874e93aeef1	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	Luca Bianchi	waiter	280000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.043965	2026-05-05 17:55:43.043965	\N	140	0
4335d06d-780e-43f8-82c0-61605c0f6b54	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	9323fd64-17dc-401f-8c07-528a7dcf5fb9	Carlos Mendez	kitchen_staff	320000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.049923	2026-05-05 17:55:43.049923	\N	140	0
0a315870-f120-414f-ad78-ef0cc1b317e4	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	e7c0a417-1d09-42e0-b0c0-278801594949	Ana Lima	restaurant_cleaner	220000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.056603	2026-05-05 17:55:43.056603	\N	0	0
f925ebce-662b-4371-b070-d1cc3b8b5162	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	ef1abc49-94d6-43dc-8f10-94eb34bb7bc1	Omar Faruk	restaurant_cashier	300000	USD	monthly	\N	\N	\N	t	\N	2026-05-05 17:55:43.063363	2026-05-05 17:55:43.063363	\N	140	0
\.


--
-- Data for Name: payroll_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_entries (id, hotel_id, property_id, owner_id, payroll_config_id, staff_id, staff_name, amount, bonus_amount, deduction_amount, net_amount, currency, period_month, period_year, status, paid_at, notes, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: pos_menu_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_menu_categories (id, tenant_id, property_id, name, sort_order, is_active, created_at) FROM stdin;
7f4cd092-57b7-4104-a3a2-7b52fcb06edf	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	Səhər Yeməyi	0	t	2026-05-05 17:55:42.915716
d64c9381-e87a-4f9f-b123-d8d0ebea8ea5	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	Əsas Yeməklər	1	t	2026-05-05 17:55:42.922615
52ac9d76-df4b-4d9a-9489-624b8f5dcd6c	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	İçkilər	2	t	2026-05-05 17:55:42.928378
50865b33-b335-441b-984e-7e8c6c86a281	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	Şirniyyat	3	t	2026-05-05 17:55:42.931806
302d4528-dd27-4fba-a5cc-8cbb70488407	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	Soyuq içkilər	0	t	2026-05-06 18:27:54.050716
40345f87-cbe0-4a81-94d8-18713b4cc1ab	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	Əsas yeməklər	1	t	2026-05-06 18:27:54.053759
41c6542a-2e46-4184-bc0e-6af4dab69915	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	Şirniyyat	2	t	2026-05-06 18:27:54.05723
\.


--
-- Data for Name: pos_menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_menu_items (id, tenant_id, property_id, category_id, name, description, price_cents, image_url, is_available, created_at) FROM stdin;
70311bcd-521f-4a36-951d-018e62571ff2	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	7f4cd092-57b7-4104-a3a2-7b52fcb06edf	Tam Qaynar Səhər Yeməyi	Yumurta, kolbasa, tost	2500	\N	t	2026-05-05 17:55:42.937661
e50e9c70-b558-4a4e-a2d3-d64943a0169a	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	7f4cd092-57b7-4104-a3a2-7b52fcb06edf	Pankek	Ağcaqayın şərbəti ilə	1800	\N	t	2026-05-05 17:55:42.951713
50d2f63c-008c-4ba7-8330-f8e09ff47d35	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	7f4cd092-57b7-4104-a3a2-7b52fcb06edf	Qranola & Yoqurt	Təzə meyvə ilə	1200	\N	t	2026-05-05 17:55:42.9568
8015899f-f7db-45cc-93f9-f402fe8c5b54	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	d64c9381-e87a-4f9f-b123-d8d0ebea8ea5	Cızlama Toyuq	Kartof püresi ilə	3500	\N	t	2026-05-05 17:55:42.961219
5eeb18ff-4592-4c59-8f6a-e0ad0fa647d4	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	d64c9381-e87a-4f9f-b123-d8d0ebea8ea5	Biftek	Kökü garnir ilə	5500	\N	t	2026-05-05 17:55:42.965561
f12b9ac6-278b-4377-ae32-493d2a010dcd	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	d64c9381-e87a-4f9f-b123-d8d0ebea8ea5	Qril Balıq	Limon yağı ilə	4200	\N	t	2026-05-05 17:55:42.970366
2c35fece-d1be-43a1-9cd5-64bd755ca736	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	d64c9381-e87a-4f9f-b123-d8d0ebea8ea5	Vegetarian Pasta	Mevsim tərəvəzləri ilə	2800	\N	t	2026-05-05 17:55:42.975721
9d8ded79-f729-4b14-88fe-6032883ec760	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	52ac9d76-df4b-4d9a-9489-624b8f5dcd6c	Limonad	Ev hazırlaması	600	\N	t	2026-05-05 17:55:42.97999
9cc46893-bed1-4065-8a61-8e4e7cab6e7a	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	52ac9d76-df4b-4d9a-9489-624b8f5dcd6c	Çay	Süd ilə	400	\N	t	2026-05-05 17:55:42.986122
5e00d154-9f92-4e66-894d-588c518a041d	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	52ac9d76-df4b-4d9a-9489-624b8f5dcd6c	Espresso	İtalyan rostu	700	\N	t	2026-05-05 17:55:42.989719
461447ca-2a7e-4f0f-9ab2-d428598d92f6	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	52ac9d76-df4b-4d9a-9489-624b8f5dcd6c	Mineral Su	0.5L	350	\N	t	2026-05-05 17:55:42.994436
d03b42e3-0716-4532-9353-e6bba9a72d0f	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	50865b33-b335-441b-984e-7e8c6c86a281	Şokoladlı Keks	Şokolad suyu ilə	1400	\N	t	2026-05-05 17:55:42.999529
e68ee87c-8f2c-4222-bed3-56e279f13bd3	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	50865b33-b335-441b-984e-7e8c6c86a281	Dondurma	3 top	900	\N	t	2026-05-05 17:55:43.003976
ee26d362-a994-4abd-a4d6-1a2ac8570839	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	50865b33-b335-441b-984e-7e8c6c86a281	Tiramisu	Klassik İtalyan	1800	\N	t	2026-05-05 17:55:43.008932
59efe8df-b4d7-4c90-8f84-08fb709488c1	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	302d4528-dd27-4fba-a5cc-8cbb70488407	Limonad	Ev limonadı	500	\N	t	2026-05-06 18:27:54.061874
1b6841c4-c4ae-4acc-b4e6-b48c394a0dac	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	302d4528-dd27-4fba-a5cc-8cbb70488407	Mineral Su	0.5L	300	\N	t	2026-05-06 18:27:54.065702
5e330b78-f78f-41b9-a278-47b4750255d5	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	302d4528-dd27-4fba-a5cc-8cbb70488407	Portağal Şirəsi	Təzə sıxılmış	600	\N	t	2026-05-06 18:27:54.068602
60eb1472-f128-43e7-bccc-9ecefd592d91	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	40345f87-cbe0-4a81-94d8-18713b4cc1ab	Qril Toyuq	Kartofla	3200	\N	t	2026-05-06 18:27:54.072313
9db9b1fe-d140-419a-9494-522afa5a03a8	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	40345f87-cbe0-4a81-94d8-18713b4cc1ab	Biftek	Qovrulmuş tərəvəzlə	5000	\N	t	2026-05-06 18:27:54.075406
dcc17da8-f37e-4780-9d1a-cd78b5360669	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	40345f87-cbe0-4a81-94d8-18713b4cc1ab	Balıq	Limon yağı ilə	4000	\N	t	2026-05-06 18:27:54.079197
3147dbb0-d1ac-47cf-b78a-d9900720c9da	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	40345f87-cbe0-4a81-94d8-18713b4cc1ab	Vegetarian Pasta	Mövsümi tərəvəzlə	2500	\N	t	2026-05-06 18:27:54.082558
46485314-dc22-4184-b926-b8ae244e8c47	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	41c6542a-2e46-4184-bc0e-6af4dab69915	Tiramisu	Klassik İtalyan	1800	\N	t	2026-05-06 18:27:54.086415
a35970fe-07a9-487e-94c4-ddbb9bb15fc5	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	41c6542a-2e46-4184-bc0e-6af4dab69915	Şokolad Tort	Şokolad sousla	1500	\N	t	2026-05-06 18:27:54.090306
\.


--
-- Data for Name: pos_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_order_items (id, order_id, menu_item_id, item_name, quantity, unit_price_cents, total_cents) FROM stdin;
6fc5d3ad-91a0-4400-a138-348962b4ffc3	cf79b576-b01c-47e2-9847-41f5ca071b87	\N	Biftek	1	5500	5500
d0e771e6-b240-43a4-8063-0a4ab38fe602	cf79b576-b01c-47e2-9847-41f5ca071b87	\N	Limonad	2	600	1200
de050de4-a2f6-426a-a0b6-cb6bafe5997a	cf79b576-b01c-47e2-9847-41f5ca071b87	\N	Tiramisu	1	1800	1800
5c5231a4-0a0b-4355-a0e7-e50ce4bb0ed0	70bc5e27-a8b6-4fe9-9849-39e74f4ec623	\N	Qril Balıq	1	4200	4200
4a64d8f1-743d-4cd1-88f7-21cd8fbf3f68	70bc5e27-a8b6-4fe9-9849-39e74f4ec623	\N	Mineral Su	1	350	350
cd5c02a4-be58-4300-a8a6-adb57a906892	0a8d3374-06e7-48c5-9cad-08274de2c769	\N	Cızlama Toyuq	1	3500	3500
25652cd8-294d-42a1-a0f6-424986950e2c	0a8d3374-06e7-48c5-9cad-08274de2c769	\N	Çay	1	400	400
a9b6dbb6-3903-4f8d-9eed-8ca0a424abc7	8545785d-0a22-4ce3-90d7-204dadbf87b9	\N	Biftek	1	5000	5000
6658af86-86d3-4aa2-b8f7-c3bc2af31a65	8545785d-0a22-4ce3-90d7-204dadbf87b9	\N	Limonad	2	500	1000
5ef89fd3-cd20-4468-a1eb-77b12810e2f5	8545785d-0a22-4ce3-90d7-204dadbf87b9	\N	Tiramisu	1	1800	1800
3d2bea5c-5205-4d52-84f9-0c721faf5b5f	44b40bef-6d79-4f74-898f-0893cabf345d	\N	Balıq	1	4000	4000
5af1ab41-d0b5-41b8-b545-bdc620ebfc02	44b40bef-6d79-4f74-898f-0893cabf345d	\N	Mineral Su	1	300	300
c3236327-43c6-4512-a8a0-fc50d96a335f	44b40bef-6d79-4f74-898f-0893cabf345d	\N	Şokolad Tort	1	1500	1500
8daa9b9e-d287-4692-9c65-538e1069766c	9a9560be-5728-46f9-bf24-bfb8c22a2257	\N	Qril Toyuq	2	3200	6400
\.


--
-- Data for Name: pos_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_orders (id, tenant_id, property_id, folio_id, booking_id, table_number, guest_name, waiter_id, kitchen_status, settlement_status, notes, total_cents, created_at, ready_at, delivered_at, settled_at, room_number, order_type, source_type, items) FROM stdin;
cf79b576-b01c-47e2-9847-41f5ca071b87	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N	3	Sarah Johnson	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	cooking	pending	\N	8700	2026-05-05 17:55:43.068238	\N	\N	\N	\N	dine_in	staff	\N
70bc5e27-a8b6-4fe9-9849-39e74f4ec623	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N	7	Michael Chen	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	ready	pending	\N	4550	2026-05-05 17:55:43.075192	\N	\N	\N	\N	dine_in	staff	\N
0a8d3374-06e7-48c5-9cad-08274de2c769	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N	\N	Sarah Johnson	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	delivered	pending	\N	3900	2026-05-05 17:55:43.082644	\N	\N	\N	202	room_service	staff	\N
8545785d-0a22-4ce3-90d7-204dadbf87b9	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	\N	\N	3	Əli Hüseynov	\N	cooking	pending	\N	8700	2026-05-06 18:27:54.094948	\N	\N	\N	\N	dine_in	staff	\N
44b40bef-6d79-4f74-898f-0893cabf345d	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	\N	\N	5	Nigar Əliyeva	\N	ready	pending	\N	4500	2026-05-06 18:27:54.101677	\N	\N	\N	\N	dine_in	staff	\N
9a9560be-5728-46f9-bf24-bfb8c22a2257	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	\N	\N	1	Tural Qasımov	\N	delivered	cash_paid	\N	6200	2026-05-06 18:27:54.108027	\N	\N	\N	\N	dine_in	staff	\N
\.


--
-- Data for Name: pricing_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pricing_rules (id, property_id, tenant_id, name, rule_type, priority, conditions, adjustment, is_active, created_at) FROM stdin;
138d1b7b-0b09-479c-a44f-60f94c663fc0	d60048fa-971f-486c-a8db-610a5965ad97	demo_session_9cda15e2-8c39-411b-adb5-95f102414de3	Weekend Surge	day_of_week	10	{"days": [5, 6]}	{"type": "percentage", "value": 15}	t	2026-03-04 17:55:31.751175
228852f2-eb9a-4348-af2e-ecfd1bdbd8e5	096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	Test Weekend Surge	day_of_week	10	{"days": [5, 6]}	{"type": "percentage", "value": 15}	t	2026-03-05 15:07:38.432219
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.properties (id, owner_id, name, type, address, phone, email, logo_url, country, city, postal_code, website, star_rating, total_units, number_of_floors, building_type, primary_guest_type, has_smart_devices, smart_door_locks, smart_hvac, smart_lighting, pms_system, bms_system, iot_sensors, pms_software, pms_other, expected_smart_room_count, billing_currency, billing_contact_email, timezone, is_active, created_at, tenant_id, image_url, country_tax_rate, utility_expense_pct, cleaning_expense_monthly, default_employee_tax_rate, additional_expenses_monthly) FROM stdin;
c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	da	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	2-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-20 09:25:24.020197	\N	\N	0	0	0	0	0
719dd5ca-c66f-4947-8b7e-1b30e22f787a	4b40a969-f41d-4722-bf60-e60829e7bc90	Black.ice.aframe2	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	apartment	3	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	t	2026-03-04 10:02:21.044136	\N	\N	0	0	0	0	0
b0803298-c2e9-44ac-b28d-4866be2e217e	ae2ddc1d-50dc-489d-b690-73465af34a13	test	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	2-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-20 08:56:25.587756	\N	\N	0	0	0	0	0
969381ca-6c92-4fb7-9b75-6c15dce51d0f	e1ac24e3-e692-44cb-b829-d2d3920a2324	Test Channex Hotel	hotel	123 Test St	+994501234567	info@testhotel.com	\N	Azerbaijan	Baku	\N	\N	\N	25	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	t	2026-04-29 08:45:20.968541	\N	\N	0	0	0	0	0
d7bb67a8-f871-42d1-a78f-1115b35f04e9	e10e1ae2-7ac4-4814-8db4-b701c457309d	Black.ice.aframe2	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	apartment	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	t	2026-03-11 12:47:41.407813	\N	\N	0	0	0	0	0
afbc29ae-ca8f-4c3c-9840-98f3ceb2f1b2	bc78df31-2b2a-4daa-a3d8-51a0ca8baa10	TestHotel_ArfmpL	hotel	Test Address 123	+994501234567	hotel_aYE8W7@test.com	\N	Azerbaijan	Baku	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	t	2026-02-20 08:50:33.268654	\N	\N	0	0	0	0	0
e0ad8e78-4f8b-45ab-9f06-33c384367f0d	e333d1d7-db91-4f5a-a85b-f78b25df2b53	df	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	3-star	43	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	f	2026-02-20 07:49:44.035132	\N	\N	0	0	0	0	0
d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	Grand Riviera Resort & Spa	resort	123 Oceanview Boulevard, Miami Beach, FL 33139	+994501234567	demo_owner+hotel@example.com	\N	United States	Test City	\N	\N	\N	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	t	2026-02-19 17:35:05.771701	\N	\N	0	0	0	0	0
af2cc7de-c86c-485f-bc92-d0125ec094fb	ac506214-8952-45da-97f0-0e771f8543a2	test	hotel	Baku , Khagani rustamov 8	+0518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	3-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-20 06:40:15.885182	\N	\N	0	0	0	0	0
1008e1af-da16-465b-9812-12a2ae80d378	4251c73f-843a-49a7-ad6f-991e94b408db	Nuhouse	hotel	Nakhchivan - Shikhmahmud	+994504449292	admin@ossaipro.com	\N	Azerbaijan	Nakhchivan	\N	\N	resort	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	Asia/Baku	t	2026-03-28 11:25:36.287368	\N	\N	18	10	1000	4	0
72122e33-d1a4-4805-bae0-57c020b13ce6	a8d4b603-ad1a-4807-ad4d-d992076c5892	gsd	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	5-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-19 18:40:15.288651	\N	\N	0	0	0	0	0
c43b9ca9-7855-43b7-8c41-d2863b88e47a	495c33fe-a392-439a-aec7-39d639d8b45c	aewr	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	3-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-19 17:38:52.928191	\N	\N	0	0	0	0	0
2196d0ed-08de-474f-a104-d0c0d5f8fb02	7402ec1b-29e9-4041-86d5-711beacb39e7	test	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	3-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-20 10:24:50.797012	\N	\N	0	0	0	0	0
fb04e537-345b-4e39-9d19-959e2eded6dc	f73182bf-6a38-4126-b94d-7ef754bc3db2	3	hotel	Baku , Khagani rustamov 8, 31	\N	\N	\N	Azerbaijan	Baku	\N	\N	\N	33	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	f	2026-02-20 09:26:17.305254	\N	\N	0	0	0	0	0
59c84f95-6cfc-44c8-b7ed-53ef157054ea	f73182bf-6a38-4126-b94d-7ef754bc3db2	2	hotel	Baku , Khagani rustamov 8, 31	\N	\N	\N	Azerbaijan	Baku	\N	\N	\N	20	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	f	2026-02-20 09:26:01.361895	\N	\N	0	0	0	0	0
d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	6dec171d-d048-47d4-a5d4-1476a7b5390a	ttt	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	boutique	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-19 17:05:59.832238	\N	\N	0	0	0	0	0
e2475222-a91c-4167-b334-99f020731951	02d18ce6-ec09-48c3-948e-741eeceaee86	tttt	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	5-star	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-19 16:43:35.763074	\N	\N	0	0	0	0	0
579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	tt	hotel	Baku , Khagani rustamov 8	+994518880089	ramin.v@orange-studio.az	\N	Azerbaijan	Baku	\N	\N	boutique	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	f	2026-02-19 16:41:22.768512	\N	\N	0	0	0	0	0
e9510355-d798-4f92-a102-1a59c2c2fc85	87772a76-ada5-4dc6-bacf-9e949d17ffc6	Test Hotel	hotel	Test St 1	+994501234567	hotel@test.com	\N	Azerbaijan	Baku	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	f	2026-02-14 14:41:51.69622	\N	\N	0	0	0	0	0
096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	Demo Hotel	hotel	Demo Street 1	+994501234567	demo-hotel@example.com	\N	Azerbaijan	Baku	\N	\N	\N	5	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	UTC	t	2026-03-05 15:06:34.950141	\N	\N	0	0	0	0	0
prop-test-rs	899d7a50-7ac8-4c57-b16a-035da45ab8dc	Test Hotel Property	hotel	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	t	2026-02-24 12:30:51.687688	899d7a50-7ac8-4c57-b16a-035da45ab8dc	\N	0	0	0	0	0
beaddf7c-4234-4316-b8a1-b73f2327936a	adfa9924-8b80-4edb-9481-a67feac2580f	Fix Cafe	restaurant	\N	+994501234567	fix@test.com	\N	AZ	Baku	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	t	2026-05-06 17:53:33.508846	\N	\N	0	0	0	0	0
8f33f4e2-9509-4834-8efc-7705a5915129	1aa25103-7061-4340-b939-98fed23f74e3	Baku Bistro	restaurant	Nizami küçəsi 45, Bakı	+994501234567	info@bakubistro.az	\N	Azerbaijan	Baku	\N	\N	\N	\N	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	Asia/Baku	t	2026-05-06 18:27:54.03593	\N	\N	0	0	0	0	0
8e0bc00d-3e78-4038-976c-341cab01e423	a25bc5e3-4dfe-49c9-899c-f15b8dd8da75	Test Hotel testuser_1777910103	hotel	Test Address 1	+994501234567	testuser_1777910103@hotel.com	\N	AZ	Baku	\N	\N	\N	10	\N	\N	\N	f	f	f	f	f	f	f	\N	\N	\N	\N	\N	\N	t	2026-05-04 15:55:03.959982	\N	\N	0	0	0	0	0
\.


--
-- Data for Name: quote_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_notes (id, quote_request_id, author_user_id, note_text, created_at) FROM stdin;
\.


--
-- Data for Name: quote_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_requests (id, hotel_name, contact_name, phone, email, country, city, preferred_contact_hours, timezone, preferred_contact_method, total_rooms, expected_smart_rooms, interested_features, message, source_page, language, status, internal_notes, email_sent, created_at, updated_at, assigned_to_user_id, contacted_at) FROM stdin;
\.


--
-- Data for Name: rate_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_plans (id, property_id, tenant_id, name, refund_policy, meal_plan, price_modifier, is_default, is_active, created_at) FROM stdin;
2bcb861a-b660-4303-98d7-2a9faa8e4ac4	b234cd19-cb86-485b-a2cb-7c6687e89b91	11405dd7-d6b6-4d46-8774-bbaa16c01f71	Standard	flexible	none	0	t	t	2026-05-04 15:49:20.659556
df1033e7-f401-4c81-908f-4b2231b27b0a	dd1d6554-478a-44ab-a85d-72bf5d4a51e3	11405dd7-d6b6-4d46-8774-bbaa16c01f71	Standard	flexible	none	0	t	t	2026-05-04 15:55:03.805787
\.


--
-- Data for Name: recurring_expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recurring_expenses (id, hotel_id, property_id, owner_id, category, description, amount, currency, frequency, vendor, is_active, next_run_at, last_run_at, created_by, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: referral_commissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referral_commissions (id, staff_user_id, owner_id, commission_pct, status, amount_cents, paid_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: refund_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refund_requests (id, invoice_id, transaction_id, owner_id, tenant_id, amount, currency, reason, status, requested_by, approved_by, rejected_by, rejection_reason, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: restaurant_cleaning_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurant_cleaning_tasks (id, tenant_id, property_id, description, location, assigned_to_id, created_by_id, status, completed_at, photo_url, created_at) FROM stdin;
427ab77b-4395-4a01-98ff-4df04e101c7a	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	Test task	Table area	\N	ef1abc49-94d6-43dc-8f10-94eb34bb7bc1	pending	\N	\N	2026-04-29 15:03:28.203569
\.


--
-- Data for Name: restaurant_guest_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurant_guest_messages (id, property_id, table_number, sender_name, message, is_read_by_waiter, created_at) FROM stdin;
20c8b0a8-2348-4db2-a8a1-e29e8863286e	8f33f4e2-9509-4834-8efc-7705a5915129	3	Qonaq	🔔 Qaroson çağırılır	f	2026-05-07 09:09:34.424429
\.


--
-- Data for Name: restaurant_staff_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurant_staff_profiles (id, user_id, property_id, salary_amount, tax_rate, tables_assigned, notes, updated_at) FROM stdin;
\.


--
-- Data for Name: restaurant_tables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurant_tables (id, property_id, table_number, capacity, created_at) FROM stdin;
\.


--
-- Data for Name: revenues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.revenues (id, hotel_id, property_id, owner_id, booking_id, guest_id, transaction_id, room_number, category, description, amount, currency, payment_method, payment_status, source_type, created_by, created_by_name, created_at, tenant_id) FROM stdin;
5535a7e1-036d-45bb-b440-2380b21c4501	4941633e-88da-4920-92c5-6f29de45f79a	12b384d5-a4e4-4077-bd2e-8dcfb0656aee	\N	e27d63b7-999f-47bc-a1ba-d730eaa87930	0803ee24-dc71-430a-9b76-4d4885a624be	1e20a034-56fb-4ae0-9533-a6b6809c6053	101	room_booking	Room 101 booking payment	20000	USD	credit_card	paid	auto	demo_staff_1	Demo Staff	2026-02-13 14:52:20.031319	899d7a50-7ac8-4c57-b16a-035da45ab8dc
4d32ee74-cbdb-4b2e-80d7-3350c00b277a	7577111e-642c-4e59-a839-6686f47c5256	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	443f65a3-aa8a-42f6-8dae-8c5900d8ba18	254ef3be-573c-45a1-ad39-96cd40546b7d	25ca3e47-238d-461e-9537-d7757c2e82ea	505	room_booking	Room 505 booking payment	75000	USD	cash	paid	auto	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	2026-02-20 10:04:09.699148	f73182bf-6a38-4126-b94d-7ef754bc3db2
8cdae7dc-c356-427b-9cfe-c011f7683def	7577111e-642c-4e59-a839-6686f47c5256	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	c648a0ed-4ec3-4610-b476-6305e7f12048	81e76596-4329-4026-98e9-f2f040820245	864343ab-f940-44fc-82a3-f9f792b1cdd4	3	room_booking	Room 3 booking payment	75000	USD	cash	paid	auto	5928ad00-69b2-4c01-a6c5-5379c5110c4b	staf22	2026-02-20 10:18:42.29239	f73182bf-6a38-4126-b94d-7ef754bc3db2
40e3f607-3a0c-4ee9-9255-bc1d0b0ab069	4941633e-88da-4920-92c5-6f29de45f79a	\N	\N	96dff7ef-a6ef-43b8-89a9-6964ce2dd964	a3a1a731-f4f6-498f-96bb-33a8f99c5d37	96dca2ea-8c23-4eea-bfd9-206de3b4e508	702	room_booking	Room 702 booking payment	10000	USD	cash	paid	auto	demo_recep_1	Demo Reception	2026-02-24 12:16:11.933389	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
\.


--
-- Data for Name: room_nights; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.room_nights (id, unit_id, date, booking_id, tenant_id, property_id, created_at) FROM stdin;
623d2014-d2fa-4a3e-a040-b0122ced7cc6	16495a29-0043-408c-81bb-78e3717990e8	2026-03-24	62ddfb35-a3eb-4cc0-8de7-613f7106c306	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	2026-03-23 16:09:13.756088
a3dac8b0-632b-4fe8-90b1-35cc44498e75	16495a29-0043-408c-81bb-78e3717990e8	2026-03-25	62ddfb35-a3eb-4cc0-8de7-613f7106c306	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	2026-03-23 16:09:13.756088
a06fe338-7b26-4b1c-a128-ac2b4e41ab96	16495a29-0043-408c-81bb-78e3717990e8	2026-03-26	62ddfb35-a3eb-4cc0-8de7-613f7106c306	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	2026-03-23 16:09:13.756088
\.


--
-- Data for Name: room_preparation_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.room_preparation_orders (id, guest_id, hotel_id, room_number, occasion_type, decoration_style, add_ons, notes, budget_range, custom_budget, preferred_datetime, reference_image_url, price, status, staff_assigned, admin_notes, rejection_reason, created_at, updated_at, owner_id, property_id, tenant_id) FROM stdin;
\.


--
-- Data for Name: room_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.room_settings (id, booking_id, temperature, lights_on, lights_brightness, curtains_open, jacuzzi_on, jacuzzi_temperature, welcome_mode, updated_at, door_locked, curtains_position, bathroom_lights_on, bathroom_lights_brightness, hall_lights_on, hall_lights_brightness, non_dimmable_lights_on, tenant_id) FROM stdin;
99bfeaeb-1d47-435d-a067-f1f36c8e7736	340a1d5f-f7a0-451e-b718-b67e7acd74a5	22	f	50	f	f	38	t	2026-02-24 11:00:32.423664	t	0	f	50	f	50	f	demo_session_2879497c-67d8-4254-a824-fcbaea376064
a4e807d3-091c-4acd-b670-ad2449406c0b	fb36d454-1188-4c95-8f29-16b22baf9ca4	22	f	50	f	f	38	t	2026-02-24 11:01:23.116474	t	0	f	50	f	50	f	demo_session_2879497c-67d8-4254-a824-fcbaea376064
335a0edd-e186-4143-bb4e-effb74159ebd	07a20250-599d-4622-8177-a89636b29843	22	f	50	f	f	38	t	2026-02-24 11:35:53.490385	t	0	f	50	f	50	f	demo_session_3f0af152-9afc-4ef2-af0a-6cf8495bbfcc
ea8e5727-2bc8-43bc-a5d1-af658e7eeb49	e77f8cb2-35bf-488a-a50c-74704c693c93	22	f	50	f	f	38	t	2026-02-24 11:54:37.461041	t	0	f	50	f	50	f	demo_session_54d883e0-d226-42eb-84df-bb19082f7e3f
9caecfe1-7c1e-45de-b954-decbc9554096	352e587b-8bde-42fb-a6a1-91c950a5aede	22	f	50	f	f	38	t	2026-02-24 11:59:54.305864	t	0	f	50	f	50	f	demo_session_695830c5-05bd-4882-8eb6-cb868bdff80c
59e6897f-133e-4a6a-ad9b-ee3f0eeceb9e	e27d63b7-999f-47bc-a1ba-d730eaa87930	22	f	50	f	f	38	t	2026-02-13 16:50:27.17	t	0	f	75	f	60	f	\N
23f6e620-f1c0-49fc-83e9-5bab8a57d798	3201d4d2-c2d2-4b69-a97f-43d6cf727f77	22	f	50	f	f	38	t	2026-02-24 12:00:58.930252	t	0	f	50	f	50	f	demo_session_34e01e00-8509-47db-874b-3bbc6ed52284
b28614fa-720e-4c98-b05c-01ff26f2be50	e087a247-2820-43ac-a422-086647504685	22	f	50	f	f	38	t	2026-02-24 12:15:15.463911	t	0	f	50	f	50	f	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
4b834f2b-2fb5-4ef6-9fdb-48b0a192563a	96dff7ef-a6ef-43b8-89a9-6964ce2dd964	22	f	50	f	f	38	t	2026-02-24 12:16:11.89636	t	0	f	50	f	50	f	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7
491450cb-2be6-41c9-98f9-118db398625c	e7b0b3d6-1bef-4704-86bb-51f82f3c2cf6	22	f	50	f	f	38	t	2026-02-24 13:15:15.322557	t	0	f	50	f	50	f	demo_session_2c831ac8-9c02-411c-b930-799a0999b7b8
0751a83b-b5ed-4690-8080-9eaed3772f34	9867f205-79fb-4853-a858-4cb4effaf631	22	t	70	t	f	38	f	2026-05-07 13:54:50.294022	t	0	f	50	f	50	f	\N
74a9c450-2693-4194-9203-5d14fa1d8301	443f65a3-aa8a-42f6-8dae-8c5900d8ba18	22	f	50	f	f	38	t	2026-02-20 10:04:09.658086	t	0	f	50	f	50	f	f73182bf-6a38-4126-b94d-7ef754bc3db2
69dda966-49dd-4ce5-b348-decea57af538	c648a0ed-4ec3-4610-b476-6305e7f12048	22	f	50	f	f	38	t	2026-02-20 10:18:42.261639	t	0	f	50	f	50	f	f73182bf-6a38-4126-b94d-7ef754bc3db2
8607fa6c-b6ab-4583-9c94-ffbe8571036c	62ddfb35-a3eb-4cc0-8de7-613f7106c306	22	f	50	f	f	38	t	2026-03-23 16:09:13.767635	t	0	f	50	f	50	f	11405dd7-d6b6-4d46-8774-bbaa16c01f71
b221876e-13e5-4f7d-b09f-1f19c2231873	bce0f8e8-7258-4378-bb49-06e03bf2e9d5	22	f	50	f	f	38	t	2026-03-23 16:12:33.186373	t	0	f	50	f	50	f	11405dd7-d6b6-4d46-8774-bbaa16c01f71
901a5d87-014f-494f-8caa-5af1ac4d2aca	abc4b890-ae34-4fb6-ba01-bf6aaff86156	22	f	50	f	f	38	t	2026-03-23 16:12:33.630518	t	0	f	50	f	50	f	11405dd7-d6b6-4d46-8774-bbaa16c01f71
d4ac3628-ebd1-4301-a7d3-0e6b7ea504ac	d719846a-2d2f-49c8-a32f-06a43d8752c4	22	f	50	f	f	38	t	2026-03-23 16:15:53.193989	t	0	f	50	f	50	f	11405dd7-d6b6-4d46-8774-bbaa16c01f71
9830e3fc-c154-420a-b0c6-77dfdb222cad	245962ce-d1bd-46cd-9d87-6b66a77665d4	22	f	50	f	f	38	t	2026-03-23 16:16:15.765856	t	0	f	50	f	50	f	11405dd7-d6b6-4d46-8774-bbaa16c01f71
\.


--
-- Data for Name: service_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_requests (id, guest_id, booking_id, room_number, request_type, description, status, priority, assigned_to, notes, created_at, updated_at, owner_id, property_id, tenant_id) FROM stdin;
a705da5d-63f6-4e6a-b029-b54a9be48927	81e76596-4329-4026-98e9-f2f040820245	c648a0ed-4ec3-4610-b476-6305e7f12048	3	taxi	tad	pending	normal	\N	\N	2026-02-20 10:21:30.573253	2026-02-20 10:21:30.573253	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2
cc80c49d-474c-496d-a945-fd9a76dbb58c	f365edad-3a97-42f6-a549-a5ffa19348e0	9867f205-79fb-4853-a858-4cb4effaf631	202	housekeeping	Extra towels requested for room 202	in_progress	medium	\N	\N	2026-05-07 13:54:50.297631	2026-05-07 13:54:50.297631	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N
f6939cbc-7e7f-4326-a35a-7add2ff9faef	f365edad-3a97-42f6-a549-a5ffa19348e0	9867f205-79fb-4853-a858-4cb4effaf631	202	room_service	Deliver breakfast to room 202 at 08:00	pending	normal	\N	\N	2026-05-07 13:54:50.302041	2026-05-07 13:54:50.302041	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
a_zCQeVFr1b3uhFQg4OGfTe5TGDHQIay	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-13T17:53:33.465Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"07e725fb-ed49-4689-ab67-45920fe4315b","role":"owner_admin"}	2026-05-13 17:53:34
jwoQCojE95-T_rRjoNFQaZ4dANekfCMT	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-13T18:42:14.476Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"9bcf37cf-dffe-4f20-845e-3d953d7133d0","role":"owner_admin"}	2026-05-13 18:47:11
mWYoEHGN7aAbEAGPEWz7kN5L0CxSpnel	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:11:28.958Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_04edc8c5-719e-422e-b8ce-513121e6c90a"}	2026-05-11 15:11:33
fFyZ0upNtBfnRlaB250k-k26VPnifNwo	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-13T18:47:23.112Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"9bcf37cf-dffe-4f20-845e-3d953d7133d0","role":"owner_admin"}	2026-05-13 18:55:38
FwkXq99bnM8rRPLwH2yOE_TSJGLmUty2	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:53:14.251Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_f6f6a23c-951d-48f7-b77f-0129ec88e3d7"}	2026-05-11 15:53:22
QhkkX2ctOrnrn1b--buJ0gPQJ4PJeNRh	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:48:47.982Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_9199bf7e-a9ed-4482-b931-3aa8fcdbdb5e"}	2026-05-11 15:49:07
_2X_LL3l93hvb5E03Fhq9pXTto5MXM0e	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:37.482Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_fbfac078-f38a-4e16-997a-5ad0351e51c8"}	2026-05-11 15:49:38
BhTc49k2d6gkFHEPh8hhPiFBsxnGPdUH	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:37.823Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_fbfac078-f38a-4e16-997a-5ad0351e51c8"}	2026-05-11 15:49:38
M4fvLLKDqkuTUQXD-RwEinKjWFuFiX_V	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:51:49.374Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_45bb0427-7093-4a74-8aae-c8c2f196457f"}	2026-05-11 15:51:50
wlaHDKt5r1govPpkGKFbkUDGTHUZhwjr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:51:49.816Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_45bb0427-7093-4a74-8aae-c8c2f196457f"}	2026-05-11 15:51:50
NbAm_ZK9k6-r9tzwUEfn6pHQdU9Z4x1Y	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:51:50.075Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_45bb0427-7093-4a74-8aae-c8c2f196457f"}	2026-05-11 15:51:51
JHR8ZLlD6gD-E6RfSA7m85zoRKxSybtB	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:51:50.334Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_45bb0427-7093-4a74-8aae-c8c2f196457f"}	2026-05-11 15:51:51
wiSTFsxHBheD2gsC_9pCGrqjk4glUvAQ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-13T15:35:34.659Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"ded08335-b52a-4093-ab0a-875dbfe20c20","role":"restaurant_manager","demoSessionTenantId":"demo_session_9657bdfd-65fd-4ed8-8602-bc0281786945"}	2026-05-13 15:35:37
_P4-lweQiT3nqF7nHPbFjms6RwcixiOE	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-12T09:27:46.046Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"69d2ec0e-d832-4477-b631-c1d03de733ce","role":"oss_super_admin"}	2026-05-12 09:27:47
9u34-Abb4uSlq67xzkAS9ruOl8Mrueq0	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-12T09:27:31.057Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"69d2ec0e-d832-4477-b631-c1d03de733ce","role":"oss_super_admin"}	2026-05-12 09:28:11
MOdvE8VUUtUrU9boqHEuqFghzWclBztQ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:55:04.263Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"d5bafbda-322b-4a13-8c87-18b227575be0","role":"owner_admin"}	2026-05-11 15:55:07
FVD7HcXybdwq2LyKazTPxUCdXInL_xxv	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-14T13:54:50.423Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"9e24c346-6f7c-47c6-93a2-9b17fda0c4dc","role":"waiter","demoSessionTenantId":"demo_session_8e701eda-9dd1-403d-bab3-001d4456b5af"}	2026-05-14 15:39:27
xpwLma_xrsZ4_JC37awN4YQLcIaExIT8	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:55:02.672Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_33eabc10-6419-446b-aeeb-ac78d5f75082"}	2026-05-11 15:55:03
GtwezvdB2yLuewCxTi6wWdravzvIxCcp	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:55:03.071Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_33eabc10-6419-446b-aeeb-ac78d5f75082"}	2026-05-11 15:55:04
1DKXi4y_oLHgKPlj-HwYk_YXnok2DrV3	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:12:03.288Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_a945395a-8f67-4812-9cf6-623d936b8dc0"}	2026-05-11 15:12:05
rd8sxc3N1v49Jze-ZPSFx4Dqt_aGtzuG	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:55:03.432Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_33eabc10-6419-446b-aeeb-ac78d5f75082"}	2026-05-11 15:55:04
aC7ABK9Yj1OCUexlPnwSsSwPu3YYYCMM	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:12:21.623Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_7c881ce1-b292-4055-8a09-ed8366e7770a"}	2026-05-11 15:12:23
W8RDt9h_vPtAmjulMDnhhhNEg4-u_S2i	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:55:03.810Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_33eabc10-6419-446b-aeeb-ac78d5f75082"}	2026-05-11 15:55:04
thuOkatIt2dzlnWHJ9AmOwjiK9N1VrgQ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:09.835Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_d06d31c8-94b7-45fe-bd48-815572746f9b"}	2026-05-11 15:49:10
KnMlndNwgmSpdzfxrP7XpbOEucwo1oPJ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T16:03:53.570Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"69d2ec0e-d832-4477-b631-c1d03de733ce","role":"oss_super_admin"}	2026-05-11 16:03:54
VWkQhIK7bZzmX1BSyYOQwRsHSOHhT6hl	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:50:26.249Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_58be3da1-b40c-471b-8e61-5355913f4627"}	2026-05-11 15:50:27
3KGrWQ9B4fC8sjOAbD7K-cixwkxcHsS_	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:50:26.601Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_58be3da1-b40c-471b-8e61-5355913f4627"}	2026-05-11 15:50:27
oSPa4Non6xbVZKYMXH5FAgJeJhxDwv5A	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:50:26.747Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_58be3da1-b40c-471b-8e61-5355913f4627"}	2026-05-11 15:50:27
_PyVHJZ-ivT7pDYpp55137K3r6UxAPRG	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:12:14.971Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_b017e71e-c004-4fd2-8f05-e420a5e17a96"}	2026-05-11 15:12:15
Qu_UL6SA1FJeKG8ieu6UlSRZ4xlD0vZY	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:19.527Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_4442a925-b3cd-4f8c-9ccc-23a852d27d07"}	2026-05-11 15:49:20
L4VuADn-f56e3D1TjDym77C0_KihVaKl	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:19.917Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_4442a925-b3cd-4f8c-9ccc-23a852d27d07"}	2026-05-11 15:49:20
vOjMi1gniNoeVFvCzC1j3LK4xRJCENvl	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:20.175Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_4442a925-b3cd-4f8c-9ccc-23a852d27d07"}	2026-05-11 15:49:21
s1s7NiAhXG-GJjOzfF3akWUzZo2QTtEr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:20.441Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_4442a925-b3cd-4f8c-9ccc-23a852d27d07"}	2026-05-11 15:49:21
MFpbJ7aSDd7CHGsVs_ecG_VI13-g3YYA	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:49:20.663Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_4442a925-b3cd-4f8c-9ccc-23a852d27d07"}	2026-05-11 15:49:21
0EeA8HWkUrpSDRDN5mUPfriTg3xxwb64	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:50:45.710Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_d1a95c48-a43f-48ce-8044-752ef0e2d71b"}	2026-05-11 15:50:46
3ZV9_IO9DJ2Sl3bC6mmrBW4Jkd5aKdZt	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:50:46.301Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_d1a95c48-a43f-48ce-8044-752ef0e2d71b"}	2026-05-11 15:50:47
_6m-eVvnpfF40YRKrLjhBkP421x4_8j2	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T15:50:46.439Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"62797tA7","role":"owner_admin","demoSessionTenantId":"demo_session_d1a95c48-a43f-48ce-8044-752ef0e2d71b"}	2026-05-11 15:50:47
zfPySOK6D9sN7OF-5Xws2_cvfoqQDU8y	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-11T16:04:36.942Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"69d2ec0e-d832-4477-b631-c1d03de733ce","role":"oss_super_admin"}	2026-05-11 16:04:38
aydrSZTZtlmxosc0wwI0h0WBOoG8Ps7G	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-12T09:51:10.435Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"69d2ec0e-d832-4477-b631-c1d03de733ce","role":"oss_super_admin"}	2026-05-12 09:51:11
4agSLavoPaVum3Nk8mv3Ay6J63JHPbeg	{"cookie":{"originalMaxAge":604800000,"expires":"2026-05-12T09:51:16.532Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"69d2ec0e-d832-4477-b631-c1d03de733ce","role":"oss_super_admin"}	2026-05-12 09:51:17
\.


--
-- Data for Name: staff_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_feedback (id, owner_id, staff_id, hotel_id, tenant_id, type, reason, score_impact, created_at) FROM stdin;
\.


--
-- Data for Name: staff_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_invitations (id, property_id, owner_id, email, staff_role, status, invited_by, accepted_by, invite_token, created_at, updated_at, tenant_id) FROM stdin;
df71356f-946e-480c-b13d-c595500d2296	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	ramin.v@orange-studio.az	front_desk	pending	8317f3c8-f1f9-4b9f-8570-25968af7ef28	\N	1c26decc-13ec-4ab3-bddd-268b029f9a25	2026-02-19 16:42:15.095139	2026-02-19 16:42:15.095139	\N
07ad2ca1-da8d-4cf1-930e-56176c9cf2c3	fb04e537-345b-4e39-9d19-959e2eded6dc	f73182bf-6a38-4126-b94d-7ef754bc3db2	ramin.v@orange-studio.az	front_desk	accepted	8da0da3f-8e4a-4623-ac41-789ee316b827	5928ad00-69b2-4c01-a6c5-5379c5110c4b	f32f3b2b-1762-44f5-b97e-3ad86ebc54d2	2026-02-20 09:33:02.660849	2026-02-20 09:34:09.741	\N
c677f64b-26b6-4ae6-ac6a-7ed123bd27b4	fb04e537-345b-4e39-9d19-959e2eded6dc	f73182bf-6a38-4126-b94d-7ef754bc3db2	ramin.v@orange-studio.az	front_desk	accepted	8da0da3f-8e4a-4623-ac41-789ee316b827	b7c11396-9a5a-48a3-8443-9e2e199ac124	e69c9bf3-5a87-4b6b-ab53-7bb344797659	2026-02-20 09:38:30.961437	2026-02-20 09:39:26.129	\N
02dd3ac4-3d74-4c98-aba4-e4cbb40413a5	b8762915-3c99-457c-84ff-42190b4a4440	13a6c421-6b54-4799-8a9d-b3bb456ef0da	rnurullayeva@gmail.com	manager	pending	e66113d2-4e1e-4635-8ef6-8d3c8ad3bfdb	\N	89a4bf2c-e2e6-4681-822e-61c34886b9eb	2026-02-20 11:53:27.090694	2026-02-20 11:53:27.090694	\N
d44e36ad-b69e-4576-878a-f4502bbb3768	b8762915-3c99-457c-84ff-42190b4a4440	13a6c421-6b54-4799-8a9d-b3bb456ef0da	ramin.v@orange-studio.az	front_desk	accepted	e66113d2-4e1e-4635-8ef6-8d3c8ad3bfdb	853b0e41-82f6-48bc-b8ed-7b7ea052b3d4	aa5c4f24-28d2-4b22-86bc-e1d4386f89a9	2026-02-20 11:55:15.61842	2026-02-20 12:02:44.922	\N
f1c5b5cb-9201-4016-b317-73ec38b5d94d	b8762915-3c99-457c-84ff-42190b4a4440	13a6c421-6b54-4799-8a9d-b3bb456ef0da	attila.nikbakht1988@gmail.com	front_desk	pending	e66113d2-4e1e-4635-8ef6-8d3c8ad3bfdb	\N	e79f1711-2174-4e4d-8f40-ca038a7bb307	2026-02-20 12:05:11.33811	2026-02-20 12:05:11.33811	\N
d30b7bd9-7f68-4608-9c2e-1059ab5845df	b8762915-3c99-457c-84ff-42190b4a4440	13a6c421-6b54-4799-8a9d-b3bb456ef0da	ramin.v@orange-studio.az	front_desk	accepted	e66113d2-4e1e-4635-8ef6-8d3c8ad3bfdb	480eaa8f-5d14-4f0b-8a19-25c9d2725527	8cb4c86a-8339-47c3-91b7-51dadc4926c1	2026-02-20 12:06:14.918808	2026-02-20 12:07:07.638	\N
\.


--
-- Data for Name: staff_message_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_message_status (id, message_id, staff_id, is_read, read_at) FROM stdin;
\.


--
-- Data for Name: staff_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_messages (id, hotel_id, tenant_id, sender_role, sender_id, message_text, created_at) FROM stdin;
\.


--
-- Data for Name: staff_performance_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_performance_scores (id, staff_id, hotel_id, tenant_id, message_response_score, task_completion_score, service_quality_score, activity_score, manual_adjustment, total_score, period, calculated_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, owner_id, plan_type, feature_flags, max_properties, max_units_per_property, start_date, end_date, is_active, created_at, tenant_id, trial_ends_at, smart_plan_type, max_staff, multi_property, performance_enabled, staff_performance_enabled, advanced_analytics, priority_support, custom_integrations, smart_rooms_enabled, guest_management, staff_management, plan_code, status, current_period_start, current_period_end, auto_renew, cancel_at_period_end, failed_payment_attempts, last_payment_order_id, updated_at) FROM stdin;
b641d94c-e1df-49fd-be1b-14cac5c183de	6bc37ae9-1cac-4cf0-920a-2c54d018cb53	pro	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	999	50	2026-02-20 08:08:49.378579	\N	t	2026-02-20 08:08:49.378579	6bc37ae9-1cac-4cf0-920a-2c54d018cb53	\N	none	999	t	t	t	t	f	f	f	t	t	CORE_PRO	active	2026-02-20 08:08:49.378579	\N	t	f	0	\N	2026-03-05 14:50:56.998986
69988c98-f408-4072-af0f-c797601ed44b	87772a76-ada5-4dc6-bacf-9e949d17ffc6	basic	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-14 14:41:51.816722	\N	t	2026-02-14 14:41:51.816722	\N	\N	none	0	f	f	f	f	f	f	f	t	f	CORE_STARTER	active	2026-02-14 14:41:51.816722	\N	t	f	0	\N	2026-03-05 14:50:56.998986
bbc25f1d-0b52-4a5b-a590-581a14d4c495	afa0de93-1326-4fe4-a339-f65121ba4bcb	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-19 16:41:22.893866	\N	t	2026-02-19 16:41:22.893866	\N	2026-03-05 16:41:22.892	none	0	f	f	f	f	f	f	f	t	f	CORE_STARTER	trial	2026-02-19 16:41:22.893866	2026-03-05 16:41:22.892	t	f	0	\N	2026-03-05 14:50:56.998986
4454b8ac-573b-4715-8958-659a0fa767d9	02d18ce6-ec09-48c3-948e-741eeceaee86	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-19 16:43:35.768715	\N	t	2026-02-19 16:43:35.768715	\N	2026-03-05 16:43:35.767	none	0	f	f	f	f	f	f	f	t	f	CORE_STARTER	trial	2026-02-19 16:43:35.768715	2026-03-05 16:43:35.767	t	f	0	\N	2026-03-05 14:50:56.998986
d0ff1cfa-fee5-41eb-be92-c23d29af23be	6dec171d-d048-47d4-a5d4-1476a7b5390a	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-19 17:05:59.846438	\N	t	2026-02-19 17:05:59.846438	\N	2026-03-05 17:05:59.845	none	0	f	f	f	f	f	f	f	t	f	CORE_STARTER	trial	2026-02-19 17:05:59.846438	2026-03-05 17:05:59.845	t	f	0	\N	2026-03-05 14:50:56.998986
14826b60-3a2f-4ab0-a011-9b0df47c4a95	ac506214-8952-45da-97f0-0e771f8543a2	pro	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-20 06:40:15.892145	\N	t	2026-02-20 06:40:15.892145	\N	\N	none	0	t	t	t	t	t	t	f	t	t	CORE_PRO	active	2026-02-20 06:40:15.892145	\N	t	f	0	\N	2026-03-05 14:50:56.998986
a03b93e9-67d1-4f8d-9e31-a42abb02132e	11405dd7-d6b6-4d46-8774-bbaa16c01f71	pro	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	999	999	2026-02-19 17:35:05.786422	\N	t	2026-02-19 17:35:05.786422	\N	2026-03-05 17:35:05.785	none	999	t	t	t	t	t	t	f	t	t	CORE_PRO	active	2026-02-19 17:35:05.786422	2026-03-05 17:35:05.785	t	f	0	\N	2026-03-05 14:50:56.998986
69a9dd82-e13d-4093-8ff3-2d4327cb7b93	495c33fe-a392-439a-aec7-39d639d8b45c	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-19 17:38:52.942583	\N	t	2026-02-19 17:38:52.942583	\N	2026-03-05 17:38:52.941	none	0	f	f	f	f	f	f	f	t	f	CORE_STARTER	trial	2026-02-19 17:38:52.942583	2026-03-05 17:38:52.941	t	f	0	\N	2026-03-05 14:50:56.998986
f223fd8b-ccf5-4c06-a763-5f910f185d24	a8d4b603-ad1a-4807-ad4d-d992076c5892	starter	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-19 18:40:15.293789	\N	t	2026-02-19 18:40:15.293789	\N	2026-03-05 18:40:15.292	none	5	f	f	f	f	f	f	f	t	t	CORE_STARTER	active	2026-02-19 18:40:15.293789	2026-03-05 18:40:15.292	t	f	0	\N	2026-03-05 14:50:56.998986
fa1c936c-e9f8-47e6-871e-786b6c08ff2b	e333d1d7-db91-4f5a-a85b-f78b25df2b53	pro	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-20 07:49:44.040379	\N	t	2026-02-20 07:49:44.040379	\N	\N	none	0	t	t	t	t	t	t	f	t	t	CORE_PRO	active	2026-02-20 07:49:44.040379	\N	t	f	0	\N	2026-03-05 14:50:56.998986
24125f46-265e-4ebf-89bf-9748c53fe1a9	bc78df31-2b2a-4daa-a3d8-51a0ca8baa10	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	999	999	2026-02-20 08:50:33.274465	\N	t	2026-02-20 08:50:33.274465	\N	2026-03-06 08:50:33.273	none	999	t	t	t	t	t	t	f	t	t	CORE_PRO	trial	2026-02-20 08:50:33.274465	2026-03-06 08:50:33.273	t	f	0	\N	2026-03-05 14:50:56.998986
cc115603-caf0-4b91-850a-6b464abd5c1b	ae2ddc1d-50dc-489d-b690-73465af34a13	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-02-20 08:56:25.591465	\N	t	2026-02-20 08:56:25.591465	\N	2026-03-06 08:56:25.59	none	5	f	f	f	f	f	f	f	t	t	CORE_STARTER	trial	2026-02-20 08:56:25.591465	2026-03-06 08:56:25.59	t	f	0	\N	2026-03-05 14:50:56.998986
941d5e52-118b-42d1-9252-6ead3f46b1da	f73182bf-6a38-4126-b94d-7ef754bc3db2	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	3	30	2026-02-20 09:25:24.026101	\N	t	2026-02-20 09:25:24.026101	\N	2026-03-06 09:25:24.025	none	20	t	t	t	t	f	f	f	t	t	CORE_GROWTH	trial	2026-02-20 09:25:24.026101	2026-03-06 09:25:24.025	t	f	0	\N	2026-03-05 14:50:56.998986
accbb303-268b-431f-8c07-f1a30238efbc	4b40a969-f41d-4722-bf60-e60829e7bc90	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	20	2026-03-04 10:02:21.157543	\N	t	2026-03-04 10:02:21.157543	\N	2026-03-18 10:02:21.156	none	5	f	f	f	f	f	f	f	t	t	CORE_STARTER	trial	2026-03-04 10:02:21.157543	2026-03-18 10:02:21.156	t	f	0	\N	2026-03-05 14:50:56.998986
42d0881c-7996-4fc3-b9d2-5763444d8ba1	e1ac24e3-e692-44cb-b829-d2d3920a2324	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	3	30	2026-04-29 08:45:21.018546	\N	t	2026-04-29 08:45:21.018546	\N	2026-05-13 08:45:21.017	none	20	t	t	t	t	f	f	f	t	t	CORE_GROWTH	active	2026-04-29 08:45:21.018546	\N	t	f	0	\N	2026-04-29 08:45:21.018546
dd322694-a454-42ce-9f68-819c372fbb60	11e77135-6f73-422d-8b48-244d2137c1e6	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	3	30	2026-03-05 15:06:34.956397	\N	f	2026-03-05 15:06:34.956397	\N	2026-03-19 15:06:34.955	none	20	t	t	t	t	f	f	f	t	t	CORE_GROWTH	expired	2026-03-05 15:06:34.956397	\N	t	f	0	\N	2026-04-29 09:45:51.678
0915e60b-c046-4f5a-ab4f-8ac99a13a240	a25bc5e3-4dfe-49c9-899c-f15b8dd8da75	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	20	2026-05-04 15:55:03.967464	\N	t	2026-05-04 15:55:03.967464	\N	2026-05-18 15:55:03.966	none	5	f	f	f	f	f	f	f	t	t	CORE_STARTER	trial	2026-05-04 15:55:03.967464	\N	t	f	0	\N	2026-05-04 15:55:03.967464
7cfa5122-3139-4be5-87e4-6418b8616eb7	1abed867-520f-42c0-87cb-836763296852	pro	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	999	999	2026-05-04 16:04:37.152001	\N	t	2026-05-04 16:04:37.152001	\N	2026-05-18 16:04:37.146	none	999	t	t	t	t	t	t	f	t	t	CORE_PRO	trial	2026-05-04 16:04:37.152001	\N	t	f	0	\N	2026-05-04 16:04:37.152001
56dc2ac3-8a80-487a-9956-a8f1dfd3edda	7402ec1b-29e9-4041-86d5-711beacb39e7	pro	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	999	999	2026-02-20 10:24:50.800867	\N	t	2026-02-20 10:24:50.800867	\N	2026-06-03 16:04:37.347	none	999	t	t	t	t	t	t	f	t	t	CORE_PRO	trial	2026-02-20 10:24:50.800867	2026-03-06 10:24:50.8	t	f	0	\N	2026-05-04 16:04:37.35
5b4e046a-06a6-4cc7-92f8-312d53e79404	1aa25103-7061-4340-b939-98fed23f74e3	basic	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	50	2026-05-06 18:27:54.047158	\N	t	2026-05-06 18:27:54.047158	\N	2026-05-20 18:27:54.045	none	5	f	f	f	f	f	f	f	t	f	REST_BISTRO	trial	2026-05-06 18:27:54.045	2026-05-20 18:27:54.045	t	f	0	\N	2026-05-06 18:27:54.047158
d2743666-aaf2-43fa-83b0-0d855ecced58	adfa9924-8b80-4edb-9481-a67feac2580f	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	20	2026-05-06 17:53:33.520097	\N	t	2026-05-06 17:53:33.520097	\N	2026-05-20 17:53:33.518	none	5	f	f	f	f	f	f	f	t	t	REST_CAFE	trial	2026-05-07 09:12:09.166377	2026-05-20 17:53:33.518	t	f	0	\N	2026-05-06 17:53:33.520097
2579ad32-1817-4ed1-9fe9-cf72eee2dbca	4251c73f-843a-49a7-ad6f-991e94b408db	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	20	2026-03-28 11:25:36.29873	\N	t	2026-03-28 11:25:36.29873	\N	2026-06-06 09:12:13.626938	none	5	f	f	f	f	f	f	f	t	t	CORE_STARTER	trial	2026-05-07 09:12:13.626938	2026-06-06 09:12:13.626938	t	f	0	\N	2026-03-28 11:25:36.29873
0bb6711f-4440-4b28-8b6b-37f3ab9bd4ef	e10e1ae2-7ac4-4814-8db4-b701c457309d	trial	{"analytics": true, "smart_room": true, "iot_devices": false, "ai_concierge": false}	1	20	2026-03-11 12:47:41.411587	\N	t	2026-03-11 12:47:41.411587	\N	2026-06-06 09:12:17.830667	none	5	f	f	f	f	f	f	f	t	t	CORE_STARTER	trial	2026-05-07 09:12:17.830667	2026-06-06 09:12:17.830667	t	f	0	\N	2026-03-11 12:47:41.411587
\.


--
-- Data for Name: tax_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_configurations (id, hotel_id, tenant_id, name, code, rate, is_inclusive, applies_to, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units (id, property_id, owner_id, unit_number, unit_type, name, floor, capacity, description, amenities, price_per_night, status, is_active, created_at, unit_category, tenant_id) FROM stdin;
fc12fb0e-71ce-42ef-9b67-e5da59ef8a8c	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:41:48.39079	accommodation	afa0de93-1326-4fe4-a339-f65121ba4bcb
57c504dc-e14e-4f1a-9b6f-657a9777a904	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:41:48.396404	accommodation	afa0de93-1326-4fe4-a339-f65121ba4bcb
95e1d529-6ee1-45b3-ad9d-8aa1d7436d5c	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:41:48.40026	accommodation	afa0de93-1326-4fe4-a339-f65121ba4bcb
6bab022a-e559-4840-8457-72c6f85c5809	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:41:48.403775	accommodation	afa0de93-1326-4fe4-a339-f65121ba4bcb
943af9a5-4f48-4ec8-b8ff-2edc683575ad	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:41:48.407096	accommodation	afa0de93-1326-4fe4-a339-f65121ba4bcb
0a9ccd10-3cfa-42eb-85e5-6988cfe6db0b	579129ae-3ff4-42ec-825a-61c7c5319d85	afa0de93-1326-4fe4-a339-f65121ba4bcb	r	parking_spot	r	\N	\N	\N	\N	\N	available	t	2026-02-19 16:42:37.138604	parking	\N
8ad08901-c063-443c-8105-977089e42513	e2475222-a91c-4167-b334-99f020731951	02d18ce6-ec09-48c3-948e-741eeceaee86	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:43:54.936141	accommodation	02d18ce6-ec09-48c3-948e-741eeceaee86
6980f2f0-f4a8-497d-9e98-2f5b373a8201	e2475222-a91c-4167-b334-99f020731951	02d18ce6-ec09-48c3-948e-741eeceaee86	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:43:54.939888	accommodation	02d18ce6-ec09-48c3-948e-741eeceaee86
1bcf15a6-a751-4851-b6ab-7087608c6eff	e2475222-a91c-4167-b334-99f020731951	02d18ce6-ec09-48c3-948e-741eeceaee86	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:43:54.943347	accommodation	02d18ce6-ec09-48c3-948e-741eeceaee86
7354e460-0db4-437d-9ee5-8b66e0b62a40	e2475222-a91c-4167-b334-99f020731951	02d18ce6-ec09-48c3-948e-741eeceaee86	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:43:54.946451	accommodation	02d18ce6-ec09-48c3-948e-741eeceaee86
8ce043fc-6186-4847-b622-95c6b42158ff	e2475222-a91c-4167-b334-99f020731951	02d18ce6-ec09-48c3-948e-741eeceaee86	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 16:43:54.949685	accommodation	02d18ce6-ec09-48c3-948e-741eeceaee86
13bb196a-6f78-4e8e-991f-3f426f5a4d00	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	6dec171d-d048-47d4-a5d4-1476a7b5390a	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:06:16.64123	accommodation	6dec171d-d048-47d4-a5d4-1476a7b5390a
9814fe4e-fc0b-40a1-9c9d-ce6334fff8d3	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	6dec171d-d048-47d4-a5d4-1476a7b5390a	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:06:16.646166	accommodation	6dec171d-d048-47d4-a5d4-1476a7b5390a
87f8257d-e9b8-49ef-8532-4c17fbd8bd48	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	6dec171d-d048-47d4-a5d4-1476a7b5390a	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:06:16.652036	accommodation	6dec171d-d048-47d4-a5d4-1476a7b5390a
573caeb1-03dd-41bb-85a4-d7743af5b45a	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	6dec171d-d048-47d4-a5d4-1476a7b5390a	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:06:16.656516	accommodation	6dec171d-d048-47d4-a5d4-1476a7b5390a
52818049-5ca2-4a92-8309-d4d7e06d2ff3	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	6dec171d-d048-47d4-a5d4-1476a7b5390a	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:06:16.660712	accommodation	6dec171d-d048-47d4-a5d4-1476a7b5390a
7678e187-a5a0-4366-ae52-6f0741be0279	c43b9ca9-7855-43b7-8c41-d2863b88e47a	495c33fe-a392-439a-aec7-39d639d8b45c	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:39:11.773945	accommodation	495c33fe-a392-439a-aec7-39d639d8b45c
1e261d2e-4f2e-4ed1-abe7-9ef582d1e7f2	c43b9ca9-7855-43b7-8c41-d2863b88e47a	495c33fe-a392-439a-aec7-39d639d8b45c	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:39:11.777784	accommodation	495c33fe-a392-439a-aec7-39d639d8b45c
aa87e39c-c009-4527-ae19-adc2174a4310	c43b9ca9-7855-43b7-8c41-d2863b88e47a	495c33fe-a392-439a-aec7-39d639d8b45c	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:39:11.78384	accommodation	495c33fe-a392-439a-aec7-39d639d8b45c
7e939f3f-498c-4c41-b662-bef60613bf03	c43b9ca9-7855-43b7-8c41-d2863b88e47a	495c33fe-a392-439a-aec7-39d639d8b45c	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:39:11.787352	accommodation	495c33fe-a392-439a-aec7-39d639d8b45c
22e5307e-f47b-480c-8b4a-4d7a2199340f	c43b9ca9-7855-43b7-8c41-d2863b88e47a	495c33fe-a392-439a-aec7-39d639d8b45c	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 17:39:11.79498	accommodation	495c33fe-a392-439a-aec7-39d639d8b45c
405b1936-85df-4df7-b9f6-143b0f9d15a3	72122e33-d1a4-4805-bae0-57c020b13ce6	a8d4b603-ad1a-4807-ad4d-d992076c5892	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 18:40:34.223394	accommodation	a8d4b603-ad1a-4807-ad4d-d992076c5892
4f3f2397-0091-47e1-895f-a9f65e9317b2	72122e33-d1a4-4805-bae0-57c020b13ce6	a8d4b603-ad1a-4807-ad4d-d992076c5892	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 18:40:34.227191	accommodation	a8d4b603-ad1a-4807-ad4d-d992076c5892
79256013-1582-461d-8209-58e4974191fb	72122e33-d1a4-4805-bae0-57c020b13ce6	a8d4b603-ad1a-4807-ad4d-d992076c5892	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 18:40:34.230474	accommodation	a8d4b603-ad1a-4807-ad4d-d992076c5892
d454003d-c1dc-488d-9a75-55f20a8c5aee	72122e33-d1a4-4805-bae0-57c020b13ce6	a8d4b603-ad1a-4807-ad4d-d992076c5892	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 18:40:34.233692	accommodation	a8d4b603-ad1a-4807-ad4d-d992076c5892
204a8c14-89c1-4df4-b685-44f0ddef5cd9	72122e33-d1a4-4805-bae0-57c020b13ce6	a8d4b603-ad1a-4807-ad4d-d992076c5892	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-19 18:40:34.237043	accommodation	a8d4b603-ad1a-4807-ad4d-d992076c5892
990638c1-7659-4637-b72a-825344177eb4	af2cc7de-c86c-485f-bc92-d0125ec094fb	ac506214-8952-45da-97f0-0e771f8543a2	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 06:40:33.38056	accommodation	ac506214-8952-45da-97f0-0e771f8543a2
10f09b79-51ae-4197-8f65-464311dfca5a	af2cc7de-c86c-485f-bc92-d0125ec094fb	ac506214-8952-45da-97f0-0e771f8543a2	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 06:40:33.389689	accommodation	ac506214-8952-45da-97f0-0e771f8543a2
fe932d16-4fe9-4f12-a50b-899ba83777fe	af2cc7de-c86c-485f-bc92-d0125ec094fb	ac506214-8952-45da-97f0-0e771f8543a2	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 06:40:33.393093	accommodation	ac506214-8952-45da-97f0-0e771f8543a2
5a8543f5-5e2b-49de-bd4b-c052e801284a	af2cc7de-c86c-485f-bc92-d0125ec094fb	ac506214-8952-45da-97f0-0e771f8543a2	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 06:40:33.396543	accommodation	ac506214-8952-45da-97f0-0e771f8543a2
7700b8b4-b190-4418-9a7d-458001e7735e	af2cc7de-c86c-485f-bc92-d0125ec094fb	ac506214-8952-45da-97f0-0e771f8543a2	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 06:40:33.400093	accommodation	ac506214-8952-45da-97f0-0e771f8543a2
8298acb9-8eed-45d7-b096-3df6e690b767	b0803298-c2e9-44ac-b28d-4866be2e217e	ae2ddc1d-50dc-489d-b690-73465af34a13	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 08:57:18.924002	accommodation	ae2ddc1d-50dc-489d-b690-73465af34a13
33744b78-a0fb-44de-8bef-c0ca444ded54	b0803298-c2e9-44ac-b28d-4866be2e217e	ae2ddc1d-50dc-489d-b690-73465af34a13	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 08:57:18.927008	accommodation	ae2ddc1d-50dc-489d-b690-73465af34a13
27a2c08c-0240-4aa4-a528-c36ad55e38db	b0803298-c2e9-44ac-b28d-4866be2e217e	ae2ddc1d-50dc-489d-b690-73465af34a13	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 08:57:18.929994	accommodation	ae2ddc1d-50dc-489d-b690-73465af34a13
4c517173-f46b-4094-bbf9-77e9505d18ad	b0803298-c2e9-44ac-b28d-4866be2e217e	ae2ddc1d-50dc-489d-b690-73465af34a13	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 08:57:18.933434	accommodation	ae2ddc1d-50dc-489d-b690-73465af34a13
ed69358c-9986-430c-a117-56cd3fc31e3e	b0803298-c2e9-44ac-b28d-4866be2e217e	ae2ddc1d-50dc-489d-b690-73465af34a13	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 08:57:18.936336	accommodation	ae2ddc1d-50dc-489d-b690-73465af34a13
496ff178-99c3-4ca6-87a2-8f2dd8c30589	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 09:25:45.42259	accommodation	f73182bf-6a38-4126-b94d-7ef754bc3db2
0bec17d5-e0ba-4356-8753-2fe97710fd30	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 09:25:45.426793	accommodation	f73182bf-6a38-4126-b94d-7ef754bc3db2
81c3dd13-3e8f-4ecc-9aa6-f1f062dc84d2	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 09:25:45.431391	accommodation	f73182bf-6a38-4126-b94d-7ef754bc3db2
8177964e-202b-4c47-9d35-68d8af78fc43	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 09:25:45.435121	accommodation	f73182bf-6a38-4126-b94d-7ef754bc3db2
974efd53-d2da-410e-8ef7-9ff00fe06b0b	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	f73182bf-6a38-4126-b94d-7ef754bc3db2	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 09:25:45.438852	accommodation	f73182bf-6a38-4126-b94d-7ef754bc3db2
5b6682d1-cf89-4b10-a4d2-3cf4111d0a38	fb04e537-345b-4e39-9d19-959e2eded6dc	f73182bf-6a38-4126-b94d-7ef754bc3db2	1	room	2	1	2	\N	\N	\N	available	t	2026-02-20 09:27:09.940009	accommodation	\N
5a4535f8-7791-4418-9f1f-6fc3e14c23bb	2196d0ed-08de-474f-a104-d0c0d5f8fb02	7402ec1b-29e9-4041-86d5-711beacb39e7	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 10:25:21.148886	accommodation	7402ec1b-29e9-4041-86d5-711beacb39e7
6bf4f149-09db-4408-8ff1-ef31ed0fb9b7	2196d0ed-08de-474f-a104-d0c0d5f8fb02	7402ec1b-29e9-4041-86d5-711beacb39e7	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 10:25:21.152442	accommodation	7402ec1b-29e9-4041-86d5-711beacb39e7
bd469b10-64ef-4353-9c88-026bf66a504e	2196d0ed-08de-474f-a104-d0c0d5f8fb02	7402ec1b-29e9-4041-86d5-711beacb39e7	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 10:25:21.15518	accommodation	7402ec1b-29e9-4041-86d5-711beacb39e7
14b9b0e6-422b-4398-8b2b-a6d0fd2fe0c9	2196d0ed-08de-474f-a104-d0c0d5f8fb02	7402ec1b-29e9-4041-86d5-711beacb39e7	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 10:25:21.158329	accommodation	7402ec1b-29e9-4041-86d5-711beacb39e7
e1abaa2e-1dcc-4aec-a1fe-40badc10627a	2196d0ed-08de-474f-a104-d0c0d5f8fb02	7402ec1b-29e9-4041-86d5-711beacb39e7	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-02-20 10:25:21.160804	accommodation	7402ec1b-29e9-4041-86d5-711beacb39e7
unit-103	prop-test-rs	899d7a50-7ac8-4c57-b16a-035da45ab8dc	103	suite	\N	2	4	\N	\N	\N	ready	t	2026-02-24 12:31:02.57518	accommodation	899d7a50-7ac8-4c57-b16a-035da45ab8dc
unit-102	prop-test-rs	899d7a50-7ac8-4c57-b16a-035da45ab8dc	102	room	\N	1	2	\N	\N	\N	dirty	t	2026-02-24 12:31:02.57518	accommodation	899d7a50-7ac8-4c57-b16a-035da45ab8dc
unit-101	prop-test-rs	899d7a50-7ac8-4c57-b16a-035da45ab8dc	101	room	\N	1	2	\N	\N	\N	ready	t	2026-02-24 12:31:02.57518	accommodation	899d7a50-7ac8-4c57-b16a-035da45ab8dc
c0bba3df-f098-49a5-8e58-17b6243e3f2f	d7bb67a8-f871-42d1-a78f-1115b35f04e9	e10e1ae2-7ac4-4814-8db4-b701c457309d	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-03-11 12:47:52.137034	accommodation	e10e1ae2-7ac4-4814-8db4-b701c457309d
e3021e41-40a4-4200-8cd5-cd54c0ac4021	d7bb67a8-f871-42d1-a78f-1115b35f04e9	e10e1ae2-7ac4-4814-8db4-b701c457309d	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-03-11 12:47:52.144074	accommodation	e10e1ae2-7ac4-4814-8db4-b701c457309d
858f45fa-0b2f-4728-be3f-7d63ff054a83	d7bb67a8-f871-42d1-a78f-1115b35f04e9	e10e1ae2-7ac4-4814-8db4-b701c457309d	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-03-11 12:47:52.146376	accommodation	e10e1ae2-7ac4-4814-8db4-b701c457309d
71ceef16-4d3d-4165-8c82-835e6756242e	d7bb67a8-f871-42d1-a78f-1115b35f04e9	e10e1ae2-7ac4-4814-8db4-b701c457309d	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-03-11 12:47:52.149692	accommodation	e10e1ae2-7ac4-4814-8db4-b701c457309d
e25f05f8-a540-4c06-a0e1-c828d1ad9e13	d7bb67a8-f871-42d1-a78f-1115b35f04e9	e10e1ae2-7ac4-4814-8db4-b701c457309d	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-03-11 12:47:52.152929	accommodation	e10e1ae2-7ac4-4814-8db4-b701c457309d
20ff0ed2-8956-4ddc-8456-8e1650f3e3d1	1008e1af-da16-465b-9812-12a2ae80d378	4251c73f-843a-49a7-ad6f-991e94b408db	VIL-001	villa	\N	\N	2	\N	\N	100	available	t	2026-03-28 11:26:17.392095	accommodation	4251c73f-843a-49a7-ad6f-991e94b408db
8b1348e8-e209-4d3b-8d4d-6612d0190873	1008e1af-da16-465b-9812-12a2ae80d378	4251c73f-843a-49a7-ad6f-991e94b408db	VIL-002	villa	\N	\N	2	\N	\N	100	available	t	2026-03-28 11:26:17.39636	accommodation	4251c73f-843a-49a7-ad6f-991e94b408db
32a2320c-328b-4b34-a767-4d63c3f7a25f	1008e1af-da16-465b-9812-12a2ae80d378	4251c73f-843a-49a7-ad6f-991e94b408db	VIL-003	villa	\N	\N	2	\N	\N	100	available	t	2026-03-28 11:26:17.399091	accommodation	4251c73f-843a-49a7-ad6f-991e94b408db
93b63e1d-bb2a-405f-b3c3-212bcb4c94f9	1008e1af-da16-465b-9812-12a2ae80d378	4251c73f-843a-49a7-ad6f-991e94b408db	VIL-004	villa	\N	\N	2	\N	\N	100	available	t	2026-03-28 11:26:17.401408	accommodation	4251c73f-843a-49a7-ad6f-991e94b408db
1716ea2f-b69a-4e7e-bf7a-3d7a74769ff0	1008e1af-da16-465b-9812-12a2ae80d378	4251c73f-843a-49a7-ad6f-991e94b408db	VIL-005	villa	\N	\N	2	\N	\N	100	available	t	2026-03-28 11:26:17.411938	accommodation	4251c73f-843a-49a7-ad6f-991e94b408db
2a7226bd-2650-4669-9e33-687bc2bce776	096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	STA-001	standard	\N	\N	2	\N	\N	100	available	t	2026-04-29 09:48:07.995203	accommodation	11e77135-6f73-422d-8b48-244d2137c1e6
df02ecc4-5975-48d7-8433-743c2ee7bb5d	096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	STA-002	standard	\N	\N	2	\N	\N	100	available	t	2026-04-29 09:48:07.999363	accommodation	11e77135-6f73-422d-8b48-244d2137c1e6
de94000b-b687-48dc-9807-757cb026f9ab	096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	STA-003	standard	\N	\N	2	\N	\N	100	available	t	2026-04-29 09:48:08.003512	accommodation	11e77135-6f73-422d-8b48-244d2137c1e6
df37d0ba-1034-4cab-8b73-0a2621792755	096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	STA-004	standard	\N	\N	2	\N	\N	100	available	t	2026-04-29 09:48:08.007239	accommodation	11e77135-6f73-422d-8b48-244d2137c1e6
8d88b8f5-819b-442f-93ac-fcb55cf856aa	096b4ba5-e48a-4947-95fb-ca9352a29a41	11e77135-6f73-422d-8b48-244d2137c1e6	STA-005	standard	\N	\N	2	\N	\N	100	available	t	2026-04-29 09:48:08.010746	accommodation	11e77135-6f73-422d-8b48-244d2137c1e6
6b64e0cc-55bb-45cb-b37c-c59c91a5fc57	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	101	standard	\N	1	2	\N	{wifi,tv,minibar,safe}	15000	available	t	2026-05-07 13:54:50.220103	accommodation	\N
3957c483-afd8-458d-993d-4be44048f96c	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	102	standard	\N	1	2	\N	{wifi,tv,minibar,safe}	15000	available	t	2026-05-07 13:54:50.220103	accommodation	\N
64af0fc5-330a-4679-a7e0-991c62287aa3	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	201	deluxe	\N	2	3	\N	{wifi,tv,minibar,safe}	25000	available	t	2026-05-07 13:54:50.220103	accommodation	\N
845cfe05-18b5-4df8-bf32-6577093e3086	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	202	deluxe	\N	2	3	\N	{wifi,tv,minibar,safe}	25000	occupied	t	2026-05-07 13:54:50.220103	accommodation	\N
a58bac8b-77e8-4d2f-8bab-6e5dda38d506	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	301	suite	\N	3	4	\N	{wifi,tv,minibar,safe}	45000	available	t	2026-05-07 13:54:50.220103	accommodation	\N
30374ba7-61cf-4607-a612-207935336dfe	d60048fa-971f-486c-a8db-610a5965ad97	11405dd7-d6b6-4d46-8774-bbaa16c01f71	302	presidential_suite	\N	3	4	\N	{wifi,tv,minibar,safe}	75000	maintenance	t	2026-05-07 13:54:50.220103	accommodation	\N
\.


--
-- Data for Name: usage_meters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_meters (id, owner_id, metric_type, current_value, max_allowed, last_updated, tenant_id) FROM stdin;
b3654049-1a92-4054-b0bc-e45946bd4590	11405dd7-d6b6-4d46-8774-bbaa16c01f71	properties	1	999	2026-03-06 13:38:28.737	\N
49bccff5-4b1b-4930-9a78-42dd67bfad99	11405dd7-d6b6-4d46-8774-bbaa16c01f71	units	5	998001	2026-03-06 13:38:28.744	\N
e61c8116-e1c6-45e9-90c3-74bc2977f14b	11405dd7-d6b6-4d46-8774-bbaa16c01f71	devices	0	999	2026-03-06 13:38:28.748	\N
a474796e-5d73-4a56-97ec-2a183f7680d7	11405dd7-d6b6-4d46-8774-bbaa16c01f71	users	5	999	2026-03-06 13:38:28.756	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, role, full_name, email, phone, avatar_url, created_at, hotel_id, language, phone_country_code, owner_id, property_id, tenant_id, referral_code) FROM stdin;
2ac88303-6e1b-4f38-a844-c96844af6fef	GUEST-KN9Y	$2b$12$QT1rjLlBEHRgtmApHY18H.0Mxw7ipOo8hOrOCjhDjC.5Du2ZkvQoa	guest	Test HK Guest	testhkpro@test.com	+1234567890	\N	2026-02-24 13:15:15.30929	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_2c831ac8-9c02-411c-b930-799a0999b7b8	\N
3e6b086d-382a-4ef2-b56c-ee5191701554	GUEST-DN7Z	$2b$12$S5hi8vnMMsJE6Hv9m2AC9ejqTVK.7itZEB00Wl6ZX17qT3fbxlMGi	guest	Test Payment Guest	test-payment@example.com	+994501234567	\N	2026-02-24 11:35:53.457642	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_3f0af152-9afc-4ef2-af0a-6cf8495bbfcc	\N
3b8c75dd-3133-4d74-aa05-a392231fca06	trialtest2	$2b$12$dFlwG8QCWppnVgfWI08/B.zur/2/MxOs5GXpFovbbMh4K7zv5qsHG	owner_admin	Trial Test	trialtest2@test.com	\N	\N	2026-02-19 17:02:37.432984	\N	en	\N	1abed867-520f-42c0-87cb-836763296852	\N	\N	\N
e9dd6201-3d01-4316-9baf-f6ac3cfe0a35	test11	$2b$12$nbPt8f311uLoPp65DlrNe.7huM9prankEcSDGYpOJ56VwErZXVq3K	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-19 17:38:53.390481	f79cf4d0-8944-4d83-9ced-976073ae2824	en	\N	495c33fe-a392-439a-aec7-39d639d8b45c	c43b9ca9-7855-43b7-8c41-d2863b88e47a	\N	\N
c07aba9f-6502-4844-9528-c3aec9689f88	diagtest1	$2b$12$uCQ66PP2xjJ69nFlG1v/E.bF1JAnnv3XF2CTnUfynpKODiOiL9QEm	owner_admin	Diag Test	diag@test.com	\N	\N	2026-02-20 08:08:19.905145	\N	en	\N	6bc37ae9-1cac-4cf0-920a-2c54d018cb53	\N	\N	\N
af7ba19d-06c4-4490-bc91-fda1414802ed	starter1	$2b$12$vj4IxSLMuIms8OrSiXpblOTCpeePIWt.UrkuNzKdSNSskfydm2vL6	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-20 08:56:26.039985	afdcc6cc-9212-4bd9-9bd2-403c0f824513	en	\N	ae2ddc1d-50dc-489d-b690-73465af34a13	b0803298-c2e9-44ac-b28d-4866be2e217e	\N	\N
bb12fe81-fe1d-467b-ba79-c4dd9547435b	GUEST-ZTCG	$2b$12$QjF76dBGkiHqiCZ05eXciOU5rAIL.741.oEATOpX.a9JRVluz.lcK	guest	Hassan Mammadov	fix_test_1774282552769@example.com	+994501234567	\N	2026-03-23 16:15:53.107655	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N
81e76596-4329-4026-98e9-f2f040820245	GUEST-2FKT	$2b$12$WLH/isQ6e1LQAvENHmbHb.ny.mK/R7qVfhS7RBZHHTm0ZZKXNpugi	guest	rasd	ramin.v@orange-studio.az	+994501234567	\N	2026-02-20 10:18:42.232707	7577111e-642c-4e59-a839-6686f47c5256	en	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N
69d2ec0e-d832-4477-b631-c1d03de733ce	oss_admin	$2b$12$LkY6ShpMhD26Cr/G4bUma.6J4RyI7yAquuxSv7FnaU0OnEap9VUQe	oss_super_admin	OSS Admin User	admin@orange-studio.az	\N	\N	2026-02-12 12:48:06.916685	86d04359-dc5e-4b08-86f7-d45bf449188a	en	\N	\N	\N	\N	\N
ef1abc49-94d6-43dc-8f10-94eb34bb7bc1	demo_restaurant_cashier	$2b$12$SQMwqVULZQZ7cN.8kblFUOe.IeT32uqOmkH67iDJV2DKMH2tkiB.O	restaurant_cashier	Omar Faruk	omar@grandriviera.com	+14155550110	\N	2026-04-29 14:44:49.952207	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
e7c0a417-1d09-42e0-b0c0-278801594949	demo_restaurant_cleaner	$2b$12$PGB8ymaCZMgCKqheSp2k7.1U.MzuFmXx5PEs2/0Uk4phLgsMCLS22	restaurant_cleaner	Ana Lima	ana@grandriviera.com	+14155550109	\N	2026-04-29 14:44:58.921261	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
c765f89e-a13c-41a1-8b8f-7dfac07d72d7	GUEST-YYS9	$2b$12$QC6nLB1LAgAQLRN1d0.QTevWg5pXLRxqv27y866pTz0xaXjq4IrY2	guest	E2E Checkin Guest	e2e-checkin@example.com	+994509999999	\N	2026-02-24 12:00:58.918732	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_34e01e00-8509-47db-874b-3bbc6ed52284	\N
496c7a53-8626-4252-9c54-dd65e6b99f71	Black.ice.aframe2	$2b$12$HgaaLnacIFY/V2qKvbe3QO9Dei2wObXLTKn.NH4jZ48HGcn01qq1C	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-03-04 10:02:21.619936	ff6d2516-815b-40ae-ac7b-cf7a086dbaa0	en	\N	4b40a969-f41d-4722-bf60-e60829e7bc90	719dd5ca-c66f-4947-8b7e-1b30e22f787a	\N	\N
38ed791c-6f0f-4abe-96fb-9d8afadda435	Nuhouse	$2b$12$5dgJVDsZwfxS2/UfBAo7O.f.f6z9IEDTGuu5McLbZP3B2.8jKxfgi	owner_admin	Ramin	admin@ossaipro.com	\N	\N	2026-03-28 11:25:36.701897	46ae92e5-9940-4b90-a5af-7fad98148a6a	en	\N	4251c73f-843a-49a7-ad6f-991e94b408db	1008e1af-da16-465b-9812-12a2ae80d378	\N	\N
31746b7d-8021-4c7f-935d-a22770d0b81b	Black.ice.aframe3	$2b$12$nuRULbEswvME.eY99ygGWet0B3fn1y8MKrM1hnDoOgYv5i75y7oA.	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-03-11 12:47:41.7577	92cf194e-6096-4945-94a3-a005d1b3f822	en	\N	e10e1ae2-7ac4-4814-8db4-b701c457309d	d7bb67a8-f871-42d1-a78f-1115b35f04e9	\N	\N
5a7a66ec-9f6b-4730-9bcd-a6b9ec71dba1	GUEST-GD65	$2b$12$3BKLKYhUvukwmb9xEploLO9lO7zv462fdNTSmC/HqYipYl17vriDu	guest	Ahmad Mammadov	test_1774282153383@example.com	+994501234567	\N	2026-03-23 16:09:13.743417	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N
a0ace9f0-eb15-4e96-8a72-da6d83247764	GUEST-T9L2	$2b$12$IrlVCTl28i2x7TLadD9zneZtTsSXz7FE9YTmMZKBkOUStdKqUmozW	guest	No Show Test Guest	noshow_v2_1774282575411@example.com	+994551234567	\N	2026-03-23 16:16:15.747493	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N
demo_staff_1	demo_staff	$2b$12$S5zCrLCjcH2ccef4GVYMqOzHirigi9ZEzxjYZdYStfFttuERjiiJ2	admin	Demo Staff	demo_staff@oss.hotel	\N	\N	2026-02-13 14:32:11.320322	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	899d7a50-7ac8-4c57-b16a-035da45ab8dc	\N
1a992ff9-d50f-4ec3-9721-12560d2c0e62	testadmin_lvPwUO	$2b$12$GV3iUW8.vGUIeNvjnh/rb.rfJX8jG6i8cY8xhBQd/E6hvTb8Lkp9C	owner_admin	Test Admin	testadmin@test.com	\N	\N	2026-02-14 14:41:52.316722	4b678775-1fb6-4b29-aeb6-66efd36254a6	en	\N	87772a76-ada5-4dc6-bacf-9e949d17ffc6	e9510355-d798-4f92-a102-1a59c2c2fc85	\N	\N
ff5b544d-40fe-49f4-8325-34a99146bca0	admin_demo	$2b$10$Hp51bH7Rq6iy00jHCdTXZOAyMQ09O1HH6XBLMa6IMyDP1L0bCdGfS	owner_admin	Demo Admin	admin@demo.com	\N	\N	2026-03-05 15:06:35.332946	c7ebef61-6fbc-438f-8a44-639d53fcc58d	en	\N	11e77135-6f73-422d-8b48-244d2137c1e6	096b4ba5-e48a-4947-95fb-ca9352a29a41	\N	\N
9ee2674e-a482-41e6-92fa-e29d22ab3948	demo_housekeeping	$2b$12$/qeWexldBzSc0KebeBGPF.oQuJMjrUobGWtnKu2cQ2kw9BYPzYElC	staff	Nina Torres	nina@grandriviera.com	+14155550104	\N	2026-04-29 14:04:04.867995	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
0d33e5a9-5008-4e52-a897-42c81274ced3	demo_admin	$2b$12$GzKyzdw5.ImMFlH1PyyS3eYWYIeC3sQ4tdbjxvgYElZLFAgH.H88G	admin	James Wilson	james@grandriviera.com	+14155550103	\N	2026-02-24 20:02:36.518965	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
8317f3c8-f1f9-4b9f-8570-25968af7ef28	test7	$2b$12$pHZ.PfXrny1e/NLac7Kme.mxMSY5BdeL3b/EC0fs.LzBkPKIVYNtq	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-19 16:41:23.433768	aa05c231-e9bf-4141-95fe-e570bd70953d	en	\N	afa0de93-1326-4fe4-a339-f65121ba4bcb	579129ae-3ff4-42ec-825a-61c7c5319d85	\N	\N
85d0d02e-5942-47c4-929a-62479c70a788	test9	$2b$12$6y1tldYiX75LwHbzcJCl5eOq/fxf8aP5OFPVIjZ5DufoCOSXzuMOi	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-19 17:06:00.278548	92be9bf5-6d03-4993-9478-a6d838398a46	en	\N	6dec171d-d048-47d4-a5d4-1476a7b5390a	d2959c48-95f9-4bf0-9f48-3f1f85ddbb70	\N	\N
da4e4e54-8610-4535-bbd9-de375e9f4337	test12	$2b$12$xPZKysEqWoSr1D5hpuhu8eHZo1J0qGHpSGgSdQqhVFjY1Svh0efgK	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-19 18:40:15.675149	e807c861-3c3e-41ed-b4d3-89dbe5020c2c	en	\N	a8d4b603-ad1a-4807-ad4d-d992076c5892	72122e33-d1a4-4805-bae0-57c020b13ce6	\N	\N
67909c91-a893-46f1-ba80-6d668fbe1d6d	test55	$2b$12$s2E56H/cFWd9Z3qjg2pgLuGNdQ7sSwlUZvCZNw5srxt/eGe/1nWcy	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-20 06:40:16.351681	df0a1f3a-869f-455a-913c-5595c65e61f7	en	\N	ac506214-8952-45da-97f0-0e771f8543a2	af2cc7de-c86c-485f-bc92-d0125ec094fb	\N	\N
f365edad-3a97-42f6-a549-a5ffa19348e0	demo_guest1	$2b$12$vuld41siojE2LR06g6aOnunzIM7bveNF4CX1c2SyMqo.d6OVfe1Hm	guest	Sarah Johnson	sarah@example.com	+14155550200	\N	2026-02-20 14:03:24.399815	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	az	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
8da0da3f-8e4a-4623-ac41-789ee316b827	orta1	$2b$12$oVjPv1QZewVWSQGk5pXJt.CwPs03mE7cjdqJxM1ZKIsWuvRWxqd.S	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-20 09:25:24.396224	7577111e-642c-4e59-a839-6686f47c5256	en	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	c25cfca8-9f81-44f5-b0d1-14b9ccaf6071	\N	\N
7e9c5281-144b-4a8f-8074-7f06a6fd7f50	test112	$2b$12$9L.YG6QnkmGJ2DkqJEAOw.ACZlGwzgpLfoMZ5UEC1DlJuqIAz/Oja	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-20 10:24:51.149169	24d1573c-c810-485c-a2f9-cc1d0ef3dfb2	en	\N	7402ec1b-29e9-4041-86d5-711beacb39e7	2196d0ed-08de-474f-a104-d0c0d5f8fb02	\N	\N
22954055-11d7-432d-87d8-cb004ce4ba2f	test_channex_user99	$2b$12$ztch28Z2SPdrCCHUJr9cseKt1OFogsaRisRN/wU0F7YhQK62iL2US	owner_admin	Test User	test99@hotel.com	\N	\N	2026-04-29 08:45:21.381205	4e646481-e975-43a1-8267-8424ef0bf4ab	en	\N	e1ac24e3-e692-44cb-b829-d2d3920a2324	969381ca-6c92-4fb7-9b75-6c15dce51d0f	\N	\N
e529a154-6b04-438e-83c5-a2b93b741c73	demo_maintenance	$2b$12$QoXWIFCUuhQans/LPJRYbOdF77hLES5vvCTzfOkgdZYZQQdk3BInu	staff	Dave Park	dave@grandriviera.com	+14155550106	\N	2026-04-29 14:04:12.133968	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
9b1dfd0b-805b-4c70-abf9-329093db2892	GUEST-P4S7	$2b$12$lTV.xh0XHx5LC2cy..W3ZemY/o8bolbk7Qi1BN.4GTIG8Ie8G2w.C	guest	Checkin Test Guest	checkin-test@example.com	+994501234567	\N	2026-02-24 11:54:37.440734	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_54d883e0-d226-42eb-84df-bb19082f7e3f	\N
8ac61fcc-aa08-4e0a-8c2a-0ab5ec3a1ce7	GUEST-G7ES	$2b$12$kdvkVTI4CaQT9lojxYyDve8sZLxsx5E/rL6I1c71AFXUyHtjl0dG.	guest	Case1 Guest Precheck First	case1@example.com	+994501111111	\N	2026-02-24 12:15:15.452952	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7	\N
ded08335-b52a-4093-ab0a-875dbfe20c20	demo_restaurant_manager	$2b$12$hTtwMElhLOO26rj52ODOQuKv3fFJAUrYt.DUVZqrYXa3fo72GZB5y	restaurant_manager	Sofia Reyes	sofia@grandriviera.com	+14155550107	\N	2026-04-29 14:44:57.838188	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
d5bafbda-322b-4a13-8c87-18b227575be0	testuser_1777910103	$2b$12$L0in.sJXv83muuuKjTISyeE5EynjgnPlY1jHJbXA0TImhv3w7OuYC	owner_admin	Test User	testuser_1777910103@test.com	\N	\N	2026-05-04 15:55:04.258275	86d04359-dc5e-4b08-86f7-d45bf449188a	en	\N	a25bc5e3-4dfe-49c9-899c-f15b8dd8da75	8e0bc00d-3e78-4038-976c-341cab01e423	\N	\N
ab11e664-1e1d-46cd-9edc-8a121fc2bbb8	testemail_staff_999	$2b$12$roQRHG962AA.lnIKRPpga.WAepBQNPBzxAOic4AXAtfXwLcEZ8DbO	reception	Test Email Staff	test@example.com	\N	\N	2026-05-05 09:51:16.958367	86d04359-dc5e-4b08-86f7-d45bf449188a	en	\N	\N	\N	\N	\N
07e725fb-ed49-4689-ab67-45920fe4315b	test_rest_fix_v2	$2b$12$61pB0IaHQmbcK..YkAH8fOQZeOzHr9cj3IM5McqZtGYp64b/g57Dy	owner_admin	Fix Test	fix@test.com	\N	\N	2026-05-06 17:53:34.008682	608e066b-3d9a-49dc-a3d3-27468d4af9b2	en	\N	adfa9924-8b80-4edb-9481-a67feac2580f	beaddf7c-4234-4316-b8a1-b73f2327936a	\N	\N
9bcf37cf-dffe-4f20-845e-3d953d7133d0	demo_restaurant_owner	$2b$12$GWpAcAJBbakLz9EMxx2hUuG/q22BtRMaOEBr1UpNHuR84/5vSmU9K	owner_admin	Leyla Məmmədova	leyla@ossrestodemo.com	+994501234567	\N	2026-05-06 18:27:54.041593	\N	en	\N	1aa25103-7061-4340-b939-98fed23f74e3	8f33f4e2-9509-4834-8efc-7705a5915129	\N	\N
3b4feb92-ace7-4005-82e9-0c23211dcfb4	GUEST-JLL6	$2b$12$DHAuW3xnWkBLoJz1UqNd/ugI5j.shSliRbG/CGjoK7uiDqvrrECZS	guest	Fatima Aliyeva	cancel_test_1774282352819@example.com	+994702345678	\N	2026-03-23 16:12:33.164792	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N
711c1a7a-40f5-45ab-a94d-3a63d3b24468	GUEST-RX2H	$2b$12$gbDfXZ5qtt0/Z4ozkmbiGec.3qeofgjPFcrnhk0NWmhZOQK1jIe5i	guest	John Smith	noshow_1774282353259@example.com	+12125551234	\N	2026-03-23 16:12:33.61822	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	\N	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	\N
a3a1a731-f4f6-498f-96bb-33a8f99c5d37	GUEST-MP4F	$2b$12$5hJq9F.OVmw2OJrNg2g1XO/GHY2rndlVhxoxtHorp9D1GLEMSBW8W	guest	Case2 Guest Payment First	case2@example.com	+994502222222	\N	2026-02-24 12:16:11.874518	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_3a963bc8-caba-40ab-8371-80f939ce96f7	\N
demo_recep_1	demo_reception	$2b$12$8VPXrcPM7df1SXB6765Oae57d6.QoGd1L9t1YK4mwy2M894iC4ZQa	reception	Demo Reception	demo_reception@oss.hotel	\N	\N	2026-02-13 14:32:15.292455	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	prop-test-rs	899d7a50-7ac8-4c57-b16a-035da45ab8dc	\N
9323fd64-17dc-401f-8c07-528a7dcf5fb9	demo_kitchen	$2b$12$zYuAD8OC.h0gxv9zX6ye2eLfHMEq0oqMCUR6O49EoHdHvbUDFkPXy	kitchen_staff	Carlos Mendez	carlos@grandriviera.com	+14155550105	\N	2026-04-29 14:04:11.657767	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
9e24c346-6f7c-47c6-93a2-9b17fda0c4dc	demo_waiter	$2b$12$Ic22WGbwE.UQv1FyeVeK7ee/M.Oks3seUqpMz8K2pUVAf2ff8m7U2	waiter	Luca Bianchi	luca@grandriviera.com	+14155550108	\N	2026-04-29 14:44:58.454387	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	\N	\N
62797tA7	demo_owner	$2b$10$XgiUtiqMAo/c/JbZ3EhlM.FT2KEg0II2ztT6.2nSGP8sPffcUGDZ.	owner_admin	Demo Owner	demo_owner@example.com	\N	\N	2026-02-13 12:14:38.31533	37e5945d-ac5f-42a5-9a1e-c29a6fdf668c	en	\N	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	899d7a50-7ac8-4c57-b16a-035da45ab8dc	\N
da401877-b991-474d-a193-acba0451280c	rectest_edz67t	$2b$12$D2BjA.p1.0FUcC4MZstzieX3sslc6s8IU45I3jmAl6BMtgHBI6m7K	reception	Reception Test OQi8	\N	\N	\N	2026-02-14 14:43:20.880409	4b678775-1fb6-4b29-aeb6-66efd36254a6	en	\N	87772a76-ada5-4dc6-bacf-9e949d17ffc6	e9510355-d798-4f92-a102-1a59c2c2fc85	\N	\N
cedfcf50-2d94-4699-9dd1-1a1b11c14824	test8	$2b$12$IRrymz1wbZNx8ZV6WBP.rusG9nqwCE25cErBETeOVwr0q8GW6LQ7m	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-19 16:43:36.196882	13bb4267-9856-4790-9c33-02b989ffbbc9	en	\N	02d18ce6-ec09-48c3-948e-741eeceaee86	e2475222-a91c-4167-b334-99f020731951	\N	\N
a420736f-75ef-42f7-bd37-b97a743f56e7	test66	$2b$12$XoF/2UBpxlp50Y6J/eKq8eMiDLYwoRn9Vdsrv5DQ38cdBHX.PLO8.	owner_admin	Ramin Veghari	ramin.v@orange-studio.az	\N	\N	2026-02-20 07:49:44.548193	f2085959-093d-4e61-9229-f38841a56f9e	en	\N	e333d1d7-db91-4f5a-a85b-f78b25df2b53	e0ad8e78-4f8b-45ab-9f06-33c384367f0d	\N	\N
375adbfa-a298-4a4c-acf9-94809174ac14	testpro_9jBjzA	$2b$12$gz.gDMfq0VUwAnWOb615m.YFAwzqLErL/07jmRESJgGnyUg8bCB8q	owner_admin	Test User z2ZC	admin_OM2tKm@test.com	\N	\N	2026-02-20 08:50:33.714892	20bf763c-1652-43af-ab4a-b91567b85f9a	en	\N	bc78df31-2b2a-4daa-a3d8-51a0ca8baa10	afbc29ae-ca8f-4c3c-9840-98f3ceb2f1b2	\N	\N
5928ad00-69b2-4c01-a6c5-5379c5110c4b	staff22	$2b$12$lXhN5T4vTHTDcmlUXr69quficxfrUvQzZvUgRn9uCLk66IlQm1pca	reception	staf22	ramin.v@orange-studio.az	\N	\N	2026-02-20 09:34:09.728289	7577111e-642c-4e59-a839-6686f47c5256	en	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	fb04e537-345b-4e39-9d19-959e2eded6dc	\N	\N
254ef3be-573c-45a1-ad39-96cd40546b7d	GUEST-KLQX	$2b$12$wtcvmQ5A/nONOtlyq4m4/.eYhCxfzCS9NWfV8aSnoxzHNFIc5ngBC	guest	Ramin Veghari	ramin.v@orange-studio.az	+994518880089	\N	2026-02-20 10:04:09.636478	7577111e-642c-4e59-a839-6686f47c5256	en	\N	\N	\N	f73182bf-6a38-4126-b94d-7ef754bc3db2	\N
5ad56e5d-fd29-4876-b148-8d42424847e9	GUEST-UPDB	$2b$12$hdvUlpuiFo4Y3mxrzO28S.BEyVBMBM0s5eomXW.Np.9/zczMLBMd2	guest	gsr	ramin.v@orange-studio.az	+994518880089	\N	2026-02-24 11:00:32.39738	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_2879497c-67d8-4254-a824-fcbaea376064	\N
909320fe-e9b7-4490-91b6-6aad72ef9b0b	GUEST-ZUDW	$2b$12$hh9DTxnMTuPODrQDWtjWiuhF1zOki9TvTp1NGWVPjTH.PKcEXbXCu	guest	te	ramin.v@orange-studio.az	+994518880089	\N	2026-02-24 11:01:23.106895	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_2879497c-67d8-4254-a824-fcbaea376064	\N
161bfeb3-c162-4917-b1d1-21c4a40e1446	GUEST-NFKV	$2b$12$qKdXItGe/UpIHIuYg24yLeq7iFcHkTSOoWrYLkicLapf2zfVMo05O	guest	API Test Guest	api-test@example.com	+994501234567	\N	2026-02-24 11:59:54.290637	4941633e-88da-4920-92c5-6f29de45f79a	en	\N	\N	\N	demo_session_695830c5-05bd-4882-8eb6-cb868bdff80c	\N
\.


--
-- Data for Name: waiter_calls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waiter_calls (id, tenant_id, property_id, booking_id, table_number, room_number, status, called_at, acknowledged_at, acknowledged_by) FROM stdin;
0d4211c8-0ed9-466b-8c6b-d8330f17dafd	11405dd7-d6b6-4d46-8774-bbaa16c01f71	d60048fa-971f-486c-a8db-610a5965ad97	07d7f792-d6a7-46b0-a46d-9efae004c3ea	\N	\N	acknowledged	2026-04-28 15:18:22.357358	2026-05-07 13:55:04.104	9e24c346-6f7c-47c6-93a2-9b17fda0c4dc
\.


--
-- Data for Name: white_label_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.white_label_settings (id, owner_id, logo_url, favicon_url, primary_color, secondary_color, accent_color, custom_domain, company_name, hide_branding, custom_css, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 22, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (name, id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (name, id);


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21
    ADD CONSTRAINT j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_pkey PRIMARY KEY (name, id);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3
    ADD CONSTRAINT j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey PRIMARY KEY (name, id);


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7
    ADD CONSTRAINT j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_pkey PRIMARY KEY (name, id);


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94
    ADD CONSTRAINT j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_pkey PRIMARY KEY (name, id);


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b
    ADD CONSTRAINT j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_pkey PRIMARY KEY (name, id);


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571
    ADD CONSTRAINT j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_pkey PRIMARY KEY (name, id);


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989
    ADD CONSTRAINT jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_pkey PRIMARY KEY (name, id);


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260
    ADD CONSTRAINT jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_pkey PRIMARY KEY (name, id);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (name);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (name);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (event, name);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (version);


--
-- Name: analytics_snapshots analytics_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_snapshots
    ADD CONSTRAINT analytics_snapshots_pkey PRIMARY KEY (id);


--
-- Name: api_usage_logs api_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_usage_logs
    ADD CONSTRAINT api_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: billing_info billing_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_info
    ADD CONSTRAINT billing_info_pkey PRIMARY KEY (id);


--
-- Name: billing_logs billing_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_logs
    ADD CONSTRAINT billing_logs_pkey PRIMARY KEY (id);


--
-- Name: board_reports board_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_reports
    ADD CONSTRAINT board_reports_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: cancellation_policies cancellation_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cancellation_policies
    ADD CONSTRAINT cancellation_policies_pkey PRIMARY KEY (id);


--
-- Name: cash_accounts cash_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: contract_acceptances contract_acceptances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_acceptances
    ADD CONSTRAINT contract_acceptances_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: cost_centers cost_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_pkey PRIMARY KEY (id);


--
-- Name: credential_logs credential_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credential_logs
    ADD CONSTRAINT credential_logs_pkey PRIMARY KEY (id);


--
-- Name: daily_financial_summaries daily_financial_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_financial_summaries
    ADD CONSTRAINT daily_financial_summaries_pkey PRIMARY KEY (id);


--
-- Name: deleted_trial_accounts deleted_trial_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deleted_trial_accounts
    ADD CONSTRAINT deleted_trial_accounts_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: device_telemetry device_telemetry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_telemetry
    ADD CONSTRAINT device_telemetry_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: door_action_logs door_action_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.door_action_logs
    ADD CONSTRAINT door_action_logs_pkey PRIMARY KEY (id);


--
-- Name: escalation_replies escalation_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.escalation_replies
    ADD CONSTRAINT escalation_replies_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: external_bookings external_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_bookings
    ADD CONSTRAINT external_bookings_pkey PRIMARY KEY (id);


--
-- Name: feature_flag_overrides feature_flag_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flag_overrides
    ADD CONSTRAINT feature_flag_overrides_pkey PRIMARY KEY (id);


--
-- Name: financial_audit_logs financial_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_audit_logs
    ADD CONSTRAINT financial_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: folio_adjustments folio_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folio_adjustments
    ADD CONSTRAINT folio_adjustments_pkey PRIMARY KEY (id);


--
-- Name: folio_charges folio_charges_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folio_charges
    ADD CONSTRAINT folio_charges_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: folio_charges folio_charges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folio_charges
    ADD CONSTRAINT folio_charges_pkey PRIMARY KEY (id);


--
-- Name: folio_payments folio_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folio_payments
    ADD CONSTRAINT folio_payments_pkey PRIMARY KEY (id);


--
-- Name: guest_folios guest_folios_booking_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guest_folios
    ADD CONSTRAINT guest_folios_booking_id_key UNIQUE (booking_id);


--
-- Name: guest_folios guest_folios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guest_folios
    ADD CONSTRAINT guest_folios_pkey PRIMARY KEY (id);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (id);


--
-- Name: housekeeping_tasks housekeeping_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.housekeeping_tasks
    ADD CONSTRAINT housekeeping_tasks_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entry_lines journal_entry_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: night_audits night_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.night_audits
    ADD CONSTRAINT night_audits_pkey PRIMARY KEY (id);


--
-- Name: no_show_records no_show_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.no_show_records
    ADD CONSTRAINT no_show_records_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: onboarding_progress onboarding_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_progress
    ADD CONSTRAINT onboarding_progress_pkey PRIMARY KEY (id);


--
-- Name: ota_conflicts ota_conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ota_conflicts
    ADD CONSTRAINT ota_conflicts_pkey PRIMARY KEY (id);


--
-- Name: ota_integrations ota_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ota_integrations
    ADD CONSTRAINT ota_integrations_pkey PRIMARY KEY (id);


--
-- Name: ota_sync_logs ota_sync_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ota_sync_logs
    ADD CONSTRAINT ota_sync_logs_pkey PRIMARY KEY (id);


--
-- Name: owners owners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owners
    ADD CONSTRAINT owners_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_unique UNIQUE (token);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_orders payment_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders
    ADD CONSTRAINT payment_orders_pkey PRIMARY KEY (id);


--
-- Name: payroll_configs payroll_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_configs
    ADD CONSTRAINT payroll_configs_pkey PRIMARY KEY (id);


--
-- Name: payroll_entries payroll_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_entries
    ADD CONSTRAINT payroll_entries_pkey PRIMARY KEY (id);


--
-- Name: pos_menu_categories pos_menu_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_menu_categories
    ADD CONSTRAINT pos_menu_categories_pkey PRIMARY KEY (id);


--
-- Name: pos_menu_items pos_menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_menu_items
    ADD CONSTRAINT pos_menu_items_pkey PRIMARY KEY (id);


--
-- Name: pos_order_items pos_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_order_items
    ADD CONSTRAINT pos_order_items_pkey PRIMARY KEY (id);


--
-- Name: pos_orders pos_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_orders
    ADD CONSTRAINT pos_orders_pkey PRIMARY KEY (id);


--
-- Name: pricing_rules pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rules
    ADD CONSTRAINT pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: quote_notes quote_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_notes
    ADD CONSTRAINT quote_notes_pkey PRIMARY KEY (id);


--
-- Name: quote_requests quote_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_requests
    ADD CONSTRAINT quote_requests_pkey PRIMARY KEY (id);


--
-- Name: rate_plans rate_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_plans
    ADD CONSTRAINT rate_plans_pkey PRIMARY KEY (id);


--
-- Name: recurring_expenses recurring_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_expenses
    ADD CONSTRAINT recurring_expenses_pkey PRIMARY KEY (id);


--
-- Name: referral_commissions referral_commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_commissions
    ADD CONSTRAINT referral_commissions_pkey PRIMARY KEY (id);


--
-- Name: refund_requests refund_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_requests
    ADD CONSTRAINT refund_requests_pkey PRIMARY KEY (id);


--
-- Name: restaurant_cleaning_tasks restaurant_cleaning_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_cleaning_tasks
    ADD CONSTRAINT restaurant_cleaning_tasks_pkey PRIMARY KEY (id);


--
-- Name: restaurant_guest_messages restaurant_guest_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_guest_messages
    ADD CONSTRAINT restaurant_guest_messages_pkey PRIMARY KEY (id);


--
-- Name: restaurant_staff_profiles restaurant_staff_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_staff_profiles
    ADD CONSTRAINT restaurant_staff_profiles_pkey PRIMARY KEY (id);


--
-- Name: restaurant_tables restaurant_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_tables
    ADD CONSTRAINT restaurant_tables_pkey PRIMARY KEY (id);


--
-- Name: revenues revenues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revenues
    ADD CONSTRAINT revenues_pkey PRIMARY KEY (id);


--
-- Name: room_nights room_nights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_nights
    ADD CONSTRAINT room_nights_pkey PRIMARY KEY (id);


--
-- Name: room_preparation_orders room_preparation_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_preparation_orders
    ADD CONSTRAINT room_preparation_orders_pkey PRIMARY KEY (id);


--
-- Name: room_settings room_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_settings
    ADD CONSTRAINT room_settings_pkey PRIMARY KEY (id);


--
-- Name: service_requests service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: staff_feedback staff_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_feedback
    ADD CONSTRAINT staff_feedback_pkey PRIMARY KEY (id);


--
-- Name: staff_invitations staff_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_invitations
    ADD CONSTRAINT staff_invitations_pkey PRIMARY KEY (id);


--
-- Name: staff_message_status staff_message_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_message_status
    ADD CONSTRAINT staff_message_status_pkey PRIMARY KEY (id);


--
-- Name: staff_messages staff_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_messages
    ADD CONSTRAINT staff_messages_pkey PRIMARY KEY (id);


--
-- Name: staff_performance_scores staff_performance_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_performance_scores
    ADD CONSTRAINT staff_performance_scores_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tax_configurations tax_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_configurations
    ADD CONSTRAINT tax_configurations_pkey PRIMARY KEY (id);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id);


--
-- Name: usage_meters usage_meters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_meters
    ADD CONSTRAINT usage_meters_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: waiter_calls waiter_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waiter_calls
    ADD CONSTRAINT waiter_calls_pkey PRIMARY KEY (id);


--
-- Name: white_label_settings white_label_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.white_label_settings
    ADD CONSTRAINT white_label_settings_pkey PRIMARY KEY (id);


--
-- Name: archive_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX archive_i1 ON pgboss.archive USING btree (archived_on);


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i1 ON pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i2 ON pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i3 ON pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i4 ON pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_i5 ON pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i1 ON pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i2 ON pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i3 ON pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i4 ON pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_i5 ON pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i1 ON pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i2 ON pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i3 ON pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i4 ON pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_i5 ON pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i1 ON pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i2 ON pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i3 ON pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i4 ON pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_i5 ON pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i1 ON pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i2 ON pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i3 ON pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i4 ON pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_i5 ON pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i1 ON pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i2 ON pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i3 ON pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i4 ON pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_i5 ON pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i1 ON pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i2 ON pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i3 ON pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i4 ON pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_i5 ON pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i1; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i1 ON pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'created'::pgboss.job_state) AND (policy = 'short'::text));


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i2; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i2 ON pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 USING btree (name, COALESCE(singleton_key, ''::text)) WHERE ((state = 'active'::pgboss.job_state) AND (policy = 'singleton'::text));


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i3; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i3 ON pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 USING btree (name, state, COALESCE(singleton_key, ''::text)) WHERE ((state <= 'active'::pgboss.job_state) AND (policy = 'stately'::text));


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i4; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE UNIQUE INDEX jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i4 ON pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 USING btree (name, singleton_on, COALESCE(singleton_key, ''::text)) WHERE ((state <> 'cancelled'::pgboss.job_state) AND (singleton_on IS NOT NULL));


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i5; Type: INDEX; Schema: pgboss; Owner: -
--

CREATE INDEX jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_i5 ON pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 USING btree (name, start_after) INCLUDE (priority, created_on, id) WHERE (state < 'active'::pgboss.job_state);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: idx_analytics_snapshots_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_analytics_snapshots_owner_id ON public.analytics_snapshots USING btree (owner_id);


--
-- Name: idx_analytics_snapshots_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_analytics_snapshots_property_id ON public.analytics_snapshots USING btree (property_id);


--
-- Name: idx_analytics_snapshots_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_analytics_snapshots_tenant_id ON public.analytics_snapshots USING btree (tenant_id);


--
-- Name: idx_api_usage_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_usage_created_at ON public.api_usage_logs USING btree (created_at);


--
-- Name: idx_api_usage_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_usage_tenant ON public.api_usage_logs USING btree (tenant_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_audit_logs_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_owner_id ON public.audit_logs USING btree (owner_id);


--
-- Name: idx_audit_logs_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_property_id ON public.audit_logs USING btree (property_id);


--
-- Name: idx_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant_id ON public.audit_logs USING btree (tenant_id);


--
-- Name: idx_billing_info_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_info_owner_id ON public.billing_info USING btree (owner_id);


--
-- Name: idx_billing_info_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_info_tenant_id ON public.billing_info USING btree (tenant_id);


--
-- Name: idx_billing_logs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_logs_created ON public.billing_logs USING btree (created_at DESC);


--
-- Name: idx_billing_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_logs_created_at ON public.billing_logs USING btree (created_at);


--
-- Name: idx_billing_logs_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_logs_hotel_id ON public.billing_logs USING btree (hotel_id);


--
-- Name: idx_billing_logs_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_logs_owner_id ON public.billing_logs USING btree (owner_id);


--
-- Name: idx_billing_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_logs_tenant_id ON public.billing_logs USING btree (tenant_id);


--
-- Name: idx_bookings_guest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_guest_id ON public.bookings USING btree (guest_id);


--
-- Name: idx_bookings_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_owner_id ON public.bookings USING btree (owner_id);


--
-- Name: idx_bookings_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_property_id ON public.bookings USING btree (property_id);


--
-- Name: idx_bookings_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bookings_tenant_id ON public.bookings USING btree (tenant_id);


--
-- Name: idx_cancel_policy_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cancel_policy_hotel_id ON public.cancellation_policies USING btree (hotel_id);


--
-- Name: idx_cancel_policy_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cancel_policy_tenant_id ON public.cancellation_policies USING btree (tenant_id);


--
-- Name: idx_cancellation_policies_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cancellation_policies_hotel_id ON public.cancellation_policies USING btree (hotel_id);


--
-- Name: idx_cancellation_policies_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cancellation_policies_tenant_id ON public.cancellation_policies USING btree (tenant_id);


--
-- Name: idx_cash_accounts_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_accounts_hotel_id ON public.cash_accounts USING btree (hotel_id);


--
-- Name: idx_cash_accounts_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_accounts_owner_id ON public.cash_accounts USING btree (owner_id);


--
-- Name: idx_cash_accounts_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_accounts_property_id ON public.cash_accounts USING btree (property_id);


--
-- Name: idx_cash_accounts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_accounts_tenant_id ON public.cash_accounts USING btree (tenant_id);


--
-- Name: idx_chat_messages_guest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_guest_id ON public.chat_messages USING btree (guest_id);


--
-- Name: idx_chat_messages_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_hotel_id ON public.chat_messages USING btree (hotel_id);


--
-- Name: idx_chat_messages_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_property_id ON public.chat_messages USING btree (property_id);


--
-- Name: idx_chat_messages_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_tenant_id ON public.chat_messages USING btree (tenant_id);


--
-- Name: idx_coa_account_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_coa_account_code ON public.chart_of_accounts USING btree (account_code);


--
-- Name: idx_coa_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_coa_hotel_id ON public.chart_of_accounts USING btree (hotel_id);


--
-- Name: idx_coa_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_coa_tenant_id ON public.chart_of_accounts USING btree (tenant_id);


--
-- Name: idx_contract_acceptances_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_acceptances_owner_id ON public.contract_acceptances USING btree (owner_id);


--
-- Name: idx_contract_acceptances_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_acceptances_tenant_id ON public.contract_acceptances USING btree (tenant_id);


--
-- Name: idx_cost_centers_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cost_centers_department_id ON public.cost_centers USING btree (department_id);


--
-- Name: idx_cost_centers_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cost_centers_hotel_id ON public.cost_centers USING btree (hotel_id);


--
-- Name: idx_credential_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credential_logs_tenant_id ON public.credential_logs USING btree (tenant_id);


--
-- Name: idx_daily_summary_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_summary_date ON public.daily_financial_summaries USING btree (summary_date);


--
-- Name: idx_daily_summary_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_summary_hotel_id ON public.daily_financial_summaries USING btree (hotel_id);


--
-- Name: idx_daily_summary_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_summary_tenant_id ON public.daily_financial_summaries USING btree (tenant_id);


--
-- Name: idx_deleted_trial_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deleted_trial_email ON public.deleted_trial_accounts USING btree (email);


--
-- Name: idx_departments_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_hotel_id ON public.departments USING btree (hotel_id);


--
-- Name: idx_departments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_departments_tenant_id ON public.departments USING btree (tenant_id);


--
-- Name: idx_device_telemetry_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_telemetry_tenant_id ON public.device_telemetry USING btree (tenant_id);


--
-- Name: idx_devices_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_owner_id ON public.devices USING btree (owner_id);


--
-- Name: idx_devices_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_property_id ON public.devices USING btree (property_id);


--
-- Name: idx_devices_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_tenant_id ON public.devices USING btree (tenant_id);


--
-- Name: idx_door_action_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_door_action_logs_tenant_id ON public.door_action_logs USING btree (tenant_id);


--
-- Name: idx_escalation_replies_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_escalation_replies_tenant_id ON public.escalation_replies USING btree (tenant_id);


--
-- Name: idx_expenses_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_expenses_hotel_id ON public.expenses USING btree (hotel_id);


--
-- Name: idx_expenses_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_expenses_owner_id ON public.expenses USING btree (owner_id);


--
-- Name: idx_expenses_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_expenses_property_id ON public.expenses USING btree (property_id);


--
-- Name: idx_expenses_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_expenses_tenant_id ON public.expenses USING btree (tenant_id);


--
-- Name: idx_external_bookings_external_id_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_external_bookings_external_id_hotel_id ON public.external_bookings USING btree (external_id, hotel_id);


--
-- Name: idx_external_bookings_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_external_bookings_hotel_id ON public.external_bookings USING btree (hotel_id);


--
-- Name: idx_external_bookings_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_external_bookings_tenant_id ON public.external_bookings USING btree (tenant_id);


--
-- Name: idx_feature_flag_overrides_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_flag_overrides_owner_id ON public.feature_flag_overrides USING btree (owner_id);


--
-- Name: idx_feature_flag_overrides_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_flag_overrides_tenant_id ON public.feature_flag_overrides USING btree (tenant_id);


--
-- Name: idx_financial_audit_logs_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_audit_logs_hotel_id ON public.financial_audit_logs USING btree (hotel_id);


--
-- Name: idx_financial_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_audit_logs_tenant_id ON public.financial_audit_logs USING btree (tenant_id);


--
-- Name: idx_financial_transactions_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_hotel_id ON public.financial_transactions USING btree (hotel_id);


--
-- Name: idx_financial_transactions_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_owner_id ON public.financial_transactions USING btree (owner_id);


--
-- Name: idx_financial_transactions_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_property_id ON public.financial_transactions USING btree (property_id);


--
-- Name: idx_financial_transactions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_tenant_id ON public.financial_transactions USING btree (tenant_id);


--
-- Name: idx_folio_adjustments_approval; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_adjustments_approval ON public.folio_adjustments USING btree (approval_status);


--
-- Name: idx_folio_adjustments_folio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_adjustments_folio_id ON public.folio_adjustments USING btree (folio_id);


--
-- Name: idx_folio_adjustments_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_adjustments_hotel_id ON public.folio_adjustments USING btree (hotel_id);


--
-- Name: idx_folio_adjustments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_adjustments_tenant_id ON public.folio_adjustments USING btree (tenant_id);


--
-- Name: idx_folio_charges_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_charges_booking_id ON public.folio_charges USING btree (booking_id);


--
-- Name: idx_folio_charges_folio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_charges_folio_id ON public.folio_charges USING btree (folio_id);


--
-- Name: idx_folio_charges_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_charges_hotel_id ON public.folio_charges USING btree (hotel_id);


--
-- Name: idx_folio_charges_service_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_charges_service_date ON public.folio_charges USING btree (service_date);


--
-- Name: idx_folio_charges_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_charges_status ON public.folio_charges USING btree (status);


--
-- Name: idx_folio_charges_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_charges_tenant_id ON public.folio_charges USING btree (tenant_id);


--
-- Name: idx_folio_payments_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_payments_booking_id ON public.folio_payments USING btree (booking_id);


--
-- Name: idx_folio_payments_folio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_payments_folio_id ON public.folio_payments USING btree (folio_id);


--
-- Name: idx_folio_payments_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_payments_hotel_id ON public.folio_payments USING btree (hotel_id);


--
-- Name: idx_folio_payments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folio_payments_tenant_id ON public.folio_payments USING btree (tenant_id);


--
-- Name: idx_folios_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folios_booking_id ON public.guest_folios USING btree (booking_id);


--
-- Name: idx_folios_guest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folios_guest_id ON public.guest_folios USING btree (guest_id);


--
-- Name: idx_folios_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folios_hotel_id ON public.guest_folios USING btree (hotel_id);


--
-- Name: idx_folios_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folios_status ON public.guest_folios USING btree (status);


--
-- Name: idx_folios_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_folios_tenant_id ON public.guest_folios USING btree (tenant_id);


--
-- Name: idx_hotels_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hotels_owner_id ON public.hotels USING btree (owner_id);


--
-- Name: idx_hotels_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hotels_property_id ON public.hotels USING btree (property_id);


--
-- Name: idx_hotels_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hotels_tenant_id ON public.hotels USING btree (tenant_id);


--
-- Name: idx_housekeeping_tasks_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_housekeeping_tasks_assigned_to ON public.housekeeping_tasks USING btree (assigned_to);


--
-- Name: idx_housekeeping_tasks_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_housekeeping_tasks_booking_id ON public.housekeeping_tasks USING btree (booking_id);


--
-- Name: idx_housekeeping_tasks_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_housekeeping_tasks_property_id ON public.housekeeping_tasks USING btree (property_id);


--
-- Name: idx_housekeeping_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_housekeeping_tasks_status ON public.housekeeping_tasks USING btree (status);


--
-- Name: idx_housekeeping_tasks_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_housekeeping_tasks_tenant_id ON public.housekeeping_tasks USING btree (tenant_id);


--
-- Name: idx_housekeeping_tasks_unit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_housekeeping_tasks_unit_id ON public.housekeeping_tasks USING btree (unit_id);


--
-- Name: idx_invoices_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_owner_id ON public.invoices USING btree (owner_id);


--
-- Name: idx_invoices_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_tenant_id ON public.invoices USING btree (tenant_id);


--
-- Name: idx_journal_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_date ON public.journal_entries USING btree (entry_date);


--
-- Name: idx_journal_entries_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_hotel_id ON public.journal_entries USING btree (hotel_id);


--
-- Name: idx_journal_entries_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_entries_tenant_id ON public.journal_entries USING btree (tenant_id);


--
-- Name: idx_journal_lines_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_lines_account_id ON public.journal_entry_lines USING btree (account_id);


--
-- Name: idx_journal_lines_entry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_lines_entry_id ON public.journal_entry_lines USING btree (journal_entry_id);


--
-- Name: idx_journal_lines_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_journal_lines_hotel_id ON public.journal_entry_lines USING btree (hotel_id);


--
-- Name: idx_leads_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_created_at ON public.leads USING btree (created_at);


--
-- Name: idx_leads_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leads_email ON public.leads USING btree (email);


--
-- Name: idx_night_audits_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_night_audits_date ON public.night_audits USING btree (audit_date);


--
-- Name: idx_night_audits_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_night_audits_hotel_id ON public.night_audits USING btree (hotel_id);


--
-- Name: idx_night_audits_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_night_audits_tenant_id ON public.night_audits USING btree (tenant_id);


--
-- Name: idx_no_show_records_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_no_show_records_hotel_id ON public.no_show_records USING btree (hotel_id);


--
-- Name: idx_no_show_records_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_no_show_records_tenant_id ON public.no_show_records USING btree (tenant_id);


--
-- Name: idx_notifications_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_read ON public.notifications USING btree (user_id, read);


--
-- Name: idx_notifications_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_tenant_id ON public.notifications USING btree (tenant_id);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_onboarding_progress_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_progress_owner_id ON public.onboarding_progress USING btree (owner_id);


--
-- Name: idx_onboarding_progress_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_onboarding_progress_tenant_id ON public.onboarding_progress USING btree (tenant_id);


--
-- Name: idx_ota_conflicts_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_conflicts_property_id ON public.ota_conflicts USING btree (property_id);


--
-- Name: idx_ota_conflicts_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_conflicts_tenant_id ON public.ota_conflicts USING btree (tenant_id);


--
-- Name: idx_ota_integrations_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_integrations_property_id ON public.ota_integrations USING btree (property_id);


--
-- Name: idx_ota_integrations_property_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ota_integrations_property_provider ON public.ota_integrations USING btree (property_id, provider);


--
-- Name: idx_ota_integrations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_integrations_tenant_id ON public.ota_integrations USING btree (tenant_id);


--
-- Name: idx_ota_sync_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_sync_logs_created_at ON public.ota_sync_logs USING btree (created_at);


--
-- Name: idx_ota_sync_logs_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_sync_logs_property_id ON public.ota_sync_logs USING btree (property_id);


--
-- Name: idx_ota_sync_logs_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_sync_logs_provider ON public.ota_sync_logs USING btree (provider);


--
-- Name: idx_ota_sync_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ota_sync_logs_tenant_id ON public.ota_sync_logs USING btree (tenant_id);


--
-- Name: idx_payment_orders_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_orders_owner_id ON public.payment_orders USING btree (owner_id);


--
-- Name: idx_payment_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_orders_status ON public.payment_orders USING btree (status);


--
-- Name: idx_payment_orders_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_orders_tenant_id ON public.payment_orders USING btree (tenant_id);


--
-- Name: idx_payroll_configs_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_configs_hotel_id ON public.payroll_configs USING btree (hotel_id);


--
-- Name: idx_payroll_configs_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_configs_owner_id ON public.payroll_configs USING btree (owner_id);


--
-- Name: idx_payroll_configs_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_configs_property_id ON public.payroll_configs USING btree (property_id);


--
-- Name: idx_payroll_configs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_configs_tenant_id ON public.payroll_configs USING btree (tenant_id);


--
-- Name: idx_payroll_entries_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_entries_hotel_id ON public.payroll_entries USING btree (hotel_id);


--
-- Name: idx_payroll_entries_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_entries_owner_id ON public.payroll_entries USING btree (owner_id);


--
-- Name: idx_payroll_entries_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_entries_property_id ON public.payroll_entries USING btree (property_id);


--
-- Name: idx_payroll_entries_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payroll_entries_tenant_id ON public.payroll_entries USING btree (tenant_id);


--
-- Name: idx_pos_menu_cat_property; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_menu_cat_property ON public.pos_menu_categories USING btree (property_id);


--
-- Name: idx_pos_menu_cat_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_menu_cat_tenant ON public.pos_menu_categories USING btree (tenant_id);


--
-- Name: idx_pos_menu_categories_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_menu_categories_property_id ON public.pos_menu_categories USING btree (property_id);


--
-- Name: idx_pos_menu_items_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_menu_items_category ON public.pos_menu_items USING btree (category_id);


--
-- Name: idx_pos_menu_items_property; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_menu_items_property ON public.pos_menu_items USING btree (property_id);


--
-- Name: idx_pos_menu_items_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_menu_items_property_id ON public.pos_menu_items USING btree (property_id);


--
-- Name: idx_pos_order_items_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_order_items_order ON public.pos_order_items USING btree (order_id);


--
-- Name: idx_pos_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_order_items_order_id ON public.pos_order_items USING btree (order_id);


--
-- Name: idx_pos_orders_kitchen_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_orders_kitchen_status ON public.pos_orders USING btree (kitchen_status);


--
-- Name: idx_pos_orders_property; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_orders_property ON public.pos_orders USING btree (property_id);


--
-- Name: idx_pos_orders_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_orders_property_id ON public.pos_orders USING btree (property_id);


--
-- Name: idx_pos_orders_settlement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_orders_settlement ON public.pos_orders USING btree (settlement_status);


--
-- Name: idx_pos_orders_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_orders_tenant ON public.pos_orders USING btree (tenant_id);


--
-- Name: idx_pos_orders_waiter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pos_orders_waiter ON public.pos_orders USING btree (waiter_id);


--
-- Name: idx_pricing_rules_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rules_property_id ON public.pricing_rules USING btree (property_id);


--
-- Name: idx_pricing_rules_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pricing_rules_tenant_id ON public.pricing_rules USING btree (tenant_id);


--
-- Name: idx_properties_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_owner_id ON public.properties USING btree (owner_id);


--
-- Name: idx_properties_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_tenant_id ON public.properties USING btree (tenant_id);


--
-- Name: idx_rate_plans_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_plans_property_id ON public.rate_plans USING btree (property_id);


--
-- Name: idx_rate_plans_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_plans_tenant_id ON public.rate_plans USING btree (tenant_id);


--
-- Name: idx_recurring_expenses_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recurring_expenses_hotel_id ON public.recurring_expenses USING btree (hotel_id);


--
-- Name: idx_recurring_expenses_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recurring_expenses_owner_id ON public.recurring_expenses USING btree (owner_id);


--
-- Name: idx_recurring_expenses_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recurring_expenses_property_id ON public.recurring_expenses USING btree (property_id);


--
-- Name: idx_recurring_expenses_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recurring_expenses_tenant_id ON public.recurring_expenses USING btree (tenant_id);


--
-- Name: idx_referral_commissions_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_referral_commissions_owner ON public.referral_commissions USING btree (owner_id);


--
-- Name: idx_referral_commissions_staff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_referral_commissions_staff ON public.referral_commissions USING btree (staff_user_id);


--
-- Name: idx_referral_commissions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_referral_commissions_status ON public.referral_commissions USING btree (status);


--
-- Name: idx_refund_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_invoice ON public.refund_requests USING btree (invoice_id);


--
-- Name: idx_refund_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_owner ON public.refund_requests USING btree (owner_id);


--
-- Name: idx_refund_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refund_status ON public.refund_requests USING btree (status);


--
-- Name: idx_restaurant_cleaning_tasks_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_cleaning_tasks_assigned ON public.restaurant_cleaning_tasks USING btree (assigned_to_id);


--
-- Name: idx_restaurant_cleaning_tasks_property; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_cleaning_tasks_property ON public.restaurant_cleaning_tasks USING btree (property_id);


--
-- Name: idx_restaurant_cleaning_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_cleaning_tasks_status ON public.restaurant_cleaning_tasks USING btree (status);


--
-- Name: idx_restaurant_cleaning_tasks_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_cleaning_tasks_tenant ON public.restaurant_cleaning_tasks USING btree (tenant_id);


--
-- Name: idx_restaurant_guest_messages_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_guest_messages_property_id ON public.restaurant_guest_messages USING btree (property_id);


--
-- Name: idx_restaurant_staff_profiles_property; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_staff_profiles_property ON public.restaurant_staff_profiles USING btree (property_id);


--
-- Name: idx_restaurant_staff_profiles_user_property; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_restaurant_staff_profiles_user_property ON public.restaurant_staff_profiles USING btree (user_id, property_id);


--
-- Name: idx_restaurant_tables_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_restaurant_tables_property_id ON public.restaurant_tables USING btree (property_id);


--
-- Name: idx_revenues_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_revenues_hotel_id ON public.revenues USING btree (hotel_id);


--
-- Name: idx_revenues_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_revenues_owner_id ON public.revenues USING btree (owner_id);


--
-- Name: idx_revenues_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_revenues_property_id ON public.revenues USING btree (property_id);


--
-- Name: idx_revenues_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_revenues_tenant_id ON public.revenues USING btree (tenant_id);


--
-- Name: idx_room_nights_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_nights_booking_id ON public.room_nights USING btree (booking_id);


--
-- Name: idx_room_nights_property_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_nights_property_date ON public.room_nights USING btree (property_id, date);


--
-- Name: idx_room_nights_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_nights_tenant_id ON public.room_nights USING btree (tenant_id);


--
-- Name: idx_room_nights_unit_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_room_nights_unit_date ON public.room_nights USING btree (unit_id, date);


--
-- Name: idx_room_preparation_orders_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_preparation_orders_hotel_id ON public.room_preparation_orders USING btree (hotel_id);


--
-- Name: idx_room_preparation_orders_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_preparation_orders_owner_id ON public.room_preparation_orders USING btree (owner_id);


--
-- Name: idx_room_preparation_orders_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_preparation_orders_property_id ON public.room_preparation_orders USING btree (property_id);


--
-- Name: idx_room_preparation_orders_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_preparation_orders_tenant_id ON public.room_preparation_orders USING btree (tenant_id);


--
-- Name: idx_room_settings_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_settings_tenant_id ON public.room_settings USING btree (tenant_id);


--
-- Name: idx_service_requests_booking_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_requests_booking_id ON public.service_requests USING btree (booking_id);


--
-- Name: idx_service_requests_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_requests_owner_id ON public.service_requests USING btree (owner_id);


--
-- Name: idx_service_requests_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_requests_property_id ON public.service_requests USING btree (property_id);


--
-- Name: idx_service_requests_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_requests_tenant_id ON public.service_requests USING btree (tenant_id);


--
-- Name: idx_staff_feedback_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_feedback_hotel_id ON public.staff_feedback USING btree (hotel_id);


--
-- Name: idx_staff_feedback_staff_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_feedback_staff_id ON public.staff_feedback USING btree (staff_id);


--
-- Name: idx_staff_invitations_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_invitations_owner_id ON public.staff_invitations USING btree (owner_id);


--
-- Name: idx_staff_invitations_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_invitations_property_id ON public.staff_invitations USING btree (property_id);


--
-- Name: idx_staff_invitations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_invitations_tenant_id ON public.staff_invitations USING btree (tenant_id);


--
-- Name: idx_staff_message_status_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_message_status_message_id ON public.staff_message_status USING btree (message_id);


--
-- Name: idx_staff_message_status_staff_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_message_status_staff_id ON public.staff_message_status USING btree (staff_id);


--
-- Name: idx_staff_messages_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_messages_hotel_id ON public.staff_messages USING btree (hotel_id);


--
-- Name: idx_staff_messages_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_messages_tenant_id ON public.staff_messages USING btree (tenant_id);


--
-- Name: idx_staff_performance_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_performance_hotel_id ON public.staff_performance_scores USING btree (hotel_id);


--
-- Name: idx_staff_performance_staff_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_staff_performance_staff_id ON public.staff_performance_scores USING btree (staff_id);


--
-- Name: idx_subscriptions_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_owner_id ON public.subscriptions USING btree (owner_id);


--
-- Name: idx_subscriptions_period_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_period_end ON public.subscriptions USING btree (current_period_end);


--
-- Name: idx_subscriptions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_status ON public.subscriptions USING btree (status);


--
-- Name: idx_subscriptions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_tenant_id ON public.subscriptions USING btree (tenant_id);


--
-- Name: idx_tax_config_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tax_config_hotel_id ON public.tax_configurations USING btree (hotel_id);


--
-- Name: idx_tax_config_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tax_config_tenant_id ON public.tax_configurations USING btree (tenant_id);


--
-- Name: idx_units_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_owner_id ON public.units USING btree (owner_id);


--
-- Name: idx_units_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_property_id ON public.units USING btree (property_id);


--
-- Name: idx_units_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_units_tenant_id ON public.units USING btree (tenant_id);


--
-- Name: idx_usage_meters_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_meters_owner_id ON public.usage_meters USING btree (owner_id);


--
-- Name: idx_usage_meters_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usage_meters_tenant_id ON public.usage_meters USING btree (tenant_id);


--
-- Name: idx_users_hotel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_hotel_id ON public.users USING btree (hotel_id);


--
-- Name: idx_users_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_owner_id ON public.users USING btree (owner_id);


--
-- Name: idx_users_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_property_id ON public.users USING btree (property_id);


--
-- Name: idx_users_referral_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_referral_code ON public.users USING btree (referral_code) WHERE (referral_code IS NOT NULL);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: idx_waiter_calls_property; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_waiter_calls_property ON public.waiter_calls USING btree (property_id);


--
-- Name: idx_waiter_calls_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_waiter_calls_property_id ON public.waiter_calls USING btree (property_id);


--
-- Name: idx_waiter_calls_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_waiter_calls_status ON public.waiter_calls USING btree (status);


--
-- Name: idx_white_label_settings_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_white_label_settings_owner_id ON public.white_label_settings USING btree (owner_id);


--
-- Name: idx_white_label_settings_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_white_label_settings_tenant_id ON public.white_label_settings USING btree (tenant_id);


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21_pkey;


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3_pkey;


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7_pkey;


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94_pkey;


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b_pkey;


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571_pkey;


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989_pkey;


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_pkey; Type: INDEX ATTACH; Schema: pgboss; Owner: -
--

ALTER INDEX pgboss.job_pkey ATTACH PARTITION pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260_pkey;


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 dlq_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7
    ADD CONSTRAINT dlq_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j3f168501ed9816b51a9f5765e0742e1eb034ab6bf72c9ae3f3a975e3
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.jef5523d8acf56d538b27a5d236279df23cac2759096da69389f13989
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j10bd5924f7230189739f23247f21ac8e657b5c1ee17765490d757a21
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j6153debd705fdbeacdd8953cced2c951a2c1cc799b54b0263ffbfd94
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j81c9b7438e27619607db6d9b2a5643e60c301dd90d41fc6459c90571
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.jf5563464ef1a2907ae09a565b65fccab3d21f44c3a939c0236bed260
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j61ec26dfcd6bec3c304f799f782ddbc80a71cc856a4abd639032393b
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7 q_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.j4e890af05f82ff97cdad0801ef42960c32570063b6a765bc639bdae7
    ADD CONSTRAINT q_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: queue queue_dead_letter_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.queue
    ADD CONSTRAINT queue_dead_letter_fkey FOREIGN KEY (dead_letter) REFERENCES pgboss.queue(name);


--
-- Name: schedule schedule_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.schedule
    ADD CONSTRAINT schedule_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: subscription subscription_name_fkey; Type: FK CONSTRAINT; Schema: pgboss; Owner: -
--

ALTER TABLE ONLY pgboss.subscription
    ADD CONSTRAINT subscription_name_fkey FOREIGN KEY (name) REFERENCES pgboss.queue(name) ON DELETE CASCADE;


--
-- Name: pos_menu_items pos_menu_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_menu_items
    ADD CONSTRAINT pos_menu_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.pos_menu_categories(id) ON DELETE SET NULL;


--
-- Name: pos_order_items pos_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_order_items
    ADD CONSTRAINT pos_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.pos_orders(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict C6JhoSMKUlyey91ck26gdpKQ7G9ndRNmO9OQLwB5V5fwdyg6FlPgPdCUwL3o5rE

